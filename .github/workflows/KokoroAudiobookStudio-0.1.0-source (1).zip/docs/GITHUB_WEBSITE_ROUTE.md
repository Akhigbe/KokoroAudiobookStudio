# GitHub website-only route — no GitHub Desktop

Use this if you only have a github.com account and do not want to install
GitHub Desktop. You will create **one workflow file** in the website editor and
upload **one source ZIP**. GitHub Actions expands the ZIP on its Windows runner.

## What you need

- A GitHub account.
- The updated source ZIP:

```text
dist/KokoroAudiobookStudio-0.1.0-source.zip
```

- A text editor such as Notepad to copy the workflow text.

You do not need Python, Inno Setup, PyInstaller, Visual Studio, or a Windows PC.

---

## 1. Create a new repository

1. Go to <https://github.com> and sign in.
2. Click the **+** button in the top-right corner.
3. Click **New repository**.
4. Use:

```text
Repository name: KokoroAudiobookStudio
Description: Offline Kokoro audiobook studio
Visibility: Public
```

5. Tick **Add a README file**.
6. Click **Create repository**.

---

## 2. Create the workflow file on the website

1. In your new repository, click **Add file**.
2. Click **Create new file**.
3. In the filename box near the top, paste this exact path:

```text
.github/workflows/build-windows.yml
```

GitHub will create the `.github` and `workflows` folders automatically.

4. In the large editor box, paste this entire workflow:

<details>
<summary>Click to expand workflow YAML</summary>

```yaml
name: Build Windows installer

on:
  workflow_dispatch:
  push:
    tags:
      - "v*"

permissions:
  contents: write

jobs:
  build:
    runs-on: windows-2022
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Set up Python 3.12 x64
        uses: actions/setup-python@v5
        with:
          python-version: "3.12"
          architecture: "x64"

      - name: Install Inno Setup 6
        shell: pwsh
        run: choco install innosetup --yes --no-progress

      - name: Prepare source
        shell: pwsh
        run: |
          $ErrorActionPreference = "Stop"
          $zips = @(Get-ChildItem -Path . -Filter "*-source.zip" -File)
          if ($zips.Count -gt 1) {
            throw "More than one *-source.zip found in the repository root. Delete old source ZIPs and keep exactly one."
          }
          $zip = $zips | Select-Object -First 1
          if ($zip) {
            Write-Host "Expanding $($zip.Name) into source/"
            if (Test-Path source) { Remove-Item source -Recurse -Force }
            Expand-Archive -Path $zip.FullName -DestinationPath source -Force
          } else {
            Write-Host "No source ZIP found; using repository root files."
            if (Test-Path source) { Remove-Item source -Recurse -Force }
            New-Item -ItemType Directory -Path source | Out-Null
            Get-ChildItem -Force | Where-Object {
              $_.Name -notin @("source", ".git")
            } | Copy-Item -Destination source -Recurse -Force
          }
          if (-not (Test-Path "source\scripts\build_windows.bat")) {
            throw "source\scripts\build_windows.bat was not found. Upload the source ZIP or extracted files correctly."
          }

      - name: Run pinned Windows build
        shell: pwsh
        working-directory: source
        run: .\scripts\build_windows.bat -SkipTests

      - name: Upload installer and portable ZIP
        uses: actions/upload-artifact@v4
        with:
          name: KokoroAudiobookStudio-Windows
          path: |
            source/dist/installer/*.exe
            source/dist/*.zip
            source/dist/SHA256SUMS.txt
          if-no-files-found: error

      - name: Attach artifacts to GitHub Release
        if: startsWith(github.ref, 'refs/tags/')
        uses: softprops/action-gh-release@v2
        with:
          files: |
            source/dist/installer/*.exe
            source/dist/*.zip
            source/dist/SHA256SUMS.txt
```

</details>

5. Scroll down to **Commit new file**.
6. In the commit message box, type:

```text
Add Windows build workflow
```

7. Click **Commit new file**.

---

## 3. Upload the source ZIP

1. Go back to the main page of the repository.
2. Click **Add file**.
3. Click **Upload files**.
4. Drag and drop, or choose:

```text
KokoroAudiobookStudio-0.1.0-source.zip
```

Only upload this one ZIP file. You do **not** need to upload extracted folders.

If you already uploaded an older ZIP, **delete the old ZIP from the repository
first**, then upload the updated one. The workflow rejects multiple
`*-source.zip` files to avoid building the wrong version.

5. In the commit message box, type:

```text
Add Kokoro source ZIP
```

6. Click **Commit changes**.

The workflow is designed to find any file ending in `-source.zip`, expand it
into a `source` folder, and build from there.

---

## 4. Run the build

1. Click the **Actions** tab.
2. If GitHub asks to enable workflows, click:

```text
I understand my workflows, go ahead and enable them
```

3. In the left sidebar, click:

```text
Build Windows installer
```

4. Click the **Run workflow** dropdown on the right.
5. Branch:

```text
main
```

6. Click the green **Run workflow** button.
7. Wait until the run shows a green check mark.

---

## 5. Download the installer

1. Click the workflow run.
2. Scroll down to **Artifacts**.
3. Download:

```text
KokoroAudiobookStudio-Windows
```

4. Unzip the downloaded artifact.
5. Open the `installer` folder.
6. Double-click:

```text
KokoroAudiobookStudio-0.1.0-win64-setup.exe
```

If Windows SmartScreen appears, choose **More info → Run anyway**. The installer
is not code-signed.

---

## 6. Install and finish first-run setup

1. Complete the installer.
2. Launch **Kokoro Audiobook Studio**.
3. Complete the setup wizard:
   - q8 model,
   - selected voices,
   - checksum-verified downloads,
   - generate and play a local sample,
   - confirm audibility,
   - **Offline Ready**.

---

## If something goes wrong

- If **Actions** is missing, confirm the workflow path is exactly:

```text
.github/workflows/build-windows.yml
```

- If the build cannot find `source\scripts\build_windows.bat`, you uploaded
  the wrong ZIP or did not upload the source ZIP at the repository root.
- If a step is red, click it, copy the last 30 lines, and send them back.
- If GitHub asks for billing on private repositories, make the repo public.
- If SmartScreen warns, that is expected because no code-signing certificate is
  configured.

## Optional: permanent Release download

Create a release/tag named `v0.1.0`. The workflow will attach the installer,
portable ZIP and checksums to the GitHub Release automatically.
