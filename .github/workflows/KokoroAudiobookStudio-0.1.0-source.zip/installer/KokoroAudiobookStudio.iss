; Inno Setup 6 script for Kokoro Audiobook Studio (Windows 10/11 x64).
; Compiled by scripts/build_windows.ps1. User projects and model files live in
; %LOCALAPPDATA%\KokoroAudiobookStudio and are preserved by default.

#ifndef AppVersion
  #define AppVersion "0.1.0"
#endif
#ifndef SourceDir
  #define SourceDir "..\build\staging"
#endif
#ifndef OutputDir
  #define OutputDir "..\dist\installer"
#endif

#define MyAppName "Kokoro Audiobook Studio"
#define MyAppShortName "KokoroAudiobookStudio"
#define MyAppPublisher "Kokoro Audiobook Studio contributors"
#define MyAppURL "https://github.com/thewh1teagle/kokoro-onnx"
#define MyAppExeName "KokoroAudiobookStudio.exe"
#define MySetupExeName "KokoroResourceSetup.exe"
#define MyAppId "{{038ED9E4-A4C4-551C-A24C-33C752536EA9}"

[Setup]
AppId={#MyAppId}
AppName={#MyAppName}
AppVersion={#AppVersion}
AppVerName={#MyAppName} {#AppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\Kokoro Audiobook Studio
DisableDirPage=auto
DefaultGroupName=Kokoro Audiobook Studio
DisableProgramGroupPage=yes
LicenseFile=..\LICENSE
InfoBeforeFile=..\docs\PRIVACY.md
OutputDir={#OutputDir}
OutputBaseFilename=KokoroAudiobookStudio-{#AppVersion}-win64-setup
SetupIconFile=..\assets\icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
UninstallDisplayName={#MyAppName}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
PrivilegesRequired=lowest
CloseApplications=yes
RestartApplications=no
UsedUserAreasWarning=no
VersionInfoVersion={#AppVersion}.0
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription=Offline local audiobook production with Kokoro
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#AppVersion}.0

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
; The one-dir build already contains the Python runtime and all native wheels.
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursedirs createallsubdirs; Excludes: "*.pyc,*.pyo,__pycache__\*,*.log,*.tmp,portable.txt,README_PORTABLE.txt"

[Icons]
Name: "{group}\Kokoro Audiobook Studio"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"
Name: "{group}\Kokoro Resource Setup"; Filename: "{app}\{#MySetupExeName}"; WorkingDir: "{app}"
Name: "{group}\Documentation"; Filename: "{app}\README.md"; WorkingDir: "{app}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Kokoro Audiobook Studio"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon; WorkingDir: "{app}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#MyAppName}}"; Flags: nowait postinstall skipifsilent

[Code]
var
  RemoveDataCheck: TNewCheckBox;
  RemoveUserData: Boolean;

procedure InitializeUninstallProgressForm();
begin
  RemoveUserData := False;
  RemoveDataCheck := TNewCheckBox.Create(UninstallProgressForm);
  RemoveDataCheck.Parent := UninstallProgressForm;
  RemoveDataCheck.Left := ScaleX(18);
  RemoveDataCheck.Top := UninstallProgressForm.ClientHeight - ScaleY(76);
  RemoveDataCheck.Width := UninstallProgressForm.ClientWidth - ScaleX(36);
  RemoveDataCheck.Height := ScaleY(24);
  RemoveDataCheck.Checked := False;
  RemoveDataCheck.Caption := 'Also delete my projects, generated audio, downloaded models and settings';
  RemoveDataCheck.Hint := 'Leave unchecked to preserve everything for a later reinstall or upgrade.';
  RemoveDataCheck.ShowHint := True;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usUninstall then
  begin
    if RemoveDataCheck <> nil then
      RemoveUserData := RemoveDataCheck.Checked;
  end;
  if (CurUninstallStep = usPostUninstall) and RemoveUserData then
  begin
    DelTree(ExpandConstant('{localappdata}\KokoroAudiobookStudio'), True, True, True);
  end;
end;
