# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller one-dir build for Kokoro Audiobook Studio (Windows x64).

Build with CPython 3.12 x64 and PyInstaller 6.16.0 using
scripts/build_windows.ps1.  The output is a folder containing the main
executable; the worker uses the same executable with --engine-worker.
"""
from pathlib import Path
from PyInstaller.utils.hooks import collect_all, collect_data_files, collect_dynamic_libs

ROOT = Path(SPECPATH).resolve().parent
ENTRY = ROOT / "scripts" / "windows" / "entry_main.py"

datas = [
    (str(ROOT / "src" / "kokoro_studio" / "assets"), "kokoro_studio/assets"),
    (str(ROOT / "docs"), "docs"),
    (str(ROOT / "third_party_licenses"), "third_party_licenses"),
    (str(ROOT / "assets" / "samples"), "assets/samples"),
    (str(ROOT / "NOTICE.md"), "."),
    (str(ROOT / "LICENSE"), "."),
    (str(ROOT / "README.md"), "."),
    (str(ROOT / "CHANGELOG.md"), "."),
]
binaries = []
hiddenimports = [
    "kokoro_onnx", "kokoro_onnx.config", "kokoro_onnx.tokenizer",
    "kokoro_onnx.chunker", "kokoro_onnx.session", "kokoro_onnx.utils",
    "onnxruntime", "onnxruntime.capi.onnxruntime_pybind11_state",
    "phonemizer", "phonemizer.backend", "phonemizer.backend.espeak",
    "espeakng_loader", "customtkinter", "miniaudio", "lameenc",
    "soundfile", "pypdf", "docx", "markdown", "psutil", "requests",
    "darkdetect", "packaging", "numpy",
]
for package in ("customtkinter", "kokoro_onnx", "espeakng_loader", "phonemizer", "miniaudio"):
    package_datas, package_binaries, package_hidden = collect_all(package)
    datas += package_datas
    binaries += package_binaries
    hiddenimports += package_hidden
for package in ("onnxruntime", "soundfile", "lameenc", "numpy"):
    binaries += collect_dynamic_libs(package)
datas += collect_data_files("pypdf")
datas += collect_data_files("docx")
hiddenimports = sorted(set(hiddenimports))

excludes = [
    "PySide6", "PyQt5", "PyQt6", "torch", "torchvision", "torchaudio",
    "gradio", "transformers", "spacy", "matplotlib", "scipy", "pandas",
    "IPython", "jupyter", "notebook", "pytest", "fpdf", "tkinter.test",
    "test", "unittest", "pdb", "doctest", "difflib", "pydoc",
]

a = Analysis(
    [str(ENTRY)],
    pathex=[str(ROOT / "src")],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=None)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="KokoroAudiobookStudio",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(ROOT / "assets" / "icon.ico"),
    version=str(ROOT / "scripts" / "windows" / "version_info.txt"),
)
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="KokoroAudiobookStudio",
)
