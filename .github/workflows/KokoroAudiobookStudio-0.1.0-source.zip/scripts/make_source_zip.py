#!/usr/bin/env python3
"""Create a reproducible source ZIP from the current workspace."""
from __future__ import annotations
import hashlib, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "dist" / "KokoroAudiobookStudio-0.1.0-source.zip"
EXCLUDE_DIRS = {"dist", "build", ".git", ".pytest_cache", "__pycache__", ".ruff_cache", "node_modules"}
EXCLUDE_FILES = {".DS_Store", "Thumbs.db"}
def include(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return False
    if path.name in EXCLUDE_FILES or path.suffix in {".pyc", ".pyo", ".log"}:
        return False
    return True
def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    files = sorted(p for p in ROOT.rglob("*") if p.is_file() and include(p))
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in files:
            zf.write(path, path.relative_to(ROOT).as_posix())
    digest = hashlib.sha256(OUT.read_bytes()).hexdigest()
    (ROOT / "dist" / "SHA256SUMS-source.txt").write_text(f"{digest}  {OUT.name}\n", encoding="ascii")
    print(f"Wrote {OUT} ({OUT.stat().st_size} bytes, {len(files)} files)")
    print(f"SHA-256 {digest}")
if __name__ == "__main__":
    main()
