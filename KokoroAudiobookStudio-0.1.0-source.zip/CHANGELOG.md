# Changelog

## 0.1.0 — 2026-10-26

- First source-complete release candidate.
- Pinned official Kokoro v1.0 q8 ONNX model and 54-voice manifest.
- Isolated CPU ONNX Runtime worker with one-thread low-memory mode by default.
- CustomTkinter light/dark desktop UI with nine production sections.
- Resumable setup/voice downloader with HTTP Range and SHA-256 verification.
- Explicit offline readiness test with real local sample generation and playback confirmation.
- Local TXT/Markdown/DOCX/PDF/paste import, chapter tools and auditable narration preprocessing.
- Persistent SQLite project store, chunk-level regeneration, cancellation/resume and streaming WAV/MP3 export.
- Reproducible Windows build scripts, Inno Setup project, portable mode, docs, sample project and test reports.
