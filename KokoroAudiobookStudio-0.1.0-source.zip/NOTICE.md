# Kokoro Audiobook Studio — notices

Copyright © 2026 Kokoro Audiobook Studio contributors.

The application source in this repository is licensed under **GNU GPL version 3
or later** (`GPL-3.0-or-later`). The full text is in [`LICENSE`](LICENSE). This
choice is compatible with the GPL-licensed phonemization components used by the
application. This document is an engineering inventory, not legal advice;
review all obligations before commercial redistribution.

## Model and voice resources (downloaded separately)

The installer does **not** bundle the Kokoro model or voice style vectors. During
first-run setup the app downloads a user-selected official ONNX model and
selected voice `.bin` files from:

- `https://huggingface.co/onnx-community/Kokoro-82M-v1.0-ONNX`
- pinned commit `1939ad2a8e416c0acfeecc08a694d14ef25f2231`
- upstream model/voice license: **Apache-2.0**
- upstream project: `https://huggingface.co/hexgrad/Kokoro-82M`

Exact sizes and SHA-256 digests are in
`src/kokoro_studio/assets/resource_manifest.json`. The setup report written to
stable app data records the files, hashes and model revision actually used.
Apache-2.0 is included as `third_party_licenses/Apache-2.0.txt`.

## Phonemization and MP3 licensing (important)

- `phonemizer==3.4.0` is **GPL-3.0-or-later**. Its bundled eSpeak NG engine and
  data are also GPL-3.0-or-later. See `third_party_licenses/GPL-3.0-or-later.txt`.
- `espeakng-loader==0.2.4` is MIT (wrapper); the eSpeak NG library it ships is
  GPL-3.0-or-later. See `third_party_licenses/MIT.txt`.
- `lameenc==1.9.0` and the LAME encoder are **LGPL-3.0-or-later**. See
  `third_party_licenses/LGPL-3.0-or-later.txt`. The application uses the
  unmodified published Python extension as a separate dynamically loaded module
  and does not claim ownership of LAME.
- The full source for this application, the complete build scripts, the pinned
  dependency list and instructions to obtain unmodified upstream sources are in
  the source archive and in `docs/DEPENDENCIES.md`. For LGPL relinking, replace
  the `lameenc` extension in the build environment with a compatible build.

## Other bundled runtime components

MIT: `kokoro-onnx==0.6.1`, `onnxruntime==1.22.1`, `miniaudio==1.71`,
`python-docx==1.2.0`, `charset-normalizer`, `urllib3`.

BSD family: `numpy==2.2.6`, `soundfile==0.13.1`, `pypdf==6.1.1`,
`Markdown==3.9`, `psutil==7.1.0`, `darkdetect==0.8.0`, `pycparser`, `idna`.

Apache-2.0: `requests==2.32.5`. `packaging==25.0` is dual Apache-2.0 OR
BSD-2-Clause. `certifi` is MPL-2.0. Pillow is MIT-CMU. `cffi` is MIT-0.
`typing_extensions` is PSF-2.0.

`customtkinter==6.0.0` metadata declares CC0-1.0 while its classifiers mention
MIT; both texts are included. The unmodified wheel is used.

Full SPDX texts are in [`third_party_licenses/`](third_party_licenses/). A
machine-readable inventory of the development environment is in
`reports/pip_licenses_all.json`; curated shipped-runtime inventory is in
[`docs/DEPENDENCIES.md`](docs/DEPENDENCIES.md).

## Build tools (not required by end users)

- PyInstaller 6.16.0: GPL-2.0-or-later **with bootloader exception**. See
  `third_party_licenses/GPL-2.0-or-later.txt` and
  `third_party_licenses/PyInstaller-BOOTLOADER-EXCEPTION.txt`.
- Inno Setup 6 is used only on the maintainer's Windows build machine; it is
  not bundled in the application.
- `fpdf2`, `pytest` and `pip-licenses` are development/test tools and are not
  included in the runtime installer.

## No telemetry / no online TTS

There is no telemetry, advertising, account system, mandatory cloud sync or
online TTS fallback. Network calls are limited to explicit setup/repair
downloads from the pinned Hugging Face repository. See `docs/PRIVACY.md`.
