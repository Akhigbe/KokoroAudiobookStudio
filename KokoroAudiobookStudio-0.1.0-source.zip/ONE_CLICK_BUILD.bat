@echo off
chcp 65001 >nul
title Kokoro Audiobook Studio -- one-click Windows build
echo.
echo ============================================================
echo  Kokoro Audiobook Studio -- one-click Windows build
echo ============================================================
echo.
echo This will install Python 3.12 and Inno Setup 6 on THIS BUILD PC
echo if needed, then create:
echo   dist\installer\KokoroAudiobookStudio-0.1.0-win64-setup.exe
echo   dist\KokoroAudiobookStudio-0.1.0-win64-portable.zip
echo.
echo End users of the generated installer do NOT need Python or Inno Setup.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\one_click_build.ps1" %*
set EXIT_CODE=%ERRORLEVEL%
echo.
if "%EXIT_CODE%"=="0" (
  echo SUCCESS. Look in the dist\installer folder and double-click the setup .exe.
) else (
  echo Build failed with exit code %EXIT_CODE%. See docs\ONE_CLICK_RELEASE.md.
)
echo.
pause
exit /b %EXIT_CODE%
