# Kokoro Audiobook Studio

A local-first Windows desktop application for producing complete audiobooks with
Kokoro v1.0 ONNX speech synthesis. It is designed for a **4 GB RAM Windows 10/11
x64 PC**, uses CPU inference by default, and works fully offline after a one-time
resource setup.

![Light theme](docs/screenshots/light.png)

Dark theme: `docs/screenshots/dark.png`.

## Easiest path: one-click Windows build

If you just want an installer, download the source ZIP, extract it on a Windows
10/11 x64 PC, and double-click **`ONE_CLICK_BUILD.bat`**. It installs the build
prerequisites with `winget`, creates the installer, then opens the output
folder. Double-click the generated setup `.exe` to install the app.

Full non-technical steps: `docs/ONE_CLICK_RELEASE.md`.

For a cloud build that needs no local Windows build tools, follow
`docs/GITHUB_ROUTE.md` and run the included `.github/workflows/build-windows.yml`
workflow on GitHub Actions.

If you do not have GitHub Desktop, use `docs/GITHUB_WEBSITE_ROUTE.md`.

## Important: this workspace contains source + reproducible build, not a compiled installer

This environment is Linux and cannot honestly produce or test a Windows `.exe`
installer. The repository includes:

- complete application source,
- pinned Windows dependency list,
- PyInstaller spec,
- Inno Setup installer script,
- portable ZIP build,
- setup wizard, offline readiness test, sample project/manuscript and WAV samples,
- automated test results and benchmark reports.

Run `scripts/build_windows.bat` on a Windows 10/11 x64 machine to produce the
actual installer and portable ZIP. End users of that installer do **not** need
Python, Git, Node, Rust, Docker, FFmpeg, Visual Studio or a browser stack.

See:

- `docs/INSTALL.md` — install/use instructions,
- `docs/BUILD_WINDOWS.md` — exact build procedure,
- `docs/TEST_REPORT.md` and `docs/END_TO_END_TEST_REPORT.md` — measured results,
- `docs/KNOWN_LIMITATIONS.md` — honest limitations,
- `NOTICE.md` and `docs/DEPENDENCIES.md` — license inventory.

## Quick start (after the Windows installer is built)

1. Run `KokoroAudiobookStudio-0.1.0-win64-setup.exe`.
2. Launch **Kokoro Audiobook Studio**.
3. Complete the first-run wizard. It downloads the selected pinned q8 model and
   voice files, verifies SHA-256 checksums, generates a real local speech sample,
   asks you to play it and confirm audibility, then reports **Offline Ready**.
4. Create/open a project, import TXT/Markdown/DOCX/PDF or paste text.
5. Review chapters and narration text; edit as needed.
6. Start the generation queue. Chunks are saved as WAV immediately and can be
   resumed or selectively regenerated.
7. Play completed chunks and export WAV or MP3 from Audio Library.

Recommended setup: **Balanced Q8** model, 4 English voices, 1 inference thread,
low-memory mode ON. This needs roughly 100 MB of downloads plus working space.

## Try from source (testing only)

```bash
python -m pip install -r requirements-dev.txt
PYTHONPATH=src python -m kokoro_studio.app --skip-setup
```

On headless Linux use `xvfb-run -a` and `--headless`. This source mode requires
Python; the packaged Windows build does not.

## License

Application code: GPL-3.0-or-later. Model/voices: Apache-2.0. Some runtime
components are GPL/LGPL; see `NOTICE.md`.
