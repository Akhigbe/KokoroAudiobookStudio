# The Lantern at Wintergate

*A sample manuscript for Kokoro Audiobook Studio.*

## Chapter 1: The Last Train

On 12 February 2026, Maya found a small brass key beneath the old station clock. It was wrapped in blue paper and marked with the number 7. “Do you hear that?” she whispered.

The last train arrived at 7:45 p.m., twelve minutes late. Dr. Okafor stepped onto the platform carrying a 2 kg parcel and a lantern that had not been lit for 30 years. He paid $12.50 for the ticket, though the route had been closed since 1996.

“Wintergate is not on the map,” he said. “That is why we can still find it.”

Maya looked at the key. The station lamps flickered once, then turned green.

## Chapter 2: The Map Room

The map room smelled of rain and old paper. On the wall, a red line ran 5 km beyond the final station and ended at a place labelled Platform 3.

Mr. Adeyemi had waited for 3 minutes before speaking. “Only 10% of the railway was ever built,” he explained. “The rest exists only when someone remembers it.”

A brass telephone rang. Maya lifted the receiver and heard the sea.

## Chapter 3: The Lantern

They walked beneath the hill for 1.2 km. The lantern in Dr. Okafor’s hand began to glow without a flame.

At the final door, Maya turned the key. Beyond it was a platform washed in morning light, and a train waiting with no driver.

“Where does it go?” she asked.

“Wherever the story needs to go next,” said Dr. Okafor.

The lantern went out. The train began to move.
