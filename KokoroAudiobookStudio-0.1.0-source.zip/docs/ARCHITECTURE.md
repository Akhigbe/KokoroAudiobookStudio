# Architecture

```
CustomTkinter desktop process
  ├─ SQLite project store + atomic settings
  ├─ import / chapter / narration preprocessing
  ├─ downloader + checksum verifier (setup only)
  ├─ generation queue (background thread)
  ├─ streaming audio exporter + miniaudio player
  └─ EngineClient ──stdin/stdout JSON──> isolated Kokoro worker process
                                             ├─ ONNX Runtime CPU session
                                             ├─ kokoro-onnx + eSpeak NG G2P
                                             └─ streams one chunk WAV to disk
```

The desktop process never loads ONNX Runtime. The worker owns the model session,
uses one intra-op thread by default, enables the ORT CPU arena/memory pattern,
and can be terminated between chunks for cancellation/memory recovery.

Long-form generation is sequential: one chunk is phonemized and synthesized at
a time, written immediately as a 24 kHz PCM16 WAV, recorded in SQLite, then
released. Final export streams existing WAV chunks in chapter/chunk order; a
complete audiobook waveform is never held in RAM.

Enforced offline mode patches outbound socket/URL entry points in the desktop
process; the worker has no network client. Downloads only happen when the user
explicitly runs setup, installs a voice or repairs resources.

See `src/kokoro_studio/` for implementation and `docs/TEST_REPORT.md` for
measured memory/responsiveness results.
