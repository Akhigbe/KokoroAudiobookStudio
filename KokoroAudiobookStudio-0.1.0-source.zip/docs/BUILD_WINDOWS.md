# Reproducible Windows build

The build is intentionally split from this Linux workspace. PyInstaller cannot
cross-compile a Windows one-dir executable from Linux, and this environment has
no Inno Setup or Windows desktop. Therefore no `.exe` is claimed here.

## Build host

- Windows 10/11 x64
- CPython 3.12.x x64 (must match the pinned native wheels)
- Inno Setup 6
- PowerShell 5.1+ or PowerShell 7
- Internet access for pip only

## Command

```powershell
cd C:\path\to\KokoroAudiobookStudio
.\scripts\build_windows.bat
```

Optional portable-only build:

```powershell
.\scripts\build_windows.bat -SkipInstaller
```

## What the script does

1. Verifies Python 3.12 x64.
2. Creates `build\venv-win`.
3. Installs `requirements-windows.txt` with exact pins.
4. Runs offline-safe unit tests unless `-SkipTests` is passed.
5. Runs PyInstaller with `scripts\kokoro_main.spec`.
6. Copies `KokoroAudiobookStudio.exe` to `KokoroResourceSetup.exe` (same one-dir runtime; app dispatches by executable name).
7. Stages docs, license texts, sample manuscripts/WAVs and build info.
8. Compiles `installer\KokoroAudiobookStudio.iss` with Inno Setup.
9. Creates a portable ZIP with a `portable.txt` marker.
10. Writes `dist\SHA256SUMS.txt`.

## Outputs

- `dist\installer\KokoroAudiobookStudio-0.1.0-win64-setup.exe`
- `dist\KokoroAudiobookStudio-0.1.0-win64-portable.zip`
- `dist\SHA256SUMS.txt`

## Upgrade/uninstall behavior

Application code installs to Program Files (or per-user Programs with lowest
privileges). User data stays in `%LOCALAPPDATA%\KokoroAudiobookStudio`, which
contains `Resources`, `Projects`, `Exports`, `Logs`, `Cache`, `settings.json`
and setup reports. Inno Setup does not delete this directory by default. The
uninstall progress form offers an explicit checkbox to delete it.

Portable mode places the same structure in `Data` beside the executable.

## Reproducibility notes

- Runtime wheels are pinned in `requirements-windows.txt`.
- Model/voice downloads are pinned to Hugging Face commit `1939ad2a8e416c0acfeecc08a694d14ef25f2231` with exact sizes and SHA-256 digests in `src/kokoro_studio/assets/resource_manifest.json`.
- Small config/tokenizer files are bundled and checksum-verified.
- The installer does not bundle model or voice files.
- The build writes `BUILD_INFO.txt` and SHA-256 sums for artifacts.

## Required validation on real Windows

The build script is provided but was not executed on Windows in this workspace.
Before release, run the installer on a clean Windows 10/11 x64 machine with
4 GB RAM: complete setup, disconnect network, generate the sample project,
export WAV/MP3, upgrade over the old version, then uninstall once with data
preservation and once with explicit data deletion.
