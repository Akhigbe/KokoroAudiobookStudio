# Dependencies and license inventory

Pinned for **CPython 3.12 x64 / Windows 10/11**. Runtime versions are in
[`requirements-windows.txt`](../requirements-windows.txt). License texts are in
[`third_party_licenses/`](../third_party_licenses). See also [`NOTICE.md`](../NOTICE.md).

## Runtime packages included by the Windows build

| Package | Version | Purpose | License / SPDX | Upstream |
|---|---:|---|---|---|
| Kokoro v1.0 ONNX q8 model + voice `.bin` files | commit `1939ad2…` | speech model and voice styles; downloaded at setup, not bundled | Apache-2.0 | [Hugging Face](https://huggingface.co/onnx-community/Kokoro-82M-v1.0-ONNX) |
| kokoro-onnx | 0.6.1 | ONNX inference wrapper, tokenizer, chunking | MIT | [GitHub](https://github.com/thewh1teagle/kokoro-onnx) |
| onnxruntime | 1.22.1 | CPU inference runtime | MIT | [onnxruntime.ai](https://onnxruntime.ai) |
| phonemizer | 3.4.0 | grapheme-to-phoneme backend | GPL-3.0-or-later | [GitHub](https://github.com/bootphon/phonemizer) |
| eSpeak NG (via espeakng-loader) | 0.2.4 wrapper | bundled G2P library/data | wrapper MIT; eSpeak NG GPL-3.0-or-later | [GitHub](https://github.com/thewh1teagle/espeakng-loader) |
| numpy | 2.2.6 | numeric buffers | BSD-3-Clause | [numpy.org](https://numpy.org) |
| soundfile | 0.13.1 | streaming WAV chunk I/O | BSD-3-Clause; bundled libsndfile LGPL-2.1-or-later | [GitHub](https://github.com/bastibe/python-soundfile) |
| customtkinter | 6.0.0 | desktop UI | CC0-1.0 (metadata) / MIT classifier | [PyPI](https://pypi.org/project/customtkinter/) |
| miniaudio | 1.71 | streaming WAV/MP3 decode and playback | MIT | [GitHub](https://github.com/irmen/pyminiaudio) |
| lameenc | 1.9.0 | MP3 encoding without FFmpeg | LGPL-3.0-or-later | [GitHub](https://github.com/chrisstaite/lameenc) |
| pypdf | 6.1.1 | local PDF text extraction | BSD-3-Clause | [GitHub](https://github.com/py-pdf/pypdf) |
| python-docx | 1.2.0 | local DOCX extraction | MIT | [GitHub](https://github.com/python-openxml/python-docx) |
| Markdown | 3.9 | optional Markdown preview | BSD-3-Clause | [Python-Markdown](https://Python-Markdown.github.io/) |
| psutil | 7.1.0 | memory/disk safety checks | BSD-3-Clause | [GitHub](https://github.com/giampaolo/psutil) |
| requests | 2.32.5 | explicit pinned setup downloads | Apache-2.0 | [PyPI](https://pypi.org/project/requests/) |
| darkdetect | 0.8.0 | system theme detection | BSD-3-Clause | [GitHub](https://github.com/albertosottile/darkdetect) |
| packaging | 25.0 | version handling | Apache-2.0 OR BSD-2-Clause | [PyPI](https://pypi.org/project/packaging/) |

Selected transitive wheels commonly collected by PyInstaller: Pillow
(MIT-CMU), cffi (MIT-0), pycparser (BSD-3-Clause), certifi (MPL-2.0),
charset-normalizer (MIT), idna (BSD-3-Clause), urllib3 (MIT),
typing_extensions (PSF-2.0), and NumPy's bundled OpenBLAS/libquadmath notices.
The PyInstaller build collects their license files where present and this
repository keeps the corresponding SPDX texts.

## Build-only tools (not needed by end users)

| Tool | Version | Purpose | License |
|---|---:|---|---|
| PyInstaller | 6.16.0 | one-dir Windows executable | GPL-2.0-or-later with bootloader exception |
| Inno Setup | 6.x | installer compiler | own freeware license; not bundled in the app runtime |
| setuptools / wheel / pip | current | build environment | MIT / PSF / permissive |
| pip-licenses | 5.0.0 | license report generation | MIT |
| pytest | 8.4.2 | automated tests | MIT |
| fpdf2 | 2.8.5 | generate sample PDF in tests | LGPL-3.0-or-later |

The build does **not** use or require Torch, Gradio, spaCy, transformers, a
browser engine, PySide6, Node.js, Rust, Docker, FFmpeg, Visual Studio, Git or
manually installed Python for end users. All native runtime libraries come from
published Windows x64 wheels.

## Source / corresponding source offer

For GPL and LGPL components, the complete corresponding source consists of:

1. this source archive (application code, build scripts, pinned requirement
   files, manifest and documentation);
2. the unmodified upstream source distributions for the exact versions listed
   above, obtainable from the linked project/PyPI pages;
3. `scripts/build_windows.ps1`, `scripts/kokoro_main.spec` and
   `installer/KokoroAudiobookStudio.iss`, which reproduce the Windows build.

The build uses unmodified wheels. In particular `lameenc` remains a separate
dynamically loaded Python extension so it can be replaced with a modified
build under LGPL terms. No FFmpeg binary is used or shipped.

## Notes on model/voice redistribution

Model and voice files are deliberately **not** copied into the installer. They
are downloaded from the pinned upstream Hugging Face commit only when the user
runs first-time setup or explicitly installs a voice. The upstream project
declares Apache-2.0; `src/kokoro_studio/assets/resource_manifest.json` records
the exact source URL, size and SHA-256 for every downloadable file. The setup
wizard displays the pinned source and setup report records what was used.
