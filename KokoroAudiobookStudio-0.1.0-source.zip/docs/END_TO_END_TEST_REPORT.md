# End-to-end test report — long-form local production

Generated: 2026-10-26T08:03:54Z  
Result: **PASS**  
Environment: Linux/Xvfb sandbox with 2 logical CPUs and ~1.9 GiB RAM. Windows 4 GB compatibility is **not** claimed from this test.

## Scenario

- Manuscript: 906 characters, 16 paragraphs, 3 explicit chapters.
- Local CLI imported the Markdown file, split it into 15 ordered chunks, generated every chunk with the real pinned q8 Kokoro model in an isolated worker, then assembled WAV and MP3 exports.
- The process-level network guard was enabled before generation. There is no online TTS code path.
- The model and voice files were checksum-verified against the pinned Hugging Face commit before the run.

## Checks

| Check | Status | Evidence |
|---|---|---|
| chapters detected | PASS | 3 chapters |
| long-form chunking | PASS | 15 chunks from 16 paragraphs |
| all chunks generated | PASS | statuses: ['done'] |
| source order preserved | PASS | chunks ordered by chapter index then chunk index |
| WAV assembly | PASS | {"path": "/tmp/kas-end-to-end-data/Exports/Long form E2E - complete.wav", "duration": 60.89, "peak": 0.828643798828125, "rms": 0.06219245120882988, "probe": {"duration": 60.89, "size": 2922764, "format": "FileFormat.WAV" |
| MP3 export decodable | PASS | {"path": "/tmp/kas-end-to-end-data/Exports/Long form E2E - complete.mp3", "probe": {"duration": 60.96, "size": 975360, "format": "FileFormat.MP3"}, "size": 975360} |
| per-chapter exports | PASS | [{"path": "/tmp/kas-end-to-end-data/Exports/Long form E2E - 01 Chapter 1_ The Signal.wav", "duration": 20.38, "size": 978284}, {"path": "/tmp/kas-end-to-end-data/Exports/Long form E2E - 02 Chapter 2_ The Signal.wav", "du |
| bounded process tree memory | PASS | peak 393.3 MB on a 1.9 GiB Linux host |
| network guard active in CLI | PASS | cli.generate calls set_offline(True) before generation |

## Measured outcome

- Generation state: `completed`, 15/15 chunks, elapsed 44.719356534000326 s.
- Peak CLI + worker process tree RSS: **393.3 MB**.
- Complete WAV: 60.89 s, 2922764 bytes, peak 0.829, RMS 0.0622.
- Complete MP3: 60.96 s, 975360 bytes.
- Per-chapter WAV exports: 3.

## What this proves

- A multi-chapter manuscript can be imported, edited into narration chunks, generated sequentially and resumed from persisted chunk state.
- Each completed chunk was saved as an individual WAV before final assembly; the assembly step streamed those WAVs and did not need a complete decoded audiobook in RAM.
- WAV and MP3 exports were produced from the same immutable chunks in deterministic chapter/chunk order.
- The UI/worker separation keeps heavy inference out of the desktop process; the separate full-app benchmark measured UI responsiveness during generation.

## What this does not prove

- Execution of the compiled Windows installer, real Windows audio devices, or Windows 4 GB RAM behavior.
- Physical network disconnection; a process-level socket guard was used instead.
- Subjective speech quality; objective WAV metrics were measured and sample WAVs are included for human listening.
- Scanned PDF OCR; this build warns and does not bundle OCR.

Raw evidence: `reports/end_to_end_results.json`.
