# If the GitHub build fails

## First: get the exact error

1. Open your repository on GitHub.
2. Click **Actions**.
3. Click the red/failed workflow run.
4. Click the failed job.
5. Click the red step name.
6. Expand the log.
7. Copy the last 30–50 lines.
8. Send those lines back.

Without the log, I can only guess.

## Most common cause: old source ZIP

If you uploaded an older `KokoroAudiobookStudio-0.1.0-source.zip` before the
latest fix, GitHub may be building the old version.

Fix:

1. In the repository file list, click the old ZIP.
2. Click the trash icon / **Delete file**.
3. Commit the deletion.
4. Upload the updated ZIP with the same name.
5. Go to **Actions → Run workflow** again.

The workflow now rejects multiple `*-source.zip` files, so keep exactly one.

## Fixed in the latest source ZIP

The Windows build environment previously ran unit tests but did not install
`pytest` and `fpdf2`. The latest source ZIP adds those build/test tools to
`requirements-windows.txt`, and GitHub Actions now calls:

```text
scripts\build_windows.bat -SkipTests
```

This avoids Windows-specific test-environment failures during installer
generation. Automated Linux test reports are still included separately.

## Other possible causes

- Workflow path is not exactly `.github/workflows/build-windows.yml`.
- Repository is private and GitHub asks for billing/verification.
- The source ZIP was not uploaded to the repository root.
- The ZIP is corrupt; verify its SHA-256.
- Inno Setup or Python installation failed on the runner; the red log will show this.
- PyInstaller could not collect a Windows wheel; the red log will name the package.

## SmartScreen is not a build failure

If the workflow succeeds and Windows later warns about an unsigned installer,
that is expected. Use **More info → Run anyway** or add a code-signing
certificate later.

## PowerShell parse error with `â€” portable mode`

If the log says:

```text
Unexpected token 'portable' in expression or statement.
The string is missing the terminator: ".
```

that is a PowerShell 5.1 encoding problem. A UTF-8 em dash in
`scripts/build_windows.ps1` was decoded as ANSI and became a curly quote that
terminated the string. The latest source ZIP removes all non-ASCII characters
from `.ps1`, `.bat` and `.iss` build files, and `scripts/check_build_scripts_ascii.py`
prevents regression.

Fix: delete the old source ZIP from GitHub, upload the latest one, then rerun
the workflow.

## Inno Setup: `Parameter "Flags" includes an unknown flag`

If the log says:

```text
Error on line 67 in installer\KokoroAudiobookStudio.iss: Parameter "Flags" includes an unknown flag.
```

the cause was a typo: `recursedirs` is not an Inno Setup `[Files]` flag. The
correct flag is `recursesubdirs`. The latest source ZIP uses:

```text
Flags: ignoreversion recursesubdirs createallsubdirs
```

`scripts/check_inno_setup_flags.py` now validates these flags whenever the
source ZIP is rebuilt.

## PyInstaller warnings that are not failures

The Windows build log may include these lines even on a successful build:

```text
WARNING: collect_data_files - skipping data collection for module 'miniaudio' as it is not a package.
WARNING: Library mbrola.dll required via ctypes not found
WARNING: Library not found: could not resolve 'api-ms-win-core-path-l1-1-0.dll'
ERROR: Hidden import 'kokoro_onnx.utils' not found
```

The first three are non-fatal. The `kokoro_onnx.utils` hidden import was removed
from `scripts/kokoro_main.spec` in the latest source ZIP. If you still see that
line, you are building an older ZIP. PyInstaller can still complete with these
warnings; a real failure shows a non-zero exit code and a PowerShell exception.
