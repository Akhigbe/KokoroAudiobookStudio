# Fix: `source\scripts\build_windows.bat was not found`

This exact error means GitHub Actions did **not** find the application source in
your repository:

```text
No source ZIP found; using repository root files.
source\scripts\build_windows.bat was not found.
```

The workflow file alone cannot build the app. Your GitHub repository must also
contain the source ZIP or the extracted source files.

## What your repository should look like

On the repository **Code** tab, at the top level, you should see at least:

```text
.github\
KokoroAudiobookStudio-0.1.0-source.zip
README.md
```

The ZIP must be in the repository root, not only on your computer.

## Fix using the GitHub website

1. Download the updated source ZIP from the workspace:

```text
KokoroAudiobookStudio-0.1.0-source.zip
```

2. Open your GitHub repository.
3. On the main **Code** tab, click **Add file → Upload files**.
4. Choose the ZIP file from your computer.
5. Commit message:

```text
Add Kokoro source ZIP
```

6. Click **Commit changes**.
7. Go to **Actions → Build Windows installer → Run workflow** again.

## If you already uploaded a ZIP

1. Check that its name ends with:

```text
-source.zip
```

2. If there are two or more ZIP files ending in `-source.zip`, delete the old
   ones. The workflow rejects multiple source ZIPs.
3. If the ZIP is inside a subfolder, delete it and re-upload it to the repository
   root.
4. Replace `.github/workflows/build-windows.yml` with the latest workflow from
   `github-workflow-copy.yml` in the updated source ZIP. The latest workflow
   searches subfolders too and prints a clearer error.

## Alternative: upload extracted files

Instead of the ZIP, you can upload the extracted source folder contents. Your
repository root must then contain:

```text
scripts\build_windows.bat
src\kokoro_studio\
requirements-windows.txt
installer\
```

If you use this method, do not also leave a source ZIP in the repository.

## Still failing?

Open the failed workflow step and copy the section titled:

```text
Repository root contains:
```

Send that file listing back. It shows exactly what GitHub sees.
