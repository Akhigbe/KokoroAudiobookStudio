# GitHub Actions route — click-by-click

If you do not have GitHub Desktop, use the website-only route in `docs/GITHUB_WEBSITE_ROUTE.md`.

This route builds the Windows installer on GitHub's Windows runner. You do not
need Python, Inno Setup, PyInstaller, or a Windows build PC.

## Before you start

You need:

- a GitHub account,
- GitHub Desktop installed on your computer,
- the source ZIP:

```text
dist/KokoroAudiobookStudio-0.1.0-source.zip
```

If you use a public repository, GitHub Actions is free within normal limits.

---

## 1. Extract the source ZIP

1. Download `KokoroAudiobookStudio-0.1.0-source.zip`.
2. Right-click it → **Extract All…**
3. Choose a simple folder, for example:

```text
C:\Users\<you>\Documents\KokoroSource
```

4. Open the extracted folder. You should see files such as:

```text
ONE_CLICK_BUILD.bat
README.md
src\
scripts\
docs\
tests\
.github\
installer\
assets\
```

`.github` may be hidden by Windows. In File Explorer choose **View → Show →
Hidden items** if you want to see it. Do not delete it.

---

## 2. Create the GitHub repository with GitHub Desktop

1. Open **GitHub Desktop** and sign in to GitHub.
2. Click **File → New repository…**
3. Use:

```text
Name: KokoroAudiobookStudio
Description: Offline Kokoro audiobook studio
Local path: C:\Users\<you>\Documents\GitHub
```

4. You can leave **Initialize this repository with a README** unchecked.
5. Click **Create repository**.
6. Click **Show in Explorer** / **Open in Explorer**.
7. Copy **all contents** from the extracted `KokoroSource` folder into this new
   repository folder. Copy the contents, not the outer `KokoroSource` folder.
8. If Windows asks about replacing `README.md` or `.gitignore`, choose
   **Replace** so the project files are used.

---

## 3. Commit and publish

1. Return to **GitHub Desktop**.
2. You should now see a long list of added files on the left.
3. In the lower-left summary box, type:

```text
Add Kokoro Audiobook Studio source
```

4. Click **Commit to main**.
5. Click **Publish repository** near the top.
6. Choose **GitHub.com**.
7. You can make it **Public** to use free public Actions minutes.
8. Click **Publish Repository**.

---

## 4. Run the Windows build workflow

1. In your browser, open your new repository on GitHub.
2. Click the **Actions** tab.
3. If GitHub says workflows are disabled, click:

```text
I understand my workflows, go ahead and enable them
```

4. In the left sidebar, click:

```text
Build Windows installer
```

5. On the right, click the **Run workflow** dropdown.
6. Branch: `main`.
7. Click the green **Run workflow** button.
8. Wait. It usually takes several minutes. Refresh the page if needed.

---

## 5. Download the installer

1. Click the workflow run name, for example:

```text
Add Kokoro Audiobook Studio source
```

2. Wait until every step has a green check mark.
3. Scroll down to the **Artifacts** section.
4. Download:

```text
KokoroAudiobookStudio-Windows
```

5. Unzip the downloaded artifact.
6. Open the `installer` folder inside it.
7. You should see:

```text
KokoroAudiobookStudio-0.1.0-win64-setup.exe
```

8. Double-click that `.exe`.

If Windows SmartScreen appears, choose **More info → Run anyway**. The generated
installer is not code-signed in this project.

---

## 6. Install and use

1. Complete the Windows installer.
2. Launch **Kokoro Audiobook Studio** from the Start Menu.
3. Complete the first-run setup wizard:
   - choose the q8 model,
   - choose voices,
   - let files download and verify,
   - generate and play the local sample,
   - confirm audibility,
   - see **Offline Ready**.
4. Create/import a project and generate audio.

---

## If something goes wrong

- If the **Actions** tab has no workflow, confirm `.github/workflows/build-windows.yml` exists in the repo. A copy is included as `github-workflow-copy.yml` in the source ZIP.
- If a workflow step is red, click it, expand **Run pinned Windows build**, copy the last 30 lines, and send them back.
- If the artifact is missing, confirm the **Upload installer and portable ZIP** step succeeded.
- If GitHub asks to verify your account or billing for private Actions, make the repository public or use the local `ONE_CLICK_BUILD.bat` route.
- If you accidentally uploaded only the ZIP file instead of extracted contents, delete the repo contents and repeat step 2 with the extracted folder.

## Optional: create a GitHub Release download

If you want a permanent download page instead of an Actions artifact:

1. In GitHub Desktop, create a tag named `v0.1.0` and push it, or create a release on GitHub with that tag.
2. The workflow will attach the installer and portable ZIP to the Release automatically.
3. Users can download the `.exe` directly from the Releases page.

No code-signing certificate is configured; SmartScreen warnings are expected.
