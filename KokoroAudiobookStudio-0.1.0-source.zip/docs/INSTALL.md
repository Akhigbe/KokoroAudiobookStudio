# Installation and use

## A. Recommended: build the Windows installer, then install it

This repository does **not** include a compiled Windows `.exe`; see
`dist/README.md`. Build it once on a Windows machine, then give the installer to
end users.

### Build host prerequisites

- Windows 10/11 x64
- CPython 3.12 x64 on `PATH`
- Inno Setup 6 (`ISCC.exe` on `PATH` or default install location)
- Internet during the build only, to install pinned Python wheels

No Visual Studio, Git, Node, Rust, Docker or FFmpeg is required.

### Build

From PowerShell in the extracted source folder:

```powershell
.\scripts\build_windows.bat
```

Outputs:

```text
dist\installer\KokoroAudiobookStudio-0.1.0-win64-setup.exe
dist\KokoroAudiobookStudio-0.1.0-win64-portable.zip
dist\SHA256SUMS.txt
```

Verify `SHA256SUMS.txt` before distributing.

### End-user install

1. Copy the installer to the target Windows 10/11 x64 PC.
2. Double-click it. No Python or developer tools are needed.
3. Launch **Kokoro Audiobook Studio** from Start Menu.
4. Complete the first-run setup wizard.
5. After **Offline Ready**, disconnect the network if desired and use the app normally.

### Portable use

1. Unzip `KokoroAudiobookStudio-0.1.0-win64-portable.zip`.
2. Keep all files in the folder together.
3. Run `KokoroAudiobookStudio.exe`.
4. Data is stored in the `Data` folder beside the app. Back up that folder before deleting the portable app.

## B. First-run setup

The wizard will:

1. show measured system RAM/disk/CPU and optional GPU provider status;
2. show exact storage requirements before downloading;
3. let you choose the recommended q8 model (92.4 MB) or optional fp32 model (325.5 MB);
4. let you select an initial small voice set or any of the 54 documented voices;
5. download only those files from the pinned Hugging Face commit;
6. verify every file against its SHA-256 digest;
7. build a local voice pack and initialize the isolated ONNX Runtime worker;
8. generate a real WAV sample with outbound network sockets blocked;
9. ask you to play the sample and confirm you heard it before writing the Offline Ready marker.

If a download is interrupted, `.part` files are retained. Re-run setup or use
**Retry/Resume** to continue. Corrupt files are quarantined and re-downloaded.

## C. Daily use

1. **My Projects** → New project / Import file / Paste text.
2. Review the import preview. TXT, Markdown, DOCX and text-based PDF are supported. Scanned PDFs show an OCR warning; this build does not bundle OCR.
3. **Manuscript Editor** → correct original text and review the separate narration text and transformation log.
4. **Chapters** → rename, reorder, split, merge, assign voices and regenerate a chapter.
5. **Voice Library** → play local voice samples, set default, add voices later with explicit online permission.
6. **Generation Queue** → start, pause, cancel/resume, retry failures, regenerate selected chunks. Progress is actual completed chunks.
7. **Audio Library** → play any completed chunk immediately, navigate chapters, adjust volume/review speed, export complete book, each chapter or selected chapter as WAV/MP3.
8. **Settings** → speech rate, pauses, chapter transitions, text normalization, abbreviation/number/date/currency/measurement expansion, pronunciation respellings, low-memory mode, threads, theme, output format and offline mode.
9. **Model & Offline Status** → verify checksums, inspect runtime/voice data, run offline readiness test, play last sample, save setup report.

## D. Source mode (testing/repair only)

```bash
python -m pip install -r requirements-dev.txt
PYTHONPATH=src python -m kokoro_studio.app --skip-setup
```

To set up resources from a terminal:

```bash
PYTHONPATH=src python -m kokoro_studio.resource_setup --cli --model q8 --voices af_heart,af_bella,am_michael,bf_emma
```

To verify offline generation:

```bash
PYTHONPATH=src python -m kokoro_studio.cli offline-test --model q8
```

Source mode requires Python. The packaged Windows installer does not.
