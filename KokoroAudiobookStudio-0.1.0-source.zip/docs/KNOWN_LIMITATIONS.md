# Known limitations

- **No compiled Windows installer is included in this workspace.** It is Linux; a Windows `.exe` cannot be honestly produced or tested here. Use `scripts/build_windows.bat` on Windows and validate the output.
- **Windows 4 GB compatibility is not proven.** A RAM-constrained Linux/Xvfb full-app benchmark peaked below 0.5 GB process tree, but Windows OS overhead and real-device behavior remain unverified.
- First-run setup needs internet to download the pinned model/voices. Model files are not bundled.
- Offline tests used a process-level socket guard, not a physically disconnected NIC.
- Scanned/image-only PDFs are detected and reported; local OCR is not bundled in this 4 GB build.
- Non-English voices are listed with documented languages/accents, but only English G2P was benchmarked. Direct eSpeak phonemization may mispronounce heteronyms.
- The pronunciation dictionary uses user-controlled **say-as respellings**, not raw IPA/phoneme injection or voice cloning.
- No emotion controls, voice cloning, custom training or actor direction beyond rate/pauses/voice/text preparation.
- Built-in review speed changes playback sample rate and therefore pitch; it does not perform pitch-preserving time stretching.
- PDF extraction is heuristic; review quotations, tables and page-break joins.
- Optional DirectML is detected but not bundled or tested; CPU is the supported default.
- MP3 support uses an LGPL encoder. Review license/source obligations before commercial redistribution.
- Installer upgrade/uninstall preservation is implemented in the Inno Setup script but not executed on real Windows here.
- No subjective human listening comparison was performed; sample WAVs and objective metrics are provided.
