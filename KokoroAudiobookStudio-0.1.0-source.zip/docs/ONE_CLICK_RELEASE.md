# One-click release guide

This guide is for someone who does **not** want to learn PyInstaller, Inno Setup
or Windows packaging.

## Option A — local one-click builder (simplest if you have a Windows PC)

You need:

- a Windows 10/11 x64 PC,
- an internet connection during the build,
- the source ZIP from this workspace.

Steps:

1. Download:

   ```text
   dist/KokoroAudiobookStudio-0.1.0-source.zip
   ```

2. Right-click the ZIP → **Extract All**.

3. Open the extracted folder.

4. Double-click:

   ```text
   ONE_CLICK_BUILD.bat
   ```

5. A blue PowerShell window appears. It will:
   - check for Python 3.12 x64;
   - install it with `winget` if missing;
   - check for Inno Setup 6;
   - install it with `winget` if missing;
   - install the pinned Python wheels;
   - build the Windows installer and portable ZIP;
   - open the output folder when finished.

6. In the output folder, double-click:

   ```text
   KokoroAudiobookStudio-0.1.0-win64-setup.exe
   ```

7. If Windows SmartScreen appears, choose **More info → Run anyway**. The
   generated installer is currently unsigned because no code-signing
   certificate is included.

8. After installation, launch **Kokoro Audiobook Studio** and complete the
   first-run setup wizard.

That is the whole process. No manual Python commands are required.

### If winget is missing

Install **App Installer** from the Microsoft Store, then run
`ONE_CLICK_BUILD.bat` again. Alternatively, install Python 3.12 x64 and
Inno Setup 6 manually, then run `scripts\build_windows.bat`.

## Option B — GitHub Actions cloud build (no local build tools)

If you do not want to install anything on your own PC:

1. Create a GitHub account and a new repository.
2. Use **GitHub Desktop** or the GitHub web uploader to add the extracted
   source folder. Keep the `.github/workflows` folder.
3. In the repository, open the **Actions** tab.
4. Select **Build Windows installer**.
5. Click **Run workflow**.
6. Wait for the green check mark.
7. Open the workflow run and download the artifact named:

   ```text
   KokoroAudiobookStudio-Windows
   ```

8. Unzip the artifact and double-click the `.exe` installer.

If you push a tag such as `v0.1.0`, the workflow also attaches the installer
and portable ZIP to a GitHub Release.

## What you get

```text
KokoroAudiobookStudio-0.1.0-win64-setup.exe
KokoroAudiobookStudio-0.1.0-win64-portable.zip
SHA256SUMS.txt
```

The installer end users do **not** need Python, Git, Node, Rust, Docker,
FFmpeg, Visual Studio, or a browser stack.

## What this workspace does not contain

It does **not** contain a prebuilt Windows `.exe`, because this environment is
Linux. The one-click builder and GitHub Actions workflow are the two supported
ways to produce one. Neither has been executed on real Windows from this
workspace; see `docs/TEST_REPORT.md` and `docs/KNOWN_LIMITATIONS.md`.
