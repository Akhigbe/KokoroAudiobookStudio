# Privacy and network policy

Kokoro Audiobook Studio is local-first.

- No account, login, telemetry, analytics, advertising, mandatory cloud sync or hidden online TTS fallback.
- Manuscripts, projects, generated audio, settings and logs stay on the local machine.
- Speech generation, document import, playback, chapter editing and export perform no network calls.
- The only network activity is an explicit first-run setup, voice installation or resource repair. Those download pinned model/voice files over HTTPS from `huggingface.co/onnx-community/Kokoro-82M-v1.0-ONNX` and verify exact SHA-256 checksums.
- Enforced offline mode blocks outbound sockets in the application process. Local/loopback sockets used by the desktop remain available.
- Stable Windows data location: `%LOCALAPPDATA%\KokoroAudiobookStudio`. Installed upgrades and uninstall preserve this directory by default; the uninstaller offers an explicit checkbox to delete it.
- Portable mode stores data in a `Data` folder beside the executable.

No claim of physically disconnected network operation is made by the Linux test; it used a process-level socket guard. See `docs/TEST_REPORT.md`.
