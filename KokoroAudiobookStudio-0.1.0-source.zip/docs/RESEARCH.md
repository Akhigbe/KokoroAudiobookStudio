# Research and model selection

Primary sources consulted:

- Kokoro v1.0 model card: https://huggingface.co/hexgrad/Kokoro-82M
- Official ONNX variants: https://huggingface.co/onnx-community/Kokoro-82M-v1.0-ONNX
- Voice grades: https://huggingface.co/hexgrad/Kokoro-82M/raw/main/VOICES.md
- kokoro-onnx: https://github.com/thewh1teagle/kokoro-onnx
- ONNX Runtime: https://onnxruntime.ai
- phonemizer: https://github.com/bootphon/phonemizer
- miniaudio: https://github.com/irmen/pyminiaudio
- lameenc/LAME: https://github.com/chrisstaite/lameenc

## Decision

Choose a Python **ONNX Runtime CPU** architecture, not PyTorch/Gradio, a browser
UI, or Rust. PyTorch/Gradio portable projects have heavy dependencies and are
poor fits for 4 GB RAM. Rust/ONNX is promising but had higher Windows G2P and
build risk. The chosen stack uses a small CustomTkinter desktop, miniaudio
playback, an isolated Kokoro worker, and no FFmpeg process.

## Model benchmark

Environment: Linux x86_64, 2 vCPU, ~1.9 GiB RAM, ORT 1.22.1, 1 thread, 244-character
English sample, voice `af_heart`, 24 kHz PCM16 WAV.

- Official HF q8: 92,361,116 bytes; init 0.446 s; peak RSS 857.5 MB (conservative no-arena config); 22.23 s generation for 17.90 s audio; RTF 1.242.
- Official HF q8f16: 86,033,585 bytes; peak RSS 1.18 GB; RTF 1.265; later segfaulted with ORT 1.24.4.
- Official HF fp32: 325,532,232 bytes; peak RSS 1.30 GB; RTF 0.804; too memory-heavy for the 4 GB target.
- GitHub int8: failed on ORT 1.22.1 with unsupported `ConvInteger(10)`; on ORT 1.24.4 it ran but was much slower and had a DC offset.

Session-option testing on ORT 1.22.1 showed enabling the CPU memory arena and
memory pattern reduced q8 peak RSS to about 611 MB at one thread and about 567 MB
at two threads, while improving speed. The shipping worker uses that config.
One thread is the default to leave CPU time for the UI; two threads can be
selected in Settings.

Dynamic-time-warping log-mel comparison found q8 vs fp32 mean cosine distance
0.056, while the GitHub int8 was 0.230. This is an objective proxy, not a human
listening test. Generated WAV samples are included under `assets/samples/audio`.

## Licensing

The model and voices are Apache-2.0. `kokoro-onnx`, ONNX Runtime, miniaudio and
python-docx are MIT. `phonemizer`/eSpeak NG are GPL-3.0-or-later; `lameenc`/LAME
are LGPL-3.0-or-later. The application is therefore GPL-3.0-or-later and
preserves license notices. See `NOTICE.md` and `docs/DEPENDENCIES.md`.
