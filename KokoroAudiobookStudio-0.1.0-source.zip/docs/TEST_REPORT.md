# Test report — Kokoro Audiobook Studio 0.1.0

Generated: 2026-10-26T08:08:59Z  
Environment: Linux-6.1.158+-x86_64-with-glibc2.41, Python 3.13.16, 2 logical CPUs  
Overall: **PASS_WITH_LIMITATIONS**

> Honesty note: A Linux/Xvfb test is not a Windows 4 GB acceptance test. Windows installer execution remains unverified.

## Automated checks

| Check | Status | Evidence |
|---|---|---|
| Unit/integration tests | PASS | {'tests': 29, 'passed': 29, 'skipped': 0, 'failed': 0, 'errors': 0} |
| All-pages GUI smoke test | PASS | 9 pages, max timer delay 0.97 ms |
| GUI pytest marker | PASS | reports/acceptance_results.json |
| Real Kokoro offline inference | PASS | real WAV generated with network guard enabled |
| Full desktop + worker benchmark | PASS | peak process tree 448.1 MB, 3 chunks |
| Model/runtime benchmark data | PASS | reports/acceptance_results.json |
| Offline readiness report | PASS | reports/acceptance_results.json |
| Setup completion report | PASS | reports/acceptance_results.json |
| Long-form import → generation → WAV/MP3 | PASS | 15 chunks, WAV 60.89 s, MP3 60.96 s |

### Commands actually run

```bash
# Offline-safe unit/integration suite
PYTHONPATH=src python -m pytest -q -m 'not e2e and not gui' --disable-warnings
# All nine desktop pages under Xvfb
xvfb-run -a python -m kokoro_studio.app --self-test --headless --skip-setup --self-test-report reports/ui_smoke.json
# Real Kokoro inference with verified q8 resources and network guard enabled
KAS_E2E=1 KAS_DATA_DIR=<prepared-resource-root> PYTHONPATH=src python -m pytest -q -m e2e
# Full desktop + isolated ONNX worker benchmark
xvfb-run -a python scripts/benchmark_full_app.py --output reports/full_app_benchmark.json
# Long-form import -> real generation -> WAV/MP3 assembly
python scripts/end_to_end_test.py --model-file <verified-q8.onnx> --voice-source <official-voice-bin-folder>
```

## Measured results

### Unit and integration suite

- 29 passed, 0 skipped, 0 failed.
- Covered: chapter detection/order, narration preprocessing and toggles, chunk limits, TXT/Markdown/DOCX/PDF import, repeated header/footer cleanup, scanned-PDF OCR warning, SQLite project/backup/restore/duplicate, selective chunk invalidation, WAV/MP3 streaming assembly and order, resumable HTTP Range download with checksum/corrupt quarantine, offline network guard, generation queue cancellation/resume and selective regeneration.

### Standalone model benchmark (2 vCPU Linux sandbox, 244-character sample, 1 CPU thread)

| Model | Size | Init | Peak RSS | Generation | Audio | RTF | Decision |
|---|---:|---:|---:|---:|---:|---:|---|
| Official HF q8 | 92.4 MB | 0.444 s | 857.5 MB | 22.23 s | 17.90 s | 1.242 | **selected default** |
| Official HF fp32 | 325.5 MB | 0.755 s | 1300.6 MB | 14.45 s | 17.98 s | 0.803 | optional, too memory-heavy for 4 GB target |
- The table's first q8/fp32 runs used `enable_cpu_mem_arena=False` as an initial conservative test. The shipping worker enables the ORT CPU arena + memory pattern on ONNX Runtime 1.22.1, which lowered q8 worker peak to roughly 567–611 MB in session-option tests; the final full-app measurement below is lower still for short chunks.
- `hf_q8f16` produced a segmentation fault with ONNX Runtime 1.24.4 and was rejected.
- The GitHub `int8` export failed on ORT 1.22.1 with unsupported `ConvInteger(10)`. On ORT 1.24.4 it ran but was ~3× slower, had a DC offset of 0.020 and worse DTW spectral distance; it was rejected.
- q8 vs fp32 DTW mean log-mel cosine distance: 0.05646780427549537 (lower is closer). This is an objective proxy, not a human listening test.

### Full application with real inference, UI and WAV assembly

- Desktop process RSS at startup: **72.9 MB**; peak UI: **77.3 MB**.
- Peak UI + isolated worker process tree: **448.1 MB**; minimum available RAM observed: **466.5 MB** on a 1.9 GiB Linux host.
- Worker model init: **0.494 s**, provider `['CPUExecutionProvider']`, ORT `1.22.1`.
- Generated 3/3 chunks in **16.238 s** for **18.615 s** of audio; wall-clock RTF **0.8723**.
- UI timer responsiveness during generation: median **47.84 ms**, p95 **94.09 ms**, max **102.72 ms**; the interface remained usable.
- Assembled WAV: peak 0.565582275390625, RMS 0.06884102523326874, DC offset -0.00032915183692239225, clipped samples 0, file size 893564 bytes.

### Explicit offline readiness test

- `ResourceManager.offline_readiness_test()` enabled the process-level network guard, loaded the real pinned q8 model in the isolated worker, generated a WAV, and verified non-silent decodable audio.
- The setup wizard additionally requires the user to play the generated sample and confirm audibility before writing the Offline Ready marker.
- This is software network isolation, not a physically disconnected NIC; normal generation code has no network client and no online TTS fallback.

## Not run / unverified

- Executing a compiled Windows .exe installer on Windows 10/11 (this workspace is Linux and cannot produce/test one).
- Windows installer upgrade and uninstall preservation on real Windows (Inno Setup script is provided, not executed).
- A complete end-to-end run on a real 4 GB RAM Windows PC with Windows OS memory overhead.
- Physically disconnecting the network cable / disabling the NIC; the offline test used a process-level socket guard.
- Audible playback through a real Windows audio device; miniaudio NULL backend was used in Linux UI tests.
- Scanned-PDF OCR accuracy; local OCR is not bundled in this 4 GB-memory build.
- DirectML/GPU acceleration on Windows; the optional package is not bundled and was not tested.
- Subjective listening comparison by a human; objective WAV metrics and dynamic-time-warping spectral similarity were measured instead.
- Installing additional voices from the live Hugging Face CDN during an automated test; the resumable downloader was tested against a local HTTP Range server.

## Interpretation for the 4 GB RAM target

The measured Linux process tree peaked below 0.5 GB during a real full-app generation, and the worker was constrained to one ORT intra-op thread. A conservative budget adding Windows 10/11 desktop overhead (roughly 1.2–1.8 GB), the 73–78 MB UI, and the 0.4 GB worker stays below 4 GB on paper. **This is an estimate, not proof.** Real Windows 4 GB acceptance testing is still required before claiming compatibility.

## Raw evidence

- `reports/acceptance_results.json`
- `reports/full_app_benchmark.json` (time-series samples and UI callback delays)
- `reports/ui_smoke.json`
- `reports/hf_q8.json`, `hf_fp32.json`, `hf_q8f16.json`, `gh_int8.json`
- `reports/quality_comparison.json`, `reports/dtw_quality.json`
- `reports/offline_ready_e2e.json`, `reports/setup_report_e2e.json`
- `reports/end_to_end_results.json` and `docs/END_TO_END_TEST_REPORT.md`
- `reports/acceptance_logs/` (raw stdout/stderr)
