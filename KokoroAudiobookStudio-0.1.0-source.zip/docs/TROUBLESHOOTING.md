# Troubleshooting

**Setup cannot download resources**
- Confirm you explicitly allowed setup/voice download; offline mode blocks network calls.
- Check free disk space. The wizard shows model + voices + working-space requirements before download.
- Re-run setup: `.part` files resume with HTTP Range. Corrupt files are moved to `.corrupt` and downloaded again.

**Offline readiness fails**
- Open Model & Offline Status and review failed checksum/runtime checks.
- Confirm `Resources\models\q8.onnx`, `Resources\config`, `Resources\voices\installed.npz` and eSpeak data exist.
- Run `Model & Offline Status → Generate & verify sample`.
- If playback fails, verify the Windows audio output device, then use Play last sample.

**Generation is slow**
- Keep low-memory mode ON and threads at 1 on a 4 GB PC. Two threads may be faster but can reduce UI responsiveness on 2-core CPUs.
- Close other applications. The queue pauses when available RAM is critically low.
- Use the recommended q8 model, not fp32.

**A chunk failed**
- Open Generation Queue; the chapter, text segment and error are shown.
- Use Retry failed or Regenerate selected. Completed chunks are reused.

**Export fails**
- Ensure every selected chunk is `done` and its WAV exists. Regenerate missing chunks.
- For MP3, verify the bundled `lameenc` extension is present. WAV export does not need it.

**No sound**
- Check Windows default output device and volume.
- Play a completed chunk from Audio Library, not only the combined file.
- The Linux automated tests used a NULL audio backend; real Windows audio devices require manual validation.

**PDF import looks wrong**
- Use a text-based PDF. Image-only PDFs need external OCR before import.
- Use Manuscript Editor to correct headers, footers and line-break joins.

**Portable mode lost data**
- Keep all files together and do not delete the `Data` folder. A `portable.txt` marker beside the executable enables portable mode.

**Logs**
- Windows: `%LOCALAPPDATA%\KokoroAudiobookStudio\Logs\studio.log`.
