#!/usr/bin/env python3
"""Benchmark the full desktop process plus the real isolated Kokoro worker.

Run under Xvfb on Linux, with KAS_DATA_DIR pointing at verified q8 resources.
The script measures the UI process, its worker child, UI timer responsiveness
during generation, and objective metrics of the assembled WAV.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np
import psutil

from kokoro_studio.audio import probe_audio, read_wav
from kokoro_studio.config import load_settings, save_settings
from kokoro_studio.models import NarrationSettings
from kokoro_studio.paths import data_root
from kokoro_studio.resources import ResourceManager
from kokoro_studio.storage import Storage
from kokoro_studio.ui.app_window import AppWindow


def prepare_project() -> str:
    settings = load_settings(force=True)
    settings.setup_complete = True
    settings.offline_mode = True
    settings.low_memory_mode = True
    settings.threads = 1
    settings.provider = "cpu"
    settings.model_id = "q8"
    settings.output_format = "wav"
    settings.narration = NarrationSettings(
        default_voice="af_heart", speed=1.0, chunk_target_chars=1000,
        chunk_max_chars=1200, trim_silence=False,
    )
    save_settings(settings)
    storage = Storage()
    text = (
        "Welcome to the local audiobook benchmark. The station clock chimed at seven.\n\n"
        "Maya lifted the lantern and walked carefully along the empty platform.\n\n"
        "This sentence confirms that the complete desktop application remains responsive during real speech generation."
    )
    project = storage.create_project("Full app benchmark", settings=settings.narration,
                                     chapters=[{"title": "Benchmark chapter", "text": text}])
    settings.last_project_id = project.id
    save_settings(settings)
    return project.id


def process_tree_rss_mb() -> tuple[float, float]:
    p = psutil.Process()
    ui = p.memory_info().rss
    # Direct worker child only; recursive /proc scans can stall the Tk timer.
    children = sum(child.memory_info().rss for child in p.children(recursive=False))
    return ui / 1048576, (ui + children) / 1048576


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(ROOT / "reports" / "full_app_benchmark.json"))
    parser.add_argument("--timeout", type=float, default=180)
    args = parser.parse_args()
    verification = ResourceManager().verify_resources("q8")
    if not verification.ok:
        print(json.dumps({"ok": False, "reason": "q8 resources not verified", "checks": verification.to_dict()}, indent=2))
        return 2
    project_id = prepare_project()
    started = time.perf_counter()
    app = AppWindow(headless=True, skip_setup=True)
    app.update()
    app_startup_seconds = time.perf_counter() - started
    ui_rss, total_rss = process_tree_rss_mb()
    measurements = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "platform": f"{os.name} / {os.uname().sysname} {os.uname().release}",
        "python": sys.version.split()[0],
        "app_startup_seconds": round(app_startup_seconds, 3),
        "data_root": str(data_root()),
        "ui_rss_start_mb": round(ui_rss, 1),
        "process_tree_rss_start_mb": round(total_rss, 1),
        "peak_ui_rss_mb": round(ui_rss, 1),
        "peak_process_tree_rss_mb": round(total_rss, 1),
        "min_available_memory_mb": round(psutil.virtual_memory().available / 1048576, 1),
        "worker_info": {},
        "timer_callback_delays_ms": [],
        "samples": [],
    }
    generation_started = 0.0
    generation_finished = 0.0
    expected_ticks = 0
    ui_timer_base = 0.0

    def sample() -> None:
        nonlocal expected_ticks, generation_finished
        ui_rss, total_rss = process_tree_rss_mb()
        status = app.ctx.controller.snapshot()
        measurements["peak_ui_rss_mb"] = max(measurements["peak_ui_rss_mb"], round(ui_rss, 1))
        measurements["peak_process_tree_rss_mb"] = max(measurements["peak_process_tree_rss_mb"], round(total_rss, 1))
        measurements["min_available_memory_mb"] = min(measurements["min_available_memory_mb"],
                                                       round(psutil.virtual_memory().available / 1048576, 1))
        engine = app.ctx.controller._engine
        if engine and getattr(engine, "ready_info", None) and not measurements["worker_info"]:
            measurements["worker_info"] = engine.ready_info
        measurements["samples"].append({
            "t": round(time.monotonic() - started, 2),
            "state": status.state, "completed": status.completed,
            "ui_rss_mb": round(ui_rss, 1), "total_rss_mb": round(total_rss, 1),
            "worker_rss_mb": round(status.worker_rss_mb, 1),
            "available_mb": round(psutil.virtual_memory().available / 1048576, 1),
        })
        if status.state in {"completed", "failed", "cancelled"} and generation_started and not generation_finished:
            generation_finished = time.monotonic()
            app.after(500, finish)
            return
        if time.monotonic() - started > args.timeout:
            app.ctx.controller.cancel()
            app.after(500, finish)
            return
        expected_ticks += 1
        app.after(250, sample)

    def ui_timer() -> None:
        nonlocal ui_timer_base
        now = time.monotonic()
        if not ui_timer_base:
            ui_timer_base = now
        index = len(measurements["timer_callback_delays_ms"])
        expected_elapsed = 0.1 * index
        delay_ms = max(0.0, now - ui_timer_base - expected_elapsed) * 1000
        measurements["timer_callback_delays_ms"].append(round(delay_ms, 2))
        if index + 1 < 200 and not generation_finished:
            app.after(100, ui_timer)

    def start_generation() -> None:
        nonlocal generation_started
        generation_started = time.monotonic()
        app.ctx.controller.start(project_id, auto_export=True)

    def finish() -> None:
        status = app.ctx.controller.snapshot()
        stats = Storage().project_stats(project_id)
        export_path = status.exports[0] if status.exports else ""
        audio_metrics = {}
        if export_path and Path(export_path).is_file():
            samples = read_wav(export_path)
            audio_metrics = {
                "duration_seconds": len(samples) / 24000,
                "peak": float(np.max(np.abs(samples))),
                "rms": float(np.sqrt(np.mean(samples ** 2))),
                "dc_offset": float(np.mean(samples)),
                "clipped_samples": int(np.sum(np.abs(samples) >= 0.999)),
                "file_size": Path(export_path).stat().st_size,
                "probe": probe_audio(export_path),
            }
        measurements.update({
            "ok": status.state == "completed" and bool(audio_metrics),
            "final_state": status.state,
            "message": status.message,
            "error": status.error,
            "total_runtime_seconds": round(time.perf_counter() - started, 3),
            "generation_wall_seconds": round((generation_finished or time.monotonic()) - generation_started, 3),
            "chunks_total": status.total,
            "chunks_completed": status.completed,
            "project_stats": stats,
            "export_path": export_path,
            "audio_metrics": audio_metrics,
        })
        if audio_metrics and audio_metrics["duration_seconds"]:
            measurements["wall_clock_rtf"] = round(measurements["generation_wall_seconds"] / audio_metrics["duration_seconds"], 4)
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(measurements, indent=2), encoding="utf-8")
        print(json.dumps({k: measurements[k] for k in (
            "ok", "final_state", "ui_rss_start_mb", "peak_ui_rss_mb", "peak_process_tree_rss_mb",
            "min_available_memory_mb", "generation_wall_seconds", "chunks_completed", "audio_metrics")}, indent=2))
        try:
            if app.ctx.controller._thread and app.ctx.controller._thread.is_alive():
                app.ctx.controller.cancel()
                app.ctx.controller._thread.join(timeout=5)
        except Exception:
            pass
        app._destroy()

    app.after(1000, start_generation)
    app.after(1100, sample)
    app.after(1200, ui_timer)
    app.mainloop()
    return 0 if measurements.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
