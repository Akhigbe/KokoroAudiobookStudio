# Reproducible Windows 10/11 x64 build for Kokoro Audiobook Studio.
# Build-host prerequisites: CPython 3.12 x64, Inno Setup 6, and internet access
# only during `pip install` of pinned wheels.  End users receive a self-contained
# installer/portable build and need none of these tools.
param(
    [string]$Version = "0.1.0",
    [switch]$SkipInstaller,
    [switch]$SkipTests
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$Src = Join-Path $Root "src"
$Build = Join-Path $Root "build"
$PyInstallerBuild = Join-Path $Build "pyinstaller"
$Dist = Join-Path $Root "dist"
$AppFolder = Join-Path $PyInstallerBuild "KokoroAudiobookStudio"
$Staging = Join-Path $Build "staging"
$InstallerOut = Join-Path $Dist "installer"
$PortableOut = Join-Path $Dist "portable"
$Venv = Join-Path $Build "venv-win"
$Python = Join-Path $Venv "Scripts\python.exe"

function Write-Step($message) {
    Write-Host "`n==> $message" -ForegroundColor Cyan
}

function Assert-Command($name, $message) {
    if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
        throw $message
    }
}

Write-Step "Checking build host"
$pythonVersion = & python --version 2>&1
if ($LASTEXITCODE -ne 0 -or -not ($pythonVersion -match "Python 3\.12\.")) {
    throw "CPython 3.12.x is required on PATH. Found: $pythonVersion"
}
if (-not [Environment]::Is64BitProcess) {
    throw "A 64-bit PowerShell/Python environment is required."
}
Write-Host "Using $pythonVersion on x64"

Write-Step "Preparing build directories"
foreach ($dir in @($Build, $PyInstallerBuild, $Dist, $Staging, $InstallerOut, $PortableOut)) {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
}
Get-ChildItem -Path $Staging -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Remove-Item -Path (Join-Path $Dist "*.exe") -Force -ErrorAction SilentlyContinue
Remove-Item -Path (Join-Path $Dist "*.zip") -Force -ErrorAction SilentlyContinue

Write-Step "Creating pinned build environment"
if (-not (Test-Path $Python)) {
    & python -m venv $Venv
}
& $Python -m pip install --upgrade "pip==25.2"
& $Python -m pip install --require-virtualenv -r (Join-Path $Root "requirements-windows.txt")
if ($LASTEXITCODE -ne 0) { throw "Pinned dependency installation failed." }

if (-not $SkipTests) {
    Write-Step "Running offline-safe unit tests"
    $env:PYTHONPATH = $Src
    & $Python -m pytest -q (Join-Path $Root "tests") -m "not e2e and not gui"
    if ($LASTEXITCODE -ne 0) { throw "Unit tests failed; refusing to package." }
}

Write-Step "Building one-dir executable with PyInstaller"
& $Python -m PyInstaller --noconfirm --clean --distpath $PyInstallerBuild --workpath (Join-Path $Build "pyi-work") (Join-Path $Root "scripts\kokoro_main.spec")
if ($LASTEXITCODE -ne 0) { throw "PyInstaller build failed." }
$MainExe = Join-Path $AppFolder "KokoroAudiobookStudio.exe"
if (-not (Test-Path $MainExe)) { throw "Expected executable not found: $MainExe" }
# A renamed stub in the same one-dir folder becomes the standalone setup utility.
Copy-Item -Path $MainExe -Destination (Join-Path $AppFolder "KokoroResourceSetup.exe") -Force

Write-Step "Staging user-facing files"
Copy-Item -Path (Join-Path $AppFolder "*") -Destination $Staging -Recurse -Force
foreach ($name in @("docs", "third_party_licenses", "assets\samples", "NOTICE.md", "LICENSE", "README.md", "CHANGELOG.md")) {
    $source = Join-Path $Root $name
    if (Test-Path $source) {
        $destination = Join-Path $Staging $name
        if ((Get-Item $source).PSIsContainer) {
            Copy-Item -Path $source -Destination $destination -Recurse -Force
        } else {
            Copy-Item -Path $source -Destination $destination -Force
        }
    }
}
Set-Content -Path (Join-Path $Staging "BUILD_INFO.txt") -Value @(
    "Kokoro Audiobook Studio $Version",
    "Built: $(Get-Date -Format o)",
    "Python: $pythonVersion",
    "Runtime: onnxruntime 1.22.1 CPU / kokoro-onnx 0.6.1",
    "Pinned model revision: 1939ad2a8e416c0acfeecc08a694d14ef25f2231",
    "Model and voice files are intentionally NOT bundled; the first-run wizard downloads and verifies them.",
    "Stable user data: %LOCALAPPDATA%\KokoroAudiobookStudio"
) -Encoding UTF8

Write-Step "Creating portable ZIP"
$PortableRoot = Join-Path $PortableOut "KokoroAudiobookStudio"
if (Test-Path $PortableRoot) { Remove-Item -Path $PortableRoot -Recurse -Force }
New-Item -ItemType Directory -Force -Path $PortableRoot | Out-Null
Copy-Item -Path (Join-Path $Staging "*") -Destination $PortableRoot -Recurse -Force
Set-Content -Path (Join-Path $PortableRoot "portable.txt") -Value "Portable mode: user data is stored in the Data folder beside this executable." -Encoding UTF8
Set-Content -Path (Join-Path $PortableRoot "README_PORTABLE.txt") -Value @(
    "Kokoro Audiobook Studio -- portable mode",
    "",
    "1. Keep all files together. Do not move only the .exe.",
    "2. Run KokoroAudiobookStudio.exe. KokoroResourceSetup.exe opens setup directly.",
    "3. Projects, downloads and exports are stored in the Data folder created beside the app.",
    "4. To remove the app, delete this folder. Back up the Data folder first to preserve projects."
) -Encoding UTF8
$PortableZip = Join-Path $Dist "KokoroAudiobookStudio-$Version-win64-portable.zip"
if (Test-Path $PortableZip) { Remove-Item -Path $PortableZip -Force }
Compress-Archive -Path (Join-Path $PortableRoot "*") -DestinationPath $PortableZip -CompressionLevel Optimal -Force

if (-not $SkipInstaller) {
    Write-Step "Compiling Inno Setup installer"
    $isccCommand = Get-Command iscc.exe -ErrorAction SilentlyContinue
    if ($isccCommand) {
        $isccPath = $isccCommand.Source
    } else {
        $default = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
        if (Test-Path $default) {
            $isccPath = $default
        } else {
            throw "Inno Setup 6 ISCC.exe not found. Install Inno Setup 6 or pass -SkipInstaller for a portable-only build."
        }
    }
    $iss = Join-Path $Root "installer\KokoroAudiobookStudio.iss"
    $isccArgs = @(
        "/DAppVersion=$Version",
        "/DSourceDir=$Staging",
        "/DOutputDir=$InstallerOut",
        "/O$InstallerOut",
        "/Qp",
        $iss
    )
    & $isccPath @isccArgs
    if ($LASTEXITCODE -ne 0) { throw "Inno Setup compilation failed." }
}

Write-Step "Writing SHA-256 checksums"
$artifacts = @()
$artifacts += Get-ChildItem -Path $InstallerOut -Filter "*.exe" -File -ErrorAction SilentlyContinue
$artifacts += Get-ChildItem -Path $Dist -Filter "*.zip" -File -ErrorAction SilentlyContinue
$lines = foreach ($file in $artifacts) {
    $hash = (Get-FileHash -Path $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    "$hash  $($file.Name)"
}
Set-Content -Path (Join-Path $Dist "SHA256SUMS.txt") -Value $lines -Encoding ASCII

Write-Step "Build complete"
Write-Host "Installer: $InstallerOut"
Write-Host "Portable:  $PortableZip"
Write-Host "Checksums: $(Join-Path $Dist 'SHA256SUMS.txt')"
Write-Host "IMPORTANT: run acceptance tests on a real Windows 10/11 x64 4 GB RAM machine before distributing."
