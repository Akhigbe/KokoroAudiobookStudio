#!/usr/bin/env python3
"""Fail if Windows build scripts contain non-ASCII characters.

Windows PowerShell 5.1 can misread UTF-8 .ps1 files without a BOM. A single
em dash can decode as a curly quote and break string parsing. Keep all .ps1,
.bat and .iss build files ASCII-only.
"""
from __future__ import annotations
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
EXTS = {".ps1", ".bat", ".iss"}
SKIP_DIRS = {"dist", "build", ".git", "__pycache__", ".pytest_cache", "node_modules"}
def main() -> int:
    problems = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in EXTS:
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        text = path.read_text(encoding="utf-8")
        for line_no, line in enumerate(text.splitlines(), 1):
            bad = [(ch, hex(ord(ch))) for ch in line if ord(ch) > 127]
            if bad:
                problems.append(f"{path.relative_to(ROOT)}:{line_no}: {bad}")
    if problems:
        print("Non-ASCII characters found in Windows build scripts:", file=sys.stderr)
        print("\n".join(problems), file=sys.stderr)
        return 1
    print("ASCII_OK: all .ps1/.bat/.iss build scripts are ASCII-only")
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
