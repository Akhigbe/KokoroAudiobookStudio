#!/usr/bin/env python3
"""Validate Windows build scripts for portability.

Windows PowerShell 5.1 can misread UTF-8 .ps1 files without a BOM, and some
cmdlets (for example Get-FileHash) are not available in every runner image.
Keep all .ps1, .bat and .iss build files ASCII-only and avoid banned cmdlets.
"""
from __future__ import annotations
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
EXTS = {".ps1", ".bat", ".iss"}
SKIP_DIRS = {"dist", "build", ".git", "__pycache__", ".pytest_cache", "node_modules"}
BANNED = {"Get-FileHash": "use the .NET SHA256 helper Get-Sha256Hex instead"}

def main() -> int:
    problems = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in EXTS:
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        text = path.read_text(encoding="utf-8")
        for line_no, line in enumerate(text.splitlines(), 1):
            bad_chars = [(ch, hex(ord(ch))) for ch in line if ord(ch) > 127]
            if bad_chars:
                problems.append(f"{path.relative_to(ROOT)}:{line_no}: non-ASCII {bad_chars}")
            for token, reason in BANNED.items():
                if token in line:
                    problems.append(f"{path.relative_to(ROOT)}:{line_no}: banned '{token}' - {reason}")
    if problems:
        print("Build script portability problems:", file=sys.stderr)
        print("\n".join(problems), file=sys.stderr)
        return 1
    print("BUILD_SCRIPTS_OK: ASCII-only and portable cmdlets")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
