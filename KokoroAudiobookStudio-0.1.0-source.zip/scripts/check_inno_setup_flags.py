#!/usr/bin/env python3
"""Validate Inno Setup [Files]/[Tasks]/[Run] Flags against known names."""
from __future__ import annotations
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
ISS = ROOT / "installer" / "KokoroAudiobookStudio.iss"
# Union of flags used by this installer; catches typos like 'recursedirs'.
VALID = {
    "ignoreversion", "recursesubdirs", "createallsubdirs", "unchecked",
    "nowait", "postinstall", "skipifsilent", "onlyifdoesntexist",
    "deleteafterinstall", "external", "nocompression", "noencryption",
    "overwritereadonly", "promptifolder", "restartreplace", "sharedfile",
    "uninsneveruninstall", "uninsremovereadonly", "dontcopy", "isreadme",
}

def main() -> int:
    problems = []
    for line_no, line in enumerate(ISS.read_text(encoding="utf-8").splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith(";"):
            continue
        if "Flags:" not in stripped:
            continue
        value = stripped.split("Flags:", 1)[1].split(";", 1)[0].strip()
        for flag in value.split():
            if flag.lower() not in VALID:
                problems.append(f"{ISS.relative_to(ROOT)}:{line_no}: unknown Flags value '{flag}'")
    if problems:
        print("\n".join(problems), file=sys.stderr)
        return 1
    print("INNO_FLAGS_OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
