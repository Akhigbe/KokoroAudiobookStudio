#!/usr/bin/env python3
"""Generate the bundled sample manuscript formats and sample project backup.

This script is for maintainers and packaging only; the desktop app never needs
it.  Requires python-docx and fpdf2 (development dependencies).
"""
from __future__ import annotations

import os
import re
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "assets" / "samples"
TEXT = SAMPLES / "The Lantern at Wintergate.txt"


def paragraphs() -> list[tuple[str, list[str]]]:
    content = TEXT.read_text(encoding="utf-8")
    chapters: list[tuple[str, list[str]]] = []
    current_title = "Introduction"
    current_paragraphs: list[str] = []
    for block in re.split(r"\n\s*\n", content):
        block = block.strip()
        if not block:
            continue
        if block.startswith("Chapter "):
            if current_paragraphs:
                chapters.append((current_title, current_paragraphs))
            current_title = block
            current_paragraphs = []
        elif block.startswith("The Lantern at Wintergate") or block.startswith("A sample manuscript"):
            continue
        else:
            current_paragraphs.append(block.replace("\n", " "))
    if current_paragraphs:
        chapters.append((current_title, current_paragraphs))
    return chapters


def write_markdown() -> None:
    lines = ["# The Lantern at Wintergate", "", "*A sample manuscript for Kokoro Audiobook Studio.*", ""]
    for title, blocks in paragraphs():
        lines.append(f"## {title}" if title.startswith("Chapter") else f"## {title}")
        lines.append("")
        for block in blocks:
            lines.extend([block, ""])
    (SAMPLES / "The Lantern at Wintergate.md").write_text("\n".join(lines), encoding="utf-8")


def write_docx() -> None:
    from docx import Document
    document = Document()
    document.add_heading("The Lantern at Wintergate", level=0)
    document.add_paragraph("A sample manuscript for Kokoro Audiobook Studio.")
    for title, blocks in paragraphs():
        document.add_heading(title, level=1)
        for block in blocks:
            document.add_paragraph(block)
    document.save(SAMPLES / "The Lantern at Wintergate.docx")


def pdf_safe(text: str) -> str:
    replacements = {
        "“": '"', "”": '"', "‘": "'", "’": "'",
        "—": " - ", "–": "-", "…": "...", "→": "->",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.encode("latin-1", "replace").decode("latin-1")


def write_pdf() -> None:
    from fpdf import FPDF
    from fpdf.enums import XPos, YPos
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.set_title("The Lantern at Wintergate")
    for page_index, (title, blocks) in enumerate(paragraphs()):
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 11)
        pdf.cell(0, 8, "THE LANTERN AT WINTERGATE", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
        pdf.ln(6)
        pdf.set_font("Helvetica", "B", 16)
        pdf.cell(0, 10, pdf_safe(title), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(3)
        pdf.set_font("Helvetica", size=11)
        for block in blocks:
            pdf.multi_cell(0, 6, pdf_safe(block))
            pdf.ln(2)
        pdf.set_y(-18)
        pdf.set_font("Helvetica", "I", 9)
        pdf.cell(0, 8, f"Sample manuscript · Page {page_index+1}", align="C")
    pdf.output(SAMPLES / "The Lantern at Wintergate.pdf")


def write_project_backup() -> None:
    from kokoro_studio.config import load_settings
    from kokoro_studio.importers import import_file
    from kokoro_studio.storage import Storage
    with tempfile.TemporaryDirectory() as temp:
        os.environ["KAS_DATA_DIR"] = temp
        import kokoro_studio.config as config
        config._settings = None
        storage = Storage(Path(temp) / "studio.sqlite3")
        result = import_file(TEXT)
        project = storage.create_project(
            "The Lantern at Wintergate — sample",
            chapters=[{"title": c.title, "text": c.text} for c in result.chapters],
            settings=load_settings().narration,
            source_path=str(TEXT), source_hash=result.source_hash,
            author="Kokoro Audiobook Studio sample",
        )
        storage.update_project(project.id, notes="Sample project. Generate audio locally after restoring.")
        storage.backup_project(project.id, SAMPLES / "sample_project.kasbackup")


def main() -> None:
    SAMPLES.mkdir(parents=True, exist_ok=True)
    write_markdown()
    write_docx()
    write_pdf()
    import sys
    sys.path.insert(0, str(ROOT / "src"))
    write_project_backup()
    for path in sorted(SAMPLES.iterdir()):
        if path.is_file():
            print(f"{path.name}: {path.stat().st_size} bytes")


if __name__ == "__main__":
    main()
