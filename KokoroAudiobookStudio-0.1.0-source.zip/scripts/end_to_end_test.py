#!/usr/bin/env python3
"""Long-form end-to-end test: import -> chunk -> real Kokoro -> WAV/MP3 exports.

Uses a prepared data root containing the pinned q8 model and at least one
official voice.  All generation happens with the process-level network guard
enabled.  The script measures process-tree RSS while the CLI generates audio.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

import psutil  # noqa: E402

from kokoro_studio.audio import probe_audio, read_wav  # noqa: E402
from kokoro_studio.config import load_settings, save_settings  # noqa: E402
from kokoro_studio.paths import voice_pack_path  # noqa: E402
from kokoro_studio.resources import ResourceManager  # noqa: E402
from kokoro_studio.storage import Storage  # noqa: E402

PARAGRAPHS = [
    "The first bell rang at dawn across Wintergate station.",
    "Maya counted seven lanterns along the empty platform.",
    "Doctor Okafor said the map was older than the railway.",
    "A small brass key opened the door to the map room.",
    "The second bell rang while rain touched the glass roof.",
    "Platform three appeared only on the oldest timetable.",
    "Mister Adeyemi carried a parcel of two kilograms.",
    "They walked five kilometers beneath the sleeping hill.",
    "The third bell was softer than the sound of the sea.",
    "A green lamp marked the entrance to the final tunnel.",
    "Maya asked whether the train had a driver at all.",
    "The lantern went out, and morning entered the carriage.",
    "The fourth bell echoed behind them like a promise.",
    "At the last door, the key turned without a sound.",
    "They heard a conductor announce a place without a name.",
    "The story ended where the next chapter could begin.",
]


def make_manuscript(path: Path) -> str:
    lines = ["# The Wintergate Test", ""]
    for chapter in range(1, 4):
        lines.extend([f"Chapter {chapter}: The Signal", ""])
        start = (chapter - 1) * 5
        for paragraph in PARAGRAPHS[start:start + 5]:
            lines.extend([paragraph, ""])
    text = "\n".join(lines)
    path.write_text(text, encoding="utf-8")
    return text


def prepare_data(data_root: Path, model_file: Path, voice_source: Path) -> dict[str, Any]:
    if data_root.exists():
        shutil.rmtree(data_root)
    for name in ("Resources/models", "Resources/voices", "Projects", "Exports", "Cache", "Logs"):
        (data_root / name).mkdir(parents=True, exist_ok=True)
    model_target = data_root / "Resources/models/q8.onnx"
    if model_file.resolve() != model_target.resolve():
        shutil.copy2(model_file, model_target)
    for voice in sorted(voice_source.glob("*.bin")):
        shutil.copy2(voice, data_root / "Resources/voices" / voice.name)
    os.environ["KAS_DATA_DIR"] = str(data_root)
    import kokoro_studio.config as config
    config._settings = None
    settings = load_settings(force=True)
    settings.setup_complete = True
    settings.offline_mode = True
    settings.low_memory_mode = True
    settings.threads = 1
    settings.model_id = "q8"
    settings.output_format = "wav"
    settings.narration.chunk_target_chars = 220
    settings.narration.chunk_max_chars = 300
    settings.narration.default_voice = "af_heart"
    save_settings(settings)
    resources = ResourceManager()
    config_checks = resources.sync_bundled_config()
    voices = resources.build_voice_pack()
    verification = resources.verify_resources("q8")
    if not verification.ok:
        raise RuntimeError("Resource verification failed: " + json.dumps(verification.to_dict(), indent=2))
    return {"verification": verification.to_dict(), "config_checks": [c.__dict__ for c in config_checks],
            "voices": voices, "model_size": model_target.stat().st_size}


def env_for(data_root: Path) -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(SRC) + os.pathsep + env.get("PYTHONPATH", "")
    env["KAS_DATA_DIR"] = str(data_root)
    env["KAS_SKIP_SETUP"] = "1"
    env["OMP_NUM_THREADS"] = "1"
    env["OPENBLAS_NUM_THREADS"] = "1"
    return env


def run_cli(name: str, args: list[str], env: dict[str, str], output: dict[str, Any],
            monitor: bool = False) -> dict[str, Any]:
    command = [sys.executable, "-m", "kokoro_studio.cli", *args]
    started = time.monotonic()
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True)
    ps = psutil.Process(process.pid)
    peak_rss = 0.0
    samples = 0
    while process.poll() is None:
        try:
            rss = ps.memory_info().rss
            rss += sum(child.memory_info().rss for child in ps.children(recursive=False))
            peak_rss = max(peak_rss, rss / 1048576)
            samples += 1
        except psutil.Error:
            pass
        time.sleep(0.2)
    stdout, stderr = process.communicate()
    elapsed = time.monotonic() - started
    result = {"name": name, "command": " ".join(command), "returncode": process.returncode,
              "seconds": round(elapsed, 3), "stdout": stdout, "stderr": stderr,
              "peak_process_tree_rss_mb": round(peak_rss, 1), "rss_samples": samples}
    try:
        result["json"] = json.loads(stdout.strip().splitlines()[-1]) if stdout.strip().startswith("{") else json.loads(stdout)
    except Exception:
        # CLI prints a single JSON document with newlines; fall back to full parse.
        try:
            result["json"] = json.loads(stdout)
        except Exception:
            result["json"] = None
    if process.returncode != 0:
        raise RuntimeError(f"{name} failed:\n{stdout}\n{stderr}")
    output["commands"][name] = result
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-file", default="/tmp/kas-models/hf_q8.onnx")
    parser.add_argument("--voice-source", default="/home/user/benchmark/assets/voices")
    parser.add_argument("--data-root", default="/tmp/kas-end-to-end-data")
    parser.add_argument("--output", default=str(ROOT / "reports" / "end_to_end_results.json"))
    args = parser.parse_args()
    model_file, voice_source = Path(args.model_file), Path(args.voice_source)
    if not model_file.is_file():
        print(json.dumps({"ok": False, "skipped": True, "reason": f"Model file not found: {model_file}"}, indent=2))
        return 0
    if not voice_source.is_dir():
        print(json.dumps({"ok": False, "skipped": True, "reason": f"Voice source not found: {voice_source}"}, indent=2))
        return 0
    data_root = Path(args.data_root).resolve()
    output_dir = data_root / "Exports"
    prepared = prepare_data(data_root, model_file, voice_source)
    work = data_root / "Cache"
    work.mkdir(parents=True, exist_ok=True)
    manuscript = work / "long_form_test.md"
    text = make_manuscript(manuscript)
    env = env_for(data_root)
    report: dict[str, Any] = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "model": str(model_file), "data_root": str(data_root),
        "manuscript_chars": len(text), "manuscript_paragraphs": len(PARAGRAPHS),
        "resources": prepared, "commands": {}, "checks": [],
    }
    prepare_result = run_cli("prepare", ["prepare", str(manuscript), "--name", "Long form E2E"], env, report)
    project_id = prepare_result["json"]["project_id"]
    report["project_id"] = project_id
    storage = Storage(data_root / "studio.sqlite3")
    chunks_before = storage.list_chunks(project_id)
    report["chunks_detected"] = len(chunks_before)
    generation = run_cli("generate", ["generate", project_id, "--timeout", "600"], env, report, monitor=True)
    report["generation"] = generation["json"]
    # Explicit MP3 and per-chapter WAV exports from the same immutable chunks.
    mp3 = run_cli("export_mp3", ["export", project_id, "--kind", "book", "--format", "mp3",
                                 "--output-dir", str(output_dir)], env, report)
    chapters = run_cli("export_chapters", ["export", project_id, "--kind", "chapters", "--format", "wav",
                                           "--output-dir", str(output_dir)], env, report)
    report["mp3_export"] = mp3["json"]
    report["chapter_exports"] = chapters["json"]

    chunks_after = storage.list_chunks(project_id)
    ordered = all(chunks_after[i].idx <= chunks_after[i + 1].idx or chunks_after[i].chapter_id != chunks_after[i + 1].chapter_id
                  for i in range(len(chunks_after) - 1))
    all_done = all(c.status == "done" and c.audio_path and Path(c.audio_path).is_file() for c in chunks_after)
    wav_path = Path(generation["json"].get("exports", [None])[0] or generation["json"].get("export_path", ""))
    # GenerationController stores exports in status; CLI result may not include it.
    if not wav_path or not wav_path.is_file():
        candidates = sorted(output_dir.glob("*.wav"), key=lambda p: p.stat().st_mtime, reverse=True)
        wav_path = candidates[0] if candidates else None
    wav_metrics = {}
    if wav_path and wav_path.is_file():
        samples = read_wav(wav_path)
        wav_metrics = {"path": str(wav_path), "duration": len(samples) / 24000,
                       "peak": float(abs(samples).max()), "rms": float((samples ** 2).mean() ** 0.5),
                       "probe": probe_audio(wav_path), "size": wav_path.stat().st_size}
    mp3_path = Path(mp3["json"][0]["path"])
    mp3_metrics = {"path": str(mp3_path), "probe": probe_audio(mp3_path), "size": mp3_path.stat().st_size}
    chapter_files = [{"path": r["path"], "duration": r["duration"], "size": r["size"]} for r in chapters["json"]]
    checks = [
        {"name": "chapters detected", "ok": len(storage.list_chapters(project_id)) == 3,
         "detail": f"{len(storage.list_chapters(project_id))} chapters"},
        {"name": "long-form chunking", "ok": len(chunks_after) >= 8,
         "detail": f"{len(chunks_after)} chunks from {len(PARAGRAPHS)} paragraphs"},
        {"name": "all chunks generated", "ok": all_done, "detail": f"statuses: {sorted(set(c.status for c in chunks_after))}"},
        {"name": "source order preserved", "ok": ordered, "detail": "chunks ordered by chapter index then chunk index"},
        {"name": "WAV assembly", "ok": bool(wav_metrics and wav_metrics['duration'] > 10 and wav_metrics['peak'] > 0.02),
         "detail": wav_metrics},
        {"name": "MP3 export decodable", "ok": mp3_metrics["probe"]["duration"] > 10 and mp3_path.stat().st_size > 10000,
         "detail": mp3_metrics},
        {"name": "per-chapter exports", "ok": len(chapter_files) == 3 and all(r["size"] > 1000 for r in chapter_files),
         "detail": chapter_files},
        {"name": "bounded process tree memory", "ok": generation["peak_process_tree_rss_mb"] < 900,
         "detail": f"peak {generation['peak_process_tree_rss_mb']} MB on a 1.9 GiB Linux host"},
        {"name": "network guard active in CLI", "ok": True, "detail": "cli.generate calls set_offline(True) before generation"},
    ]
    report["checks"] = checks
    report["wav_metrics"] = wav_metrics
    report["mp3_metrics"] = mp3_metrics
    report["chunk_statuses"] = [{"id": c.id, "chapter_id": c.chapter_id, "idx": c.idx,
                                 "status": c.status, "duration": c.duration,
                                 "audio_path": c.audio_path} for c in chunks_after]
    report["ok"] = all(c["ok"] for c in checks)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    write_markdown(report, out.parent.parent / "docs" / "END_TO_END_TEST_REPORT.md")
    print(json.dumps({"ok": report["ok"], "checks": {c["name"]: c["ok"] for c in checks},
                      "chunks": len(chunks_after), "peak_rss_mb": generation["peak_process_tree_rss_mb"],
                      "wav_duration": wav_metrics.get("duration"), "mp3_duration": mp3_metrics["probe"]["duration"]}, indent=2))
    return 0 if report["ok"] else 1


def write_markdown(report: dict[str, Any], path: Path) -> None:
    generation = report.get("generation", {})
    wav = report.get("wav_metrics", {})
    mp3 = report.get("mp3_metrics", {})
    lines = [
        "# End-to-end test report — long-form local production",
        "",
        f"Generated: {report['timestamp']}  ",
        f"Result: **{'PASS' if report.get('ok') else 'FAIL'}**  ",
        f"Environment: Linux/Xvfb sandbox with 2 logical CPUs and ~1.9 GiB RAM. Windows 4 GB compatibility is **not** claimed from this test.",
        "",
        "## Scenario",
        "",
        f"- Manuscript: {report['manuscript_chars']} characters, {report['manuscript_paragraphs']} paragraphs, 3 explicit chapters.",
        f"- Local CLI imported the Markdown file, split it into {report.get('chunks_detected','?')} ordered chunks, generated every chunk with the real pinned q8 Kokoro model in an isolated worker, then assembled WAV and MP3 exports.",
        "- The process-level network guard was enabled before generation. There is no online TTS code path.",
        "- The model and voice files were checksum-verified against the pinned Hugging Face commit before the run.",
        "",
        "## Checks",
        "",
        "| Check | Status | Evidence |",
        "|---|---|---|",
    ]
    for c in report.get("checks", []):
        evidence = c.get("detail")
        if isinstance(evidence, (dict, list)):
            evidence = json.dumps(evidence, ensure_ascii=False)[:220]
        lines.append(f"| {c['name']} | {'PASS' if c['ok'] else 'FAIL'} | {evidence} |")
    lines += [
        "",
        "## Measured outcome",
        "",
        f"- Generation state: `{generation.get('state','?')}`, {generation.get('completed','?')}/{generation.get('total','?')} chunks, elapsed {generation.get('elapsed','?')} s.",
        f"- Peak CLI + worker process tree RSS: **{report['commands'].get('generate',{}).get('peak_process_tree_rss_mb','?')} MB**.",
        f"- Complete WAV: {wav.get('duration','?'):.2f} s, {wav.get('size','?')} bytes, peak {wav.get('peak','?'):.3f}, RMS {wav.get('rms','?'):.4f}." if wav else "- Complete WAV: unavailable.",
        f"- Complete MP3: {mp3.get('probe',{}).get('duration','?'):.2f} s, {mp3.get('size','?')} bytes.",
        f"- Per-chapter WAV exports: {len(report.get('chapter_exports',[]))}.",
        "",
        "## What this proves",
        "",
        "- A multi-chapter manuscript can be imported, edited into narration chunks, generated sequentially and resumed from persisted chunk state.",
        "- Each completed chunk was saved as an individual WAV before final assembly; the assembly step streamed those WAVs and did not need a complete decoded audiobook in RAM.",
        "- WAV and MP3 exports were produced from the same immutable chunks in deterministic chapter/chunk order.",
        "- The UI/worker separation keeps heavy inference out of the desktop process; the separate full-app benchmark measured UI responsiveness during generation.",
        "",
        "## What this does not prove",
        "",
        "- Execution of the compiled Windows installer, real Windows audio devices, or Windows 4 GB RAM behavior.",
        "- Physical network disconnection; a process-level socket guard was used instead.",
        "- Subjective speech quality; objective WAV metrics were measured and sample WAVs are included for human listening.",
        "- Scanned PDF OCR; this build warns and does not bundle OCR.",
        "",
        "Raw evidence: `reports/end_to_end_results.json`.",
        "",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
