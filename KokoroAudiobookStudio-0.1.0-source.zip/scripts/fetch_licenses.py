#!/usr/bin/env python3
"""Refresh third-party license texts from SPDX (maintainer-only, requires network).

Generated files are committed with the source. The Windows build simply copies
third_party_licenses/ into the installation; end users need no network access.
"""
from __future__ import annotations

import shutil
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "third_party_licenses"
BASE = "https://raw.githubusercontent.com/spdx/license-list-data/main/text/"
SPDX_IDS = [
    "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "CC0-1.0",
    "GPL-2.0-or-later", "GPL-3.0-or-later", "LGPL-2.1-or-later",
    "LGPL-3.0-or-later", "MIT", "MIT-0", "MIT-CMU", "MPL-2.0",
    "PSF-2.0",
]


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for identifier in SPDX_IDS:
        url = BASE + identifier + ".txt"
        response = requests.get(url, timeout=60)
        response.raise_for_status()
        text = response.text.strip() + "\n"
        (OUT / f"{identifier}.txt").write_text(text, encoding="utf-8")
        print(f"{identifier}: {len(text)} bytes")
    # Prefer the canonical Debian GPL-3 text for this project's own LICENSE.
    system_gpl = Path("/usr/share/common-licenses/GPL-3")
    if system_gpl.exists():
        shutil.copy2(system_gpl, ROOT / "LICENSE")
    else:
        shutil.copy2(OUT / "GPL-3.0-or-later.txt", ROOT / "LICENSE")
    # PyInstaller's bootloader exception is not an SPDX standard text.
    (OUT / "PyInstaller-BOOTLOADER-EXCEPTION.txt").write_text(
        "PyInstaller is distributed under GPLv2-or-later with a bootloader exception.\n"
        "The exception permits distributing the generated executable under your own license terms;\n"
        "it does not relicense PyInstaller itself. See:\n"
        "https://pyinstaller.org/en/stable/license.html\n"
        "https://github.com/pyinstaller/pyinstaller/blob/develop/COPYING.txt\n",
        encoding="utf-8",
    )
    print(f"Wrote {len(SPDX_IDS)} SPDX texts and LICENSE.")


if __name__ == "__main__":
    main()
