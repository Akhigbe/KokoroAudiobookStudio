#!/usr/bin/env python3
"""Regenerate the pinned resource manifest from trusted upstream metadata.

Run deliberately on a connected maintainer machine.  The generated manifest is
committed with the source and used by the setup wizard.  Runtime generation
never calls this script.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "src" / "kokoro_studio" / "assets"
CONFIG_OUT = OUT / "runtime_config"
DEFAULT_REVISION = "1939ad2a8e416c0acfeecc08a694d14ef25f2231"
REPO = "onnx-community/Kokoro-82M-v1.0-ONNX"

LANGUAGES = {
    "a": ("English", "American", "en-us"), "b": ("English", "British", "en-gb"),
    "j": ("Japanese", "Japanese", "ja"), "z": ("Mandarin Chinese", "Chinese", "cmn"),
    "e": ("Spanish", "Spanish", "es"), "f": ("French", "French", "fr-fr"),
    "h": ("Hindi", "Indian", "hi"), "i": ("Italian", "Italian", "it"),
    "p": ("Portuguese", "Brazilian", "pt-br"),
}
CORE = ["af_heart", "af_bella", "am_michael", "bf_emma"]


def fetch(url: str) -> bytes:
    response = requests.get(url, timeout=60)
    response.raise_for_status()
    return response.content


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_grades(markdown: str) -> dict[str, str]:
    grades: dict[str, str] = {}
    for line in markdown.splitlines():
        match = re.match(r"^\|\s*(?:\*\*)?`?([a-z]{2}_[a-z0-9_]+)`?(?:\*\*)?\s*\|(.*)$", line)
        if not match:
            continue
        voice, rest = match.group(1), match.group(2)
        cells = [c.strip().strip("*") for c in rest.split("|")]
        grade = next((c for c in reversed(cells) if re.fullmatch(r"[A-F][+-]?", c)), "")
        if grade:
            grades[voice] = grade
    return grades


def voice_name(voice_id: str) -> str:
    parts = voice_id.split("_")
    return " ".join(p.capitalize() for p in parts[1:]) or voice_id


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--revision", default=DEFAULT_REVISION)
    args = parser.parse_args()
    revision = args.revision
    OUT.mkdir(parents=True, exist_ok=True)
    CONFIG_OUT.mkdir(parents=True, exist_ok=True)
    info = json.loads(fetch(f"https://huggingface.co/api/models/{REPO}/revision/{urllib_quote(revision)}?blobs=true"))
    blobs = {item["rfilename"]: item for item in info["siblings"]}
    grades = parse_grades(fetch(f"https://huggingface.co/hexgrad/Kokoro-82M/resolve/main/VOICES.md").decode("utf-8"))
    base = f"https://huggingface.co/{REPO}/resolve/{revision}/"

    def asset(remote: str, local: str, bundled: bool = False) -> dict:
        item = blobs[remote]
        data = fetch(base + remote) if bundled or item.get("size", 0) < 100_000 else None
        lfs = item.get("lfs") or {}
        checksum = lfs.get("sha256") or (sha256_bytes(data) if data is not None else "")
        if bundled and data is not None:
            (CONFIG_OUT / local).write_bytes(data)
        return {"name": local, "remote": remote, "url": base + remote,
                "size": int(item.get("size", len(data or b""))), "sha256": checksum,
                "bundled": bundled, "relative_path": f"config/{local}"}

    models = []
    for model_id, remote, label, note in (
        ("q8", "onnx/model_quantized.onnx", "Balanced Q8 (recommended)",
         "92.4 MB, measured lowest practical peak RSS; verified Apache-2.0 upstream."),
        ("fp32", "onnx/model.onnx", "Full precision reference",
         "325.5 MB, higher memory use; optional on computers above 4 GB RAM."),
    ):
        entry = asset(remote, f"{model_id}.onnx")
        entry.update({"id": model_id, "label": label, "note": note,
                      "relative_path": f"models/{model_id}.onnx", "recommended": model_id == "q8"})
        models.append(entry)

    config_files = [asset("config.json", "config.json", True),
                    asset("tokenizer.json", "tokenizer.json", True),
                    asset("tokenizer_config.json", "tokenizer_config.json", True)]
    # Vocabulary used by kokoro-onnx when a model graph does not embed it.
    try:
        import kokoro_onnx  # type: ignore
        vocab_source = Path(kokoro_onnx.__file__).resolve().parent / "config.json"
        vocab_data = vocab_source.read_bytes()
        (CONFIG_OUT / "kokoro_config.json").write_bytes(vocab_data)
        config_files.append({"name": "kokoro_config.json", "remote": "kokoro-onnx/config.json",
                             "url": "https://github.com/thewh1teagle/kokoro-onnx",
                             "size": len(vocab_data), "sha256": sha256_bytes(vocab_data),
                             "bundled": True, "relative_path": "config/kokoro_config.json"})
    except Exception as exc:
        print(f"WARNING: could not copy kokoro-onnx vocabulary: {exc}")

    voices = []
    for remote, item in sorted(blobs.items()):
        if not remote.startswith("voices/") or not remote.endswith(".bin"):
            continue
        voice_id = Path(remote).stem
        if voice_id == "af" or voice_id == "af":
            continue
        prefix = voice_id[:1]
        language, accent, lang_code = LANGUAGES.get(prefix, ("Multilingual", "Documented upstream", "en-us"))
        gender = "Female" if voice_id[1:2] == "f" else "Male" if voice_id[1:2] == "m" else "Unknown"
        lfs = item.get("lfs") or {}
        voices.append({
            "id": voice_id, "name": voice_name(voice_id), "language": language,
            "accent": accent, "gender": gender, "quality": grades.get(voice_id, "Not graded upstream"),
            "lang": lang_code, "core": voice_id in CORE,
            "url": base + remote, "remote": remote,
            "size": int(item.get("size", lfs.get("size", 0))), "sha256": lfs.get("sha256", ""),
            "relative_path": f"voices/{voice_id}.bin",
        })

    manifest = {
        "schema": 1,
        "app": "Kokoro Audiobook Studio",
        "resource_revision": revision,
        "source_repository": f"https://huggingface.co/{REPO}",
        "source_commit": revision,
        "license": "Apache-2.0",
        "license_url": "https://huggingface.co/hexgrad/Kokoro-82M",
        "network_policy": "Downloads occur only during first-run setup, explicit voice installation, or an explicit resource repair.",
        "default_model": "q8",
        "core_voices": CORE,
        "models": models,
        "config_files": config_files,
        "voices": voices,
        "runtime": {
            "engine": "kokoro-onnx==0.6.1",
            "onnxruntime": "1.22.1",
            "phonemizer": "phonemizer==3.4.0 + bundled espeak-ng data",
            "sample_rate": 24000,
            "max_phonemes": 510,
            "default_threads": 1,
            "low_memory_mode": True,
        },
    }
    (OUT / "resource_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUT / "voice_catalog.json").write_text(json.dumps(voices, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {OUT/'resource_manifest.json'} with {len(voices)} voices and {len(models)} model options.")


def urllib_quote(value: str) -> str:
    from urllib.parse import quote
    return quote(value, safe="")


if __name__ == "__main__":
    main()
