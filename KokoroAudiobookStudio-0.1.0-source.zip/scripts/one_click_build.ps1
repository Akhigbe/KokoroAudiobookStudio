# One-click Windows build bootstrapper.
# It installs Python 3.12 and Inno Setup 6 with winget if missing, then runs the
# pinned reproducible build. No PyInstaller/Inno Setup knowledge is required.
param(
    [switch]$SkipInstaller
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$BuildScript = Join-Path $PSScriptRoot "build_windows.ps1"

function Write-Step($message) {
    Write-Host "`n==> $message" -ForegroundColor Cyan
}

function Refresh-Path {
    $machine = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $user = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = ($machine + ";" + $user).Trim(";")
}

function Test-Python312 {
    $command = Get-Command python -ErrorAction SilentlyContinue
    if (-not $command) { return $false }
    $version = (& python --version 2>&1 | Out-String).Trim()
    return $version -match "Python 3\.12\."
}

function Ensure-Winget {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw @"
winget (App Installer) was not found.
On Windows 10/11, install 'App Installer' from the Microsoft Store, then run
ONE_CLICK_BUILD.bat again. Alternatively follow docs/BUILD_WINDOWS.md.
"@
    }
}

function Ensure-Python312 {
    if (Test-Python312) {
        Write-Host "Python 3.12 is already available: $((& python --version 2>&1 | Out-String).Trim())"
        return
    }
    Write-Step "Installing Python 3.12 x64 (build-time only)"
    Ensure-Winget
    winget install --exact --id Python.Python.3.12 --scope user --silent `
        --accept-package-agreements --accept-source-agreements
    Refresh-Path
    $localPython = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
    if (Test-Path $localPython) {
        $env:Path = (Split-Path $localPython) + ";" + $env:Path
    }
    if (-not (Test-Python312)) {
        throw "Python 3.12 installation did not become available. Close this window, reopen ONE_CLICK_BUILD.bat, or install Python 3.12 x64 manually."
    }
    Write-Host "Python 3.12 is ready."
}

function Ensure-InnoSetup {
    if ($SkipInstaller) { return }
    $iscc = Get-Command iscc.exe -ErrorAction SilentlyContinue
    $default = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
    if ($iscc -or (Test-Path $default)) {
        Write-Host "Inno Setup 6 is already available."
        return
    }
    Write-Step "Installing Inno Setup 6 (build-time only)"
    Ensure-Winget
    winget install --exact --id JRSoftware.InnoSetup --scope user --silent `
        --accept-package-agreements --accept-source-agreements
    Refresh-Path
    if (-not (Get-Command iscc.exe -ErrorAction SilentlyContinue) -and -not (Test-Path $default)) {
        throw "Inno Setup 6 installation did not become available. Reopen ONE_CLICK_BUILD.bat or install Inno Setup 6 manually."
    }
    Write-Host "Inno Setup 6 is ready."
}

Write-Step "Kokoro Audiobook Studio one-click build"
Write-Host "Source folder: $Root"
Ensure-Python312
Ensure-InnoSetup
Write-Step "Building installer and portable ZIP"
& $BuildScript -SkipInstaller:$SkipInstaller
if ($LASTEXITCODE -ne 0) { throw "Build failed with exit code $LASTEXITCODE." }

$installer = Join-Path $Root "dist\installer"
$portable = Join-Path $Root "dist"
Write-Step "Finished"
Write-Host "Installer folder: $installer"
Write-Host "Portable ZIP:     $portable"
Write-Host "Look for KokoroAudiobookStudio-0.1.0-win64-setup.exe and double-click it to install."
try {
    Start-Process explorer.exe -ArgumentList $installer
} catch {
    # Opening Explorer is a convenience only.
}
