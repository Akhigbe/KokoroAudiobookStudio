"""PyInstaller entry point. Do not run directly outside the build."""
from kokoro_studio.app import main

raise SystemExit(main())
