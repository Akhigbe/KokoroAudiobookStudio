"""Kokoro Audiobook Studio: local-first, offline-capable audiobook production."""

__version__ = "0.1.0"
APP_NAME = "Kokoro Audiobook Studio"
APP_ID = "KokoroAudiobookStudio"
