"""Application entry point and small headless UI smoke test."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from . import __version__
from .logging_setup import configure_logging
from .paths import ensure_dirs


def run_ui_self_test(output: str | None = None) -> dict:
    """Instantiate every page under a display and measure one UI timer callback."""
    from .ui.app_window import AppWindow, NAV
    import customtkinter as ctk

    ensure_dirs()
    started = time.monotonic()
    app = AppWindow(headless=True, skip_setup=True)
    app.update()
    visited: list[str] = []
    for key, label, icon, cls in NAV:
        app.show_page(key)
        app.update()
        visited.append(key)
    callbacks: list[float] = []
    base = time.monotonic()

    def mark() -> None:
        callbacks.append(time.monotonic() - base)
        if len(callbacks) < 5:
            app.after(100, mark)

    app.after(100, mark)
    app.after(1200, app._destroy)
    app.mainloop()
    result = {
        "ok": len(visited) == len(NAV) and len(callbacks) >= 4,
        "pages": visited,
        "timer_callback_delays_ms": [round(max(0, x - 0.1 * (i + 1)) * 1000, 2) for i, x in enumerate(callbacks)],
        "startup_seconds": round(time.monotonic() - started, 3),
        "appearance": ctk.get_appearance_mode(),
    }
    if output:
        path = Path(output)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="kokoro-audiobook-studio", description=__doc__)
    parser.add_argument("--version", action="version", version=f"Kokoro Audiobook Studio {__version__}")
    parser.add_argument("--engine-worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--verbose", action="store_true", help="Enable debug logging in the local log file.")
    parser.add_argument("--skip-setup", action="store_true", help="Do not open the first-run setup wizard (testing/repair only).")
    parser.add_argument("--headless", action="store_true", help="Use the null audio backend under Xvfb for smoke tests.")
    parser.add_argument("--self-test", action="store_true", help="Instantiate all pages and exit; requires a display/Xvfb.")
    parser.add_argument("--self-test-report", default="", help="Optional JSON output path for --self-test.")
    parser.add_argument("--setup-only", action="store_true", help="Open the resource setup utility instead of the main window.")
    parser.add_argument("--cli", nargs=argparse.REMAINDER, default=None,
                        help="Run headless CLI commands; all following arguments are passed to kokoro_studio.cli.")
    args = parser.parse_args(argv)
    configure_logging(args.verbose)
    ensure_dirs()
    if args.engine_worker:
        from .engine_worker import main as worker_main
        return worker_main()
    if args.cli is not None:
        from .cli import main as cli_main
        return cli_main(args.cli)
    # A renamed copy of the executable acts as the standalone setup utility.
    executable_stem = Path(sys.argv[0]).stem.lower()
    if args.setup_only or "resourcesetup" in executable_stem or "setup" in executable_stem:
        from .resource_setup import run_gui
        return run_gui()
    if args.self_test:
        result = run_ui_self_test(args.self_test_report or None)
        print(json.dumps(result, indent=2))
        return 0 if result["ok"] else 1
    try:
        from .ui.app_window import AppWindow
        app = AppWindow(headless=args.headless, skip_setup=args.skip_setup)
        app.mainloop()
        return 0
    except Exception as exc:
        if "display" in str(exc).lower() or "tk" in str(exc).lower():
            print(f"Desktop display unavailable: {exc}\nOn Windows, run the packaged executable. On Linux, use Xvfb for smoke tests.", file=sys.stderr)
        else:
            raise
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
