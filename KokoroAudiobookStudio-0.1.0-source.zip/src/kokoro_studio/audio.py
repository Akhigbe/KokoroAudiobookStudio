"""Streaming WAV/MP3 assembly. No complete audiobook waveform is held in RAM."""
from __future__ import annotations

import math
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator

import numpy as np
import soundfile as sf

SAMPLE_RATE = 24000
CHANNELS = 1
SAMPLE_WIDTH = 2
FADE_MS = 5


@dataclass
class ChunkSpec:
    path: str
    chapter_id: str
    chapter_idx: int
    chunk_idx: int
    pause_before_ms: int = 0
    chapter_transition_ms: int = 1200


class AudioAssemblyError(Exception):
    pass


def silence(seconds: float, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    return np.zeros(max(0, int(seconds * sample_rate)), dtype=np.float32)


def fade_in_place(samples: np.ndarray, fade_samples: int) -> np.ndarray:
    n = min(max(0, fade_samples), len(samples))
    if n:
        samples[:n] *= np.linspace(0.0, 1.0, n, endpoint=True, dtype=np.float32)
    return samples


def fade_out_in_place(samples: np.ndarray, fade_samples: int) -> np.ndarray:
    n = min(max(0, fade_samples), len(samples))
    if n:
        samples[-n:] *= np.linspace(1.0, 0.0, n, endpoint=True, dtype=np.float32)
    return samples


def _to_pcm16(samples: np.ndarray) -> bytes:
    clipped = np.clip(samples, -1.0, 1.0)
    return (clipped * 32767.0).astype("<i2", copy=False).tobytes()


class WavChunkWriter:
    """Write one generated chunk incrementally with click-safe outer edges."""

    def __init__(self, path: str | Path, sample_rate: int = SAMPLE_RATE, fade_ms: int = FADE_MS):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.sample_rate = sample_rate
        self.fade_samples = int(sample_rate * fade_ms / 1000)
        self.frames = 0
        self.peak = 0.0
        self._pending = np.empty(0, dtype=np.float32)
        self._first = True
        self._closed = False
        self._file = sf.SoundFile(str(self.path), mode="w", samplerate=sample_rate,
                                  channels=CHANNELS, subtype="PCM_16")

    def write(self, samples: np.ndarray) -> None:
        data = np.asarray(samples, dtype=np.float32).reshape(-1)
        if data.size == 0:
            return
        self.peak = max(self.peak, float(np.max(np.abs(data))) if data.size else 0.0)
        combined = np.concatenate((self._pending, data)) if self._pending.size else data
        if self._first and combined.size:
            fade_in_place(combined, self.fade_samples)
            self._first = False
        keep = min(self.fade_samples, combined.size)
        ready = combined[:-keep] if keep else combined
        self._pending = combined[-keep:].copy() if keep else np.empty(0, dtype=np.float32)
        if ready.size:
            self._file.write(np.clip(ready, -1.0, 1.0))
            self.frames += ready.size

    def close(self) -> dict[str, float]:
        if self._closed:
            return {"duration": self.frames / self.sample_rate, "peak": self.peak}
        if self._pending.size:
            fade_out_in_place(self._pending, self.fade_samples)
            self._file.write(np.clip(self._pending, -1.0, 1.0))
            self.frames += self._pending.size
            self._pending = np.empty(0, dtype=np.float32)
        self._file.close()
        self._closed = True
        return {"duration": self.frames / self.sample_rate, "peak": self.peak}

    def __enter__(self) -> "WavChunkWriter":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


def read_wav(path: str | Path, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    with sf.SoundFile(str(path), "r") as f:
        if f.samplerate != sample_rate:
            raise AudioAssemblyError(f"Unexpected sample rate {f.samplerate} in {path}; expected {sample_rate}.")
        if f.channels != CHANNELS:
            raise AudioAssemblyError(f"Unexpected channel count {f.channels} in {path}; expected mono.")
        return f.read(dtype="float32", always_2d=False)


def iter_wav(path: str | Path, block: int = 24000, sample_rate: int = SAMPLE_RATE) -> Iterator[np.ndarray]:
    with sf.SoundFile(str(path), "r") as f:
        if f.samplerate != sample_rate or f.channels != CHANNELS:
            raise AudioAssemblyError(f"Incompatible audio file: {path}")
        while True:
            data = f.read(block, dtype="float32", always_2d=False)
            if not len(data):
                break
            yield np.asarray(data, dtype=np.float32)


def wav_info(path: str | Path) -> dict[str, float | int]:
    info = sf.info(str(path))
    return {"duration": info.duration, "sample_rate": info.samplerate,
            "channels": info.channels, "frames": info.frames}


def probe_audio(path: str | Path) -> dict[str, float | int | str]:
    """Format-independent duration probe for generated exports."""
    try:
        import miniaudio  # type: ignore
        info = miniaudio.get_file_info(str(path))
        duration = float(info.duration)
        fmt = str(getattr(info, "file_format", "UNKNOWN"))
    except Exception:
        if str(path).lower().endswith(".wav"):
            data = wav_info(path)
            duration, fmt = float(data["duration"]), "WAV"
        else:
            duration, fmt = 0.0, "UNKNOWN"
    return {"duration": duration, "size": Path(path).stat().st_size, "format": fmt}


def validate_chunk_specs(specs: list[ChunkSpec]) -> list[str]:
    problems: list[str] = []
    if not specs:
        return ["No completed audio chunks were selected."]
    for i, spec in enumerate(specs):
        path = Path(spec.path)
        if not path.is_file() or path.stat().st_size < 44:
            problems.append(f"Chunk {i+1}: missing or empty WAV file ({path.name}).")
        elif path.suffix.lower() != ".wav":
            problems.append(f"Chunk {i+1}: expected WAV, found {path.suffix}.")
    return problems


def _chunk_samples(spec: ChunkSpec, fade_samples: int, trim_enabled: bool) -> np.ndarray:
    samples = read_wav(spec.path, SAMPLE_RATE)
    if trim_enabled:
        threshold = 0.003
        loud = np.flatnonzero(np.abs(samples) > threshold)
        if loud.size:
            samples = samples[loud[0]: loud[-1] + 1]
    fade_in_place(samples, fade_samples)
    fade_out_in_place(samples, fade_samples)
    return samples


def _assembly_arrays(specs: list[ChunkSpec], trim_enabled: bool,
                     cancel_event=None) -> Iterator[np.ndarray]:
    fade_samples = int(SAMPLE_RATE * FADE_MS / 1000)
    previous_chapter: str | None = None
    for index, spec in enumerate(specs):
        if cancel_event and cancel_event.is_set():
            raise AudioAssemblyError("Export cancelled.")
        pause_ms = spec.pause_before_ms
        if previous_chapter is not None and spec.chapter_id != previous_chapter:
            pause_ms = max(pause_ms, spec.chapter_transition_ms)
        if pause_ms:
            yield silence(pause_ms / 1000.0)
        yield _chunk_samples(spec, fade_samples, trim_enabled, normalize_audio, target_rms)
        previous_chapter = spec.chapter_id


def assemble_wav(specs: list[ChunkSpec], output_path: str | Path, *, trim_silence: bool = False,
                 progress: Callable[[int, int], None] | None = None, cancel_event=None) -> dict[str, Any]:
    problems = validate_chunk_specs(specs)
    if problems:
        raise AudioAssemblyError("; ".join(problems))
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + ".tmp.wav")
    frames = 0
    with sf.SoundFile(str(tmp), mode="w", samplerate=SAMPLE_RATE, channels=CHANNELS, subtype="PCM_16") as writer:
        for i, samples in enumerate(_assembly_arrays(specs, trim_silence, cancel_event)):
            if samples.size:
                writer.write(np.clip(samples, -1.0, 1.0))
                frames += samples.size
            if progress:
                progress(min(i + 1, len(specs)), len(specs))
    if cancel_event and cancel_event.is_set():
        tmp.unlink(missing_ok=True)
        raise AudioAssemblyError("Export cancelled.")
    tmp.replace(output)
    return {"path": str(output), "format": "wav", "duration": frames / SAMPLE_RATE,
            "size": output.stat().st_size, "chunks": len(specs)}


def assemble_mp3(specs: list[ChunkSpec], output_path: str | Path, *, bitrate: int = 128,
                 trim_silence: bool = False, progress: Callable[[int, int], None] | None = None,
                 cancel_event=None) -> dict[str, Any]:
    try:
        import lameenc  # type: ignore
    except Exception as exc:
        raise AudioAssemblyError("MP3 encoder is unavailable. Install the bundled lameenc wheel.") from exc
    problems = validate_chunk_specs(specs)
    if problems:
        raise AudioAssemblyError("; ".join(problems))
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + ".tmp.mp3")
    encoder = lameenc.Encoder()
    encoder.set_bit_rate(int(bitrate))
    encoder.set_in_sample_rate(SAMPLE_RATE)
    encoder.set_channels(CHANNELS)
    encoder.set_quality(2)  # high quality
    with tmp.open("wb") as f:
        blocks = 0
        for i, samples in enumerate(_assembly_arrays(specs, trim_silence, cancel_event)):
            if samples.size:
                f.write(encoder.encode(_to_pcm16(samples)))
                blocks += 1
            if progress:
                progress(min(i + 1, len(specs)), len(specs))
        f.write(encoder.flush())
    if cancel_event and cancel_event.is_set():
        tmp.unlink(missing_ok=True)
        raise AudioAssemblyError("Export cancelled.")
    tmp.replace(output)
    info = probe_audio(output)
    return {"path": str(output), "format": "mp3", "duration": float(info["duration"]),
            "size": output.stat().st_size, "chunks": len(specs)}


def assemble(specs: list[ChunkSpec], output_path: str | Path, output_format: str, **kwargs: Any) -> dict[str, Any]:
    options = dict(kwargs)
    if output_format.lower() == "wav":
        options.pop("bitrate", None)  # WAV is uncompressed
        return assemble_wav(specs, output_path, **options)
    if output_format.lower() == "mp3":
        return assemble_mp3(specs, output_path, **options)
    raise AudioAssemblyError(f"Unsupported output format: {output_format}")
