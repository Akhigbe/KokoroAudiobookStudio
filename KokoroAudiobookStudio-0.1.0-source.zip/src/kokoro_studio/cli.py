"""Headless CLI for import, generation, export, verification and benchmarks."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from . import __version__
from .audio import probe_audio, read_wav
from .config import load_settings
from .engine import EngineClient
from .generation import Exporter, GenerationController
from .importers import import_file
from .logging_setup import configure_logging
from .network_guard import set_offline
from .paths import cache_dir, voice_pack_path
from .resources import ResourceManager
from .storage import Storage
from .text_processing import split_narration_chunks
import numpy as np


def out(value) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False))


def cmd_prepare(args) -> int:
    result = import_file(args.source)
    storage = Storage()
    settings = load_settings().narration
    project = storage.create_project(
        args.name or Path(args.source).stem,
        chapters=[{"title": c.title, "text": c.text} for c in result.chapters],
        settings=settings, source_path=args.source, source_hash=result.source_hash,
    )
    out({"project_id": project.id, "name": project.name, "chapters": len(result.chapters),
         "warnings": result.warnings, "stats": storage.project_stats(project.id)})
    return 0


def cmd_generate(args) -> int:
    storage = Storage()
    project = storage.get_project(args.project_id)
    if not project:
        print("Project not found", file=sys.stderr)
        return 2
    set_offline(True)
    controller = GenerationController(storage, ResourceManager())
    status = controller.start(args.project_id, auto_export=not args.no_export)
    thread = controller._thread
    if thread:
        deadline = time.monotonic() + args.timeout
        while thread.is_alive() and time.monotonic() < deadline:
            time.sleep(0.5)
        if thread.is_alive():
            controller.cancel()
            thread.join(timeout=5)
    final = controller.snapshot().to_dict()
    final["stats"] = storage.project_stats(args.project_id)
    out(final)
    return 0 if final["state"] == "completed" else 1


def cmd_export(args) -> int:
    results = Exporter(Storage()).export_project(args.project_id, kind=args.kind,
                                                  output_format=args.format,
                                                  output_dir=args.output_dir)
    out(results)
    return 0


def cmd_verify(args) -> int:
    result = ResourceManager().verify_resources(args.model)
    out(result.to_dict())
    return 0 if result.ok else 1


def cmd_offline_test(args) -> int:
    set_offline(True)
    report = ResourceManager().offline_readiness_test(model_id=args.model, voice=args.voice,
                                                       play=False, mark_ready=True)
    out(report)
    return 0 if report.get("ok") else 1


def cmd_benchmark(args) -> int:
    resources = ResourceManager()
    settings = load_settings()
    set_offline(True)
    output = cache_dir() / "cli_benchmark.wav"
    text = args.text or ("Kokoro Audiobook Studio is generating this benchmark entirely on the local CPU. "
                         "The quick brown fox jumped over the lazy dog near the old station at seven forty-five.")
    client = EngineClient(model_path=str(resources.model_path(args.model or settings.model_id)),
                          voice_pack=str(voice_pack_path()), threads=args.threads,
                          provider="cpu")
    try:
        started = time.perf_counter()
        client.start()
        init_seconds = time.perf_counter() - started
        result = client.synthesize_chunk(text, str(output), voice=args.voice, speed=1.0)
        worker_rss = client.process_tree_rss_mb()
    finally:
        client.stop()
    samples = read_wav(output)
    result.update({
        "init_seconds": round(init_seconds, 3), "text_chars": len(text),
        "worker_rss_mb": round(worker_rss, 1), "audio_probe": probe_audio(output),
        "rms": float(np.sqrt(np.mean(samples ** 2))), "peak": float(np.max(np.abs(samples))),
        "output": str(output), "model": args.model or settings.model_id,
    })
    out(result)
    return 0


def cmd_info(args) -> int:
    resources = ResourceManager()
    out({"version": __version__, "settings": load_settings().to_dict(),
         "system": resources.system_info().__dict__, "offline_ready": resources.offline_ready(),
         "verification": resources.verify_resources().to_dict()})
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="kokoro-studio-cli", description="Headless Kokoro Audiobook Studio utilities")
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare", help="Import a manuscript and create a project")
    p.add_argument("source"); p.add_argument("--name")
    p.set_defaults(func=cmd_prepare)
    p = sub.add_parser("generate", help="Generate all pending chunks for a project")
    p.add_argument("project_id"); p.add_argument("--timeout", type=float, default=3600)
    p.add_argument("--no-export", action="store_true")
    p.set_defaults(func=cmd_generate)
    p = sub.add_parser("export", help="Export a project")
    p.add_argument("project_id"); p.add_argument("--kind", choices=["book", "chapters", "selected"], default="book")
    p.add_argument("--format", choices=["wav", "mp3"]); p.add_argument("--output-dir", default="")
    p.set_defaults(func=cmd_export)
    p = sub.add_parser("verify", help="Verify installed resources")
    p.add_argument("--model", default="q8"); p.set_defaults(func=cmd_verify)
    p = sub.add_parser("offline-test", help="Generate a real sample with outbound sockets blocked")
    p.add_argument("--model", default="q8"); p.add_argument("--voice", default="af_heart")
    p.set_defaults(func=cmd_offline_test)
    p = sub.add_parser("benchmark", help="Measure a real local inference")
    p.add_argument("--model", default=""); p.add_argument("--voice", default="af_heart")
    p.add_argument("--threads", type=int, default=1); p.add_argument("--text", default="")
    p.set_defaults(func=cmd_benchmark)
    p = sub.add_parser("info", help="Print local settings, system info and verification")
    p.set_defaults(func=cmd_info)
    args = parser.parse_args(argv)
    configure_logging(args.verbose)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
