"""Application settings with atomic writes and corruption recovery."""
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any

from .models import AppSettings
from .paths import ensure_dirs, settings_path

_settings: AppSettings | None = None


def load_settings(force: bool = False) -> AppSettings:
    global _settings
    if _settings is not None and not force:
        return _settings
    ensure_dirs()
    path = settings_path()
    if not path.exists():
        _settings = AppSettings()
        save_settings(_settings)
        return _settings
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        _settings = AppSettings.from_dict(data)
    except Exception:
        # Preserve the damaged file for support rather than silently discarding it.
        backup = path.with_suffix(path.suffix + ".corrupt")
        try:
            shutil.copy2(path, backup)
        except OSError:
            pass
        _settings = AppSettings()
        save_settings(_settings)
    return _settings


def save_settings(settings: AppSettings | None = None) -> None:
    global _settings
    settings = settings or _settings or AppSettings()
    ensure_dirs()
    path = settings_path()
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(settings.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)
    _settings = settings


def update_settings(**changes: Any) -> AppSettings:
    settings = load_settings()
    for key, value in changes.items():
        if hasattr(settings, key):
            setattr(settings, key, value)
    save_settings(settings)
    return settings


def update_narration(**changes: Any) -> AppSettings:
    settings = load_settings()
    for key, value in changes.items():
        if hasattr(settings.narration, key):
            setattr(settings.narration, key, value)
    save_settings(settings)
    return settings


def reset_settings() -> AppSettings:
    global _settings
    _settings = AppSettings()
    save_settings(_settings)
    return _settings


def settings_file_path() -> Path:
    return settings_path()
