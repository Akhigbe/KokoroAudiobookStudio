"""Parent-side client for the isolated Kokoro inference worker."""
from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Callable

import psutil

from .config import load_settings
from .logging_setup import get_logger
from .paths import config_resource_dir, voice_pack_path

log = get_logger(__name__)


class EngineError(RuntimeError):
    pass


def worker_command() -> tuple[list[str], dict[str, str]]:
    """Resolve the worker command for source and PyInstaller-frozen builds."""
    env = os.environ.copy()
    if getattr(sys, "frozen", False):
        return [sys.executable, "--engine-worker"], env
    package_parent = str(Path(__file__).resolve().parent.parent)
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = package_parent + (os.pathsep + existing if existing else "")
    return [sys.executable, "-m", "kokoro_studio.engine_worker"], env


class EngineClient:
    """One long-lived worker process; one synthesis request at a time."""

    def __init__(self, model_path: str, voice_pack: str | None = None,
                 threads: int | None = None, provider: str | None = None,
                 minimum_free_mb: int = 220):
        settings = load_settings()
        self.config = {
            "model_path": str(model_path),
            "voice_pack": str(voice_pack or voice_pack_path()),
            "threads": int(threads or settings.threads),
            "provider": provider or settings.provider,
            "minimum_free_mb": int(minimum_free_mb),
            "vocab_config": str(config_resource_dir() / "kokoro_config.json"),
        }
        self.process: subprocess.Popen[str] | None = None
        self.messages: queue.Queue[dict[str, Any]] = queue.Queue()
        self.voices: list[str] = []
        self.ready_info: dict[str, Any] = {}
        self._reader_threads: list[threading.Thread] = []
        self._lock = threading.RLock()
        self._last_error = ""
        self._peak_children_rss = 0

    def is_running(self) -> bool:
        return self.process is not None and self.process.poll() is None

    def start(self, timeout: float = 60.0) -> dict[str, Any]:
        with self._lock:
            if self.is_running():
                return self.ready_info
            command, env = worker_command()
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
            log.info("Starting Kokoro worker: %s", " ".join(command))
            self.messages = queue.Queue()
            self.process = subprocess.Popen(
                command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
                env=env, creationflags=creationflags,
            )
            self._start_reader(self.process.stdout, "stdout")
            self._start_reader(self.process.stderr, "stderr")
            request_id = uuid.uuid4().hex
            self._send({"cmd": "init", "id": request_id, **self.config})
            response = self._wait(lambda m: m.get("event") in {"ready", "error"} and m.get("id") == request_id,
                                  timeout=timeout)
            if not response or response.get("event") != "ready" or not response.get("ok"):
                error = response.get("error") if response else "worker did not respond"
                self._last_error = str(error)
                self.stop()
                raise EngineError(f"Could not initialize Kokoro model: {error}")
            self.voices = list(response.get("voices", []))
            self.ready_info = response
            return response

    def _start_reader(self, stream: Any, name: str) -> None:
        message_queue = self.messages

        def run() -> None:
            try:
                for line in stream:
                    line = line.rstrip("\r\n")
                    if not line:
                        continue
                    if name == "stdout":
                        try:
                            message_queue.put(json.loads(line))
                        except json.JSONDecodeError:
                            log.warning("Worker sent non-JSON line: %s", line[:200])
                    else:
                        log.debug("worker stderr: %s", line[:500])
            except Exception as exc:
                log.debug("worker %s reader ended: %s", name, exc)
            finally:
                message_queue.put({"event": "stream_closed", "stream": name})
        thread = threading.Thread(target=run, daemon=True, name=f"engine-{name}")
        thread.start()
        self._reader_threads.append(thread)

    def _send(self, message: dict[str, Any]) -> None:
        if not self.process or not self.process.stdin:
            raise EngineError("Worker process is not running.")
        self.process.stdin.write(json.dumps(message, ensure_ascii=False) + "\n")
        self.process.stdin.flush()

    def _wait(self, predicate: Callable[[dict[str, Any]], bool], timeout: float | None = None) -> dict[str, Any] | None:
        deadline = time.monotonic() + timeout if timeout else None
        pending: list[dict[str, Any]] = []
        while True:
            remaining = None if deadline is None else max(0.0, deadline - time.monotonic())
            try:
                message = self.messages.get(timeout=remaining)
            except queue.Empty:
                for item in pending:
                    self.messages.put(item)
                return None
            if predicate(message):
                for item in pending:
                    self.messages.put(item)
                return message
            if message.get("event") == "stream_closed" and not self.is_running():
                for item in pending:
                    self.messages.put(item)
                return None
            pending.append(message)

    def synthesize_chunk(self, text: str, output_path: str, *, voice: str = "af_heart",
                         speed: float = 1.0, lang: str = "en-us",
                         sentence_pause_ms: int = 320, clause_pause_ms: int = 140,
                         trim_silence: bool = False,
                         progress: Callable[[dict[str, Any]], None] | None = None,
                         timeout: float = 900.0) -> dict[str, Any]:
        self.start()
        request_id = uuid.uuid4().hex
        request = {"cmd": "synthesize", "id": request_id, "text": text,
                   "output": str(output_path), "voice": voice, "speed": speed,
                   "lang": lang, "sentence_pause_ms": sentence_pause_ms,
                   "clause_pause_ms": clause_pause_ms, "trim_silence": trim_silence}
        self._send(request)

        def done(message: dict[str, Any]) -> bool:
            return message.get("id") == request_id and message.get("event") in {"chunk_done", "error"}

        while True:
            response = self._wait(done, timeout=timeout)
            # Segment messages with this ID are consumed by the ordinary queue
            # path; forward any that were buffered before the final response.
            if response is None:
                self._last_error = "worker timed out or exited"
                self.cancel_current()
                raise EngineError(self._last_error)
            if response.get("event") == "error":
                self._last_error = response.get("error", "unknown worker error")
                raise EngineError(self._last_error)
            if response.get("event") == "chunk_done":
                self._drain_segments(request_id, progress)
                return response
        # Not reached.

    def _drain_segments(self, request_id: str, progress: Callable[[dict[str, Any]], None] | None) -> None:
        # Always drain interleaved segment messages so the queue cannot grow.
        try:
            while True:
                message = self.messages.get_nowait()
                if progress and message.get("event") == "segment" and message.get("id") == request_id:
                    progress(message)
        except queue.Empty:
            pass

    def process_tree_rss_mb(self) -> float:
        if not self.process:
            return 0.0
        try:
            parent = psutil.Process(self.process.pid)
            # Direct children are sufficient and avoids expensive recursive /proc scans.
            total = parent.memory_info().rss + sum(child.memory_info().rss for child in parent.children(recursive=False))
            self._peak_children_rss = max(self._peak_children_rss, total)
            return total / 1048576
        except psutil.Error:
            return 0.0

    def cancel_current(self) -> None:
        """Hard-cancel the current inference; completed WAVs remain on disk."""
        with self._lock:
            process = self.process
            self.process = None
            if process and process.poll() is None:
                try:
                    process.terminate()
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                except Exception:
                    pass
            self.voices = []
            self.ready_info = {}

    def stop(self) -> None:
        with self._lock:
            process = self.process
            if process and process.poll() is None:
                try:
                    if process.stdin:
                        process.stdin.write(json.dumps({"cmd": "shutdown", "id": "shutdown"}) + "\n")
                        process.stdin.flush()
                    process.wait(timeout=3)
                except Exception:
                    try:
                        process.terminate()
                        process.wait(timeout=2)
                    except Exception:
                        process.kill()
            self.process = None
            self.voices = []
            self.ready_info = {}

    def __enter__(self) -> "EngineClient":
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.stop()
