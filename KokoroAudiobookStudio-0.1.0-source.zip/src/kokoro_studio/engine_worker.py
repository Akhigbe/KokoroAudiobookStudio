"""Isolated Kokoro ONNX worker process.

The UI process never loads ONNX Runtime.  A worker owns one model session,
writes one chunk WAV incrementally, and can be terminated between chunks for
cancellation or memory recovery.  Communication is line-delimited JSON on
stdin/stdout; stderr never carries protocol data.
"""
from __future__ import annotations

# Keep native math libraries to one thread before numpy/ORT are imported.
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("ORT_DISABLE_TELEMETRY", "1")

import asyncio
import gc
import json
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import psutil

from .audio import WavChunkWriter
from .network_guard import set_offline


def emit(event: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(event, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def log(message: str) -> None:
    sys.stderr.write(message.rstrip() + "\n")
    sys.stderr.flush()


class KokoroWorker:
    def __init__(self, config: dict[str, Any]):
        import onnxruntime as ort  # type: ignore
        from kokoro_onnx import EspeakConfig, Kokoro  # type: ignore
        import espeakng_loader  # type: ignore

        self.config = config
        self.model_path = config["model_path"]
        self.voice_pack = config["voice_pack"]
        self.threads = max(1, min(4, int(config.get("threads", 1))))
        self.provider = config.get("provider", "cpu")
        self.sample_rate = 24000
        lib_path = espeakng_loader.get_library_path()
        data_path = espeakng_loader.get_data_path()
        os.environ["PHONEMIZER_ESPEAK_LIBRARY"] = lib_path

        session_options = ort.SessionOptions()
        session_options.intra_op_num_threads = self.threads
        session_options.inter_op_num_threads = 1
        session_options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        # Benchmarked on the pinned q8 model: this combination was faster and
        # had lower peak RSS than disabling the CPU arena / memory pattern.
        session_options.enable_cpu_mem_arena = True
        session_options.enable_mem_pattern = True
        session_options.log_severity_level = 3
        session_options.add_session_config_entry("session.intra_op.allow_spinning", "0")
        available = ort.get_available_providers()
        if self.provider == "directml" and "DmlExecutionProvider" in available:
            providers = ["DmlExecutionProvider", "CPUExecutionProvider"]
        else:
            providers = ["CPUExecutionProvider"]
        self.session = ort.InferenceSession(self.model_path, sess_options=session_options,
                                            providers=providers)
        espeak_config = EspeakConfig(lib_path=lib_path, data_path=data_path)
        vocab_config = config.get("vocab_config") or None
        self.kokoro = Kokoro.from_session(self.session, self.voice_pack,
                                          espeak_config=espeak_config,
                                          vocab_config=vocab_config)
        self.voices = self.kokoro.get_voices()
        self.ort_version = ort.__version__

    def memory_mb(self) -> float:
        return psutil.Process().memory_info().rss / 1048576

    def synthesize(self, request: dict[str, Any]) -> dict[str, Any]:
        request_id = request.get("id", "")
        text = (request.get("text") or "").strip()
        voice = request.get("voice") or (self.voices[0] if self.voices else "")
        output = Path(request["output"])
        if not text:
            raise ValueError("Empty narration chunk.")
        if voice not in self.voices:
            raise ValueError(f"Voice '{voice}' is not installed. Installed: {', '.join(self.voices[:8])}")
        available_mb = psutil.virtual_memory().available / 1048576
        minimum_mb = float(self.config.get("minimum_free_mb", 220))
        if available_mb < minimum_mb:
            raise MemoryError(f"Only {available_mb:.0f} MB RAM is available; pausing generation to protect the system (minimum {minimum_mb:.0f} MB).")
        output.parent.mkdir(parents=True, exist_ok=True)
        temporary = output.with_name(output.name + ".working.wav")
        temporary.unlink(missing_ok=True)
        speed = max(0.5, min(2.0, float(request.get("speed", 1.0))))
        trim = bool(request.get("trim_silence", False))
        sentence_pause = max(0.0, float(request.get("sentence_pause_ms", 320)) / 1000)
        clause_pause = max(0.0, float(request.get("clause_pause_ms", 140)) / 1000)
        lang = request.get("lang") or "en-us"
        writer = WavChunkWriter(temporary, sample_rate=self.sample_rate)
        started = time.perf_counter()
        segments = 0
        peak_rss = self.memory_mb()

        async def generate() -> None:
            nonlocal segments, peak_rss
            stream = self.kokoro.create_stream(
                text, voice=voice, speed=speed, lang=lang, is_phonemes=False,
                trim=trim, sentence_pause=sentence_pause, clause_pause=clause_pause,
            )
            try:
                async for samples, sample_rate in stream:
                    array = np.asarray(samples, dtype=np.float32).reshape(-1)
                    writer.write(array)
                    segments += 1
                    peak_rss = max(peak_rss, self.memory_mb())
                    emit({"event": "segment", "id": request_id, "index": segments,
                          "duration": writer.frames / self.sample_rate,
                          "rss_mb": round(peak_rss, 1)})
                    del array, samples
            finally:
                await stream.aclose()

        try:
            asyncio.run(generate())
            stats = writer.close()
            if not output.parent.exists():
                raise OSError("Output directory disappeared during generation.")
            os.replace(temporary, output)
            elapsed = time.perf_counter() - started
            gc.collect()
            return {
                "ok": True, "id": request_id, "path": str(output),
                "duration": stats["duration"], "size": output.stat().st_size,
                "peak": stats["peak"], "segments": segments,
                "elapsed": elapsed, "rtf": elapsed / max(stats["duration"], 0.001),
                "rss_mb": round(peak_rss, 1), "voice": voice,
                "available_mb_after": round(psutil.virtual_memory().available / 1048576, 1),
            }
        except BaseException:
            try:
                writer.close()
            except Exception:
                pass
            temporary.unlink(missing_ok=True)
            raise


def main() -> int:
    set_offline(True)  # worker has no network code and cannot make outbound calls
    worker: KokoroWorker | None = None
    emit({"event": "worker_started", "pid": os.getpid()})
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            command = request.get("cmd")
            request_id = request.get("id", "")
            if command == "init":
                started = time.perf_counter()
                worker = KokoroWorker(request)
                emit({"event": "ready", "id": request_id, "ok": True,
                      "init_seconds": round(time.perf_counter() - started, 3),
                      "voices": worker.voices, "provider": worker.session.get_providers(),
                      "onnxruntime": worker.ort_version, "rss_mb": round(worker.memory_mb(), 1)})
            elif command == "voices":
                emit({"event": "voices", "id": request_id, "voices": worker.voices if worker else []})
            elif command == "synthesize":
                if worker is None:
                    raise RuntimeError("Worker model is not initialized.")
                result = worker.synthesize(request)
                emit({"event": "chunk_done", **result})
            elif command == "shutdown":
                emit({"event": "shutdown", "id": request_id})
                break
            else:
                raise ValueError(f"Unknown command: {command}")
        except Exception as exc:
            emit({"event": "error", "id": locals().get("request_id", ""), "ok": False,
                  "error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc(limit=6)})
            log(traceback.format_exc())
    if worker is not None:
        del worker
        gc.collect()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
