"""Sequential, resumable generation queue and streaming exports."""
from __future__ import annotations

import gc
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable

import psutil

from .audio import ChunkSpec, assemble
from .config import load_settings
from .engine import EngineClient
from .logging_setup import get_logger
from .models import ExportRecord
from .paths import exports_dir, project_audio_dir, safe_filename, voice_pack_path
from .resources import ResourceManager
from .storage import Storage

log = get_logger(__name__)


@dataclass
class GenerationStatus:
    job_id: str = ""
    project_id: str = ""
    state: str = "idle"  # idle|running|paused|completed|cancelled|failed
    total: int = 0
    completed: int = 0
    current_chunk: str = ""
    message: str = "Ready"
    elapsed: float = 0.0
    memory_available_mb: float = 0.0
    worker_rss_mb: float = 0.0
    low_memory_pause: bool = False
    exports: list[str] = field(default_factory=list)
    error: str = ""

    @property
    def fraction(self) -> float:
        return self.completed / self.total if self.total else 0.0

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["fraction"] = self.fraction
        return data


class Exporter:
    """Build chapter and book exports from immutable per-chunk WAV files."""

    def __init__(self, storage: Storage | None = None):
        self.storage = storage or Storage()

    def build_specs(self, project_id: str, chapter_ids: set[str] | None = None) -> list[ChunkSpec]:
        project = self.storage.get_project(project_id)
        if not project:
            raise FileNotFoundError(f"Project not found: {project_id}")
        chapters = [c for c in self.storage.list_chapters(project_id) if c.enabled]
        if chapter_ids:
            chapters = [c for c in chapters if c.id in chapter_ids]
        chapters.sort(key=lambda c: c.idx)
        specs: list[ChunkSpec] = []
        problems: list[str] = []
        for chapter_index, chapter in enumerate(chapters):
            chunks = self.storage.list_chunks(project_id, chapter.id)
            for chunk in chunks:
                if chunk.status != "done" or not chunk.audio_path or not Path(chunk.audio_path).is_file():
                    problems.append(f"{chapter.title}, chunk {chunk.idx+1}: {chunk.status or 'missing audio'}")
                    continue
                specs.append(ChunkSpec(
                    path=chunk.audio_path, chapter_id=chapter.id, chapter_idx=chapter.idx,
                    chunk_idx=chunk.idx, pause_before_ms=chunk.pause_before_ms,
                    chapter_transition_ms=project.settings.chapter_transition_ms,
                ))
        if problems:
            raise RuntimeError("Cannot export: " + "; ".join(problems[:12]) + ("…" if len(problems) > 12 else ""))
        return specs

    def _output_dir(self, configured: str = "") -> Path:
        path = Path(configured) if configured else exports_dir()
        path.mkdir(parents=True, exist_ok=True)
        return path

    def export_project(self, project_id: str, *, kind: str = "book",
                       output_format: str | None = None, chapter_ids: set[str] | None = None,
                       output_dir: str = "", progress: Callable[[int, int], None] | None = None,
                       cancel_event: threading.Event | None = None) -> list[dict[str, Any]]:
        project = self.storage.get_project(project_id)
        if not project:
            raise FileNotFoundError(project_id)
        settings = load_settings()
        output_format = (output_format or settings.output_format or "wav").lower()
        bitrate = settings.mp3_bitrate
        out_dir = self._output_dir(output_dir or settings.output_dir)
        chapters = [c for c in self.storage.list_chapters(project_id) if c.enabled]
        if chapter_ids:
            chapters = [c for c in chapters if c.id in chapter_ids]
        chapters.sort(key=lambda c: c.idx)
        results: list[dict[str, Any]] = []
        if kind in {"book", "selected"}:
            specs = self.build_specs(project_id, chapter_ids if kind == "selected" else None)
            suffix = "selected" if kind == "selected" else "complete"
            name = f"{safe_filename(project.name)} - {suffix}.{output_format}"
            result = self._assemble(specs, out_dir / name, project_id, kind, output_format,
                                    bitrate, project.settings.trim_silence, progress, cancel_event)
            results.append(result)
        elif kind == "chapters":
            for chapter in chapters:
                completed = [c for c in self.storage.list_chunks(project_id, chapter.id)
                             if c.status == "done" and c.audio_path and Path(c.audio_path).is_file()]
                if not completed:
                    # Empty/front-matter chapters are skipped rather than
                    # producing a zero-length chapter file.
                    continue
                specs = self.build_specs(project_id, {chapter.id})
                name = f"{safe_filename(project.name)} - {chapter.idx+1:02d} {safe_filename(chapter.title)}.{output_format}"
                result = self._assemble(specs, out_dir / name, project_id, "chapter", output_format,
                                        bitrate, project.settings.trim_silence, progress, cancel_event,
                                        chapter_id=chapter.id)
                results.append(result)
        else:
            raise ValueError(f"Unknown export kind: {kind}")
        return results

    def _assemble(self, specs: list[ChunkSpec], path: Path, project_id: str, kind: str,
                  output_format: str, bitrate: int, trim_silence: bool,
                  progress: Callable[[int, int], None] | None,
                  cancel_event: threading.Event | None, chapter_id: str = "") -> dict[str, Any]:
        record = ExportRecord(id=f"exp_{uuid.uuid4().hex[:16]}", project_id=project_id,
                              kind=kind + (f":{chapter_id}" if chapter_id else ""),
                              format=output_format, path=str(path), status="running", created_at="")
        self.storage.add_export(record)
        try:
            result = assemble(specs, path, output_format, bitrate=bitrate,
                              trim_silence=trim_silence, progress=progress,
                              cancel_event=cancel_event)
            record.status = "completed"
            record.size_bytes = int(result["size"])
            record.duration = float(result["duration"])
            self.storage.add_export(record)
            self.storage.add_event("info", f"Exported {path.name}: {record.duration:.1f}s, {record.size_bytes/1048576:.1f} MB.", project_id)
            return {**result, "status": "completed", "export_id": record.id}
        except Exception as exc:
            record.status = "failed"
            self.storage.add_export(record)
            self.storage.add_event("error", f"Export failed for {path.name}: {exc}", project_id)
            raise


class GenerationController:
    """One-chunk-at-a-time queue with persistent progress and memory guard."""

    def __init__(self, storage: Storage | None = None, resources: ResourceManager | None = None,
                 engine_factory: Callable[..., Any] | None = None,
                 status_callback: Callable[[dict[str, Any]], None] | None = None):
        self.storage = storage or Storage()
        self.resources = resources or ResourceManager()
        self.engine_factory = engine_factory
        self.status_callback = status_callback
        self.status = GenerationStatus()
        self._lock = threading.RLock()
        self._thread: threading.Thread | None = None
        self._cancel_event = threading.Event()
        self._pause_event = threading.Event()
        self._pause_event.set()
        self._engine: Any = None
        self._job_started = 0.0

    # ---------- public controls ----------

    def start(self, project_id: str, chapter_ids: set[str] | None = None,
              *, auto_export: bool = True) -> GenerationStatus:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return self.snapshot()
            chunks = self.storage.pending_chunks(project_id, chapter_ids)
            if not chunks:
                unresolved = [c for c in self.storage.list_chunks(project_id)
                              if c.status == "error" and (not chapter_ids or c.chapter_id in chapter_ids)]
                if unresolved:
                    self.status = GenerationStatus(project_id=project_id, state="failed", total=len(unresolved),
                                                   completed=0, message=f"{len(unresolved)} chunk(s) exceeded the retry limit. Regenerate them from the queue.")
                else:
                    self.status = GenerationStatus(project_id=project_id, state="completed", total=0,
                                                   completed=0, message="All selected chunks are already generated.")
                self._emit()
                return self.snapshot()
            job = self.storage.create_job(project_id, "generation", len(chunks))
            self.status = GenerationStatus(job_id=job.id, project_id=project_id, state="running",
                                           total=len(chunks), completed=0, message="Starting local generation…")
            self._cancel_event.clear()
            self._pause_event.set()
            self._job_started = time.monotonic()
            self._thread = threading.Thread(target=self._run, args=(project_id, chapter_ids, auto_export),
                                            daemon=True, name="kas-generation")
            self._thread.start()
            self._emit()
            return self.snapshot()

    def pause(self) -> None:
        self._pause_event.clear()
        with self._lock:
            self.status.state = "paused"
            self.status.message = "Paused by user."
        self._emit()

    def resume(self) -> None:
        self._pause_event.set()
        with self._lock:
            if self.status.state == "paused":
                self.status.state = "running"
                self.status.message = "Resuming generation…"
        self._emit()

    def cancel(self) -> None:
        self._cancel_event.set()
        self._pause_event.set()
        with self._lock:
            self.status.message = "Cancelling after the current inference step…"
            engine = self._engine
        if engine and hasattr(engine, "cancel_current"):
            try:
                engine.cancel_current()
            except Exception:
                pass
        self._emit()

    def snapshot(self) -> GenerationStatus:
        with self._lock:
            status = GenerationStatus(**asdict(self.status))
            status.elapsed = time.monotonic() - self._job_started if self._job_started else 0.0
            return status

    def _emit(self) -> None:
        if self.status_callback:
            data = self.snapshot().to_dict()
            try:
                self.status_callback(data)
            except Exception as exc:
                log.debug("status callback failed: %s", exc)

    def _set(self, **changes: Any) -> None:
        with self._lock:
            for key, value in changes.items():
                if hasattr(self.status, key):
                    setattr(self.status, key, value)
            self.status.elapsed = time.monotonic() - self._job_started if self._job_started else 0.0
            self.status.memory_available_mb = psutil.virtual_memory().available / 1048576
            self.status.worker_rss_mb = self._engine.process_tree_rss_mb() if self._engine and hasattr(self._engine, "process_tree_rss_mb") else 0.0
        self._emit()

    # ---------- worker ----------

    def _create_engine(self) -> Any:
        if self.engine_factory:
            return self.engine_factory()
        settings = load_settings()
        model_path = self.resources.model_path(settings.model_id)
        return EngineClient(model_path=str(model_path), voice_pack=str(voice_pack_path()),
                            threads=settings.threads, provider=settings.provider,
                            minimum_free_mb=220)

    def _wait_while_paused_or_low_memory(self) -> bool:
        low_reported = False
        while not self._cancel_event.is_set():
            available = psutil.virtual_memory().available / 1048576
            low = load_settings().low_memory_mode and available < 320
            paused = not self._pause_event.is_set()
            if not paused and not low:
                if low_reported:
                    self._set(low_memory_pause=False, message="Memory recovered; resuming generation…")
                return True
            if low and not low_reported:
                self._set(low_memory_pause=True, state="paused",
                          message=f"Paused: only {available:.0f} MB RAM available. Close other applications or stop the job.")
                low_reported = True
            elif paused and not low:
                self._set(state="paused", message="Paused by user.")
            self._pause_event.wait(0.5)
            time.sleep(0.5)
        return False

    def _disk_ok(self, project_id: str, chunk: Any) -> tuple[bool, str]:
        path = project_audio_dir(project_id)
        free = psutil.disk_usage(str(path)).free
        # Conservative: ~14 spoken characters/second, 24 kHz PCM16, 25% headroom.
        estimated = max(1024 * 1024, int(len(chunk.narration_text) / 14 * 24000 * 2 * 1.25))
        if free < estimated + 100 * 1024 * 1024:
            return False, f"Only {free/1048576:.0f} MB disk space remains; at least {(estimated+100*1024*1024)/1048576:.0f} MB is required."
        return True, ""

    def _run(self, project_id: str, chapter_ids: set[str] | None, auto_export: bool) -> None:
        job_id = self.status.job_id
        engine = None
        processed_since_reload = 0
        completed = 0
        failures = 0
        try:
            self.storage.update_job(job_id, state="running", message="generation started")
            chunks = self.storage.pending_chunks(project_id, chapter_ids)
            self._set(total=len(chunks), state="running")
            for index, chunk in enumerate(chunks):
                if self._cancel_event.is_set():
                    break
                if not self._wait_while_paused_or_low_memory():
                    break
                ok, detail = self._disk_ok(project_id, chunk)
                if not ok:
                    self.storage.mark_chunk_error(chunk.id, detail, max_retries=99)
                    self._set(state="failed", error=detail, message=detail)
                    self.storage.update_job(job_id, state="failed", error=detail, finished_at="")
                    return
                chapter = self.storage.get_chapter(chunk.chapter_id)
                chapter_title = chapter.title if chapter else "Unknown chapter"
                self.storage.mark_chunk_running(chunk.id)
                self._set(current_chunk=chunk.id, state="running",
                          message=f"Chapter {chapter.idx+1 if chapter else '?'}: {chapter_title} · chunk {chunk.idx+1} of {len(self.storage.list_chunks(project_id, chapter.id)) if chapter else '?'}")
                if engine is None:
                    engine = self._create_engine()
                    with self._lock:
                        self._engine = engine
                    engine.start()
                output_path = self.storage.chunk_audio_path(chunk)
                try:
                    result = engine.synthesize_chunk(
                        chunk.narration_text, str(output_path), voice=chunk.voice,
                        speed=chunk.speed, lang=load_settings().narration.language,
                        sentence_pause_ms=load_settings().narration.sentence_pause_ms,
                        clause_pause_ms=load_settings().narration.clause_pause_ms,
                        trim_silence=load_settings().narration.trim_silence,
                    )
                    self.storage.mark_chunk_done(chunk.id, str(output_path),
                                                 float(result.get("duration", 0.0)),
                                                 int(result.get("size", output_path.stat().st_size)))
                    completed += 1
                    self._set(completed=completed,
                              message=f"Completed {completed}/{self.status.total} chunks · {chapter_title}")
                    self.storage.update_job(job_id, completed=completed,
                                            current_chunk=chunk.id, message=self.status.message)
                except Exception as exc:
                    failures += 1
                    error = f"{chapter_title}, chunk {chunk.idx+1}: {type(exc).__name__}: {exc}"
                    status = self.storage.mark_chunk_error(chunk.id, error)
                    self.storage.add_event("error", error, project_id)
                    log.warning("Chunk generation failed: %s", error)
                    self._set(message=f"Recoverable error saved; will retry ({status}): {chapter_title}, chunk {chunk.idx+1}")
                    # Release a possibly unhealthy model session before retrying.
                    if engine and hasattr(engine, "cancel_current"):
                        engine.cancel_current()
                    engine = None
                    with self._lock:
                        self._engine = None
                    time.sleep(min(5, failures))
                finally:
                    gc.collect()
                    processed_since_reload += 1
                    if load_settings().low_memory_mode and processed_since_reload >= 20 and engine:
                        # Reclaim ORT arena between bounded batches.
                        engine.stop()
                        engine = None
                        with self._lock:
                            self._engine = None
                        processed_since_reload = 0
            if self._cancel_event.is_set():
                self.storage.update_job(job_id, state="cancelled", message="cancelled by user", finished_at="")
                self._set(state="cancelled", message="Cancelled. Completed chunks are saved and will be reused.")
                return
            remaining = self.storage.pending_chunks(project_id, chapter_ids)
            if remaining:
                self.storage.update_job(job_id, state="failed", error=f"{len(remaining)} chunk(s) still need generation",
                                        message="Some chunks failed; retry the queue to continue.", finished_at="")
                self._set(state="failed", error=f"{len(remaining)} chunk(s) still need generation",
                          message="Some chunks failed. Their chapter and text are shown in the queue; retry to continue.")
                return
            exports: list[str] = []
            if auto_export:
                self._set(state="running", message="All chunks generated. Assembling the audiobook…")
                try:
                    exporter = Exporter(self.storage)
                    results = exporter.export_project(project_id, kind="book")
                    exports = [r["path"] for r in results]
                    self._set(exports=exports, message="Audiobook assembled and ready.")
                except Exception as exc:
                    self.storage.update_job(job_id, state="failed", error=f"assembly failed: {exc}", finished_at="")
                    self._set(state="failed", error=f"Audio assembly failed: {exc}",
                              message="Chunks are safe, but the final export needs to be retried.")
                    return
            self.storage.update_job(job_id, state="completed", completed=completed,
                                    message="generation completed", finished_at="")
            self._set(state="completed", completed=completed, exports=exports,
                      message="Generation complete. Completed chunks were reused where possible.")
        except Exception as exc:
            log.exception("Generation job crashed")
            self.storage.update_job(job_id, state="failed", error=str(exc), finished_at="")
            self._set(state="failed", error=str(exc), message=f"Generation stopped: {exc}")
        finally:
            if engine:
                try:
                    engine.stop()
                except Exception:
                    pass
            with self._lock:
                self._engine = None
            gc.collect()
