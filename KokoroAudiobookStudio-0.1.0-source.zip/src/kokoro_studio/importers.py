"""Local document import for TXT, Markdown, DOCX and text-based PDF files.

No manuscript leaves the machine.  Image-only PDFs are detected and reported as
requiring OCR; this low-memory build does not pretend to extract text from them.
"""
from __future__ import annotations

import hashlib
import html
import re
import zipfile
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path

from .text_processing import ChapterDraft, detect_chapters, clean_extracted_text, repeated_page_lines

SUPPORTED = {".txt", ".text", ".md", ".markdown", ".docx", ".pdf"}
MAX_IMPORT_BYTES = 100 * 1024 * 1024


class ImportFailure(Exception):
    pass


@dataclass
class ImportResult:
    chapters: list[ChapterDraft] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    source_type: str = ""
    source_hash: str = ""
    pages: int = 0
    needs_ocr: bool = False
    removed_lines: list[str] = field(default_factory=list)
    preview: str = ""


class _HTMLText(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag in {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "blockquote"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"p", "div", "li", "h1", "h2", "h3", "h4", "blockquote"}:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def validate_file(path: str | Path) -> Path:
    p = Path(path).expanduser().resolve()
    if not p.is_file():
        raise ImportFailure(f"File not found: {p}")
    if p.stat().st_size > MAX_IMPORT_BYTES:
        raise ImportFailure("The document is larger than the 100 MB local import limit.")
    suffix = p.suffix.lower()
    if suffix not in SUPPORTED:
        raise ImportFailure(f"Unsupported file type '{suffix}'. Supported: TXT, Markdown, DOCX, PDF.")
    head = p.open("rb").read(8)
    if suffix == ".docx":
        if not zipfile.is_zipfile(p):
            raise ImportFailure("The DOCX file is not a valid Office Open XML archive.")
        with zipfile.ZipFile(p) as zf:
            if "word/document.xml" not in zf.namelist():
                raise ImportFailure("The DOCX archive has no word/document.xml; it may be corrupt.")
    if suffix == ".pdf" and not head.startswith(b"%PDF-"):
        raise ImportFailure("The PDF file has no %PDF header; it may be corrupt or mislabeled.")
    return p


def read_txt(path: Path) -> str:
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise ImportFailure("Unable to decode this text file as UTF-8, CP1252 or Latin-1.")


def markdown_to_plain(text: str) -> str:
    """Preserve headings and paragraph boundaries while removing lightweight markup."""
    lines: list[str] = []
    in_code = False
    for line in text.splitlines():
        if line.strip().startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            lines.append(line)
            continue
        line = re.sub(r"!\[([^]]*)\]\([^)]*\)", r"\1", line)  # image alt text
        line = re.sub(r"\[([^]]+)\]\([^)]*\)", r"\1", line)    # link text
        line = re.sub(r"(\*\*|__)(.*?)\1", r"\2", line)
        line = re.sub(r"(\*|_)(.*?)\1", r"\2", line)
        line = re.sub(r"`([^`]+)`", r"\1", line)
        line = re.sub(r"^\s{0,3}>\s?", "", line)
        line = re.sub(r"^\s{0,3}[-*+]\s+", "", line)
        lines.append(line)
    return "\n".join(lines)


def markdown_to_html(text: str) -> str:
    try:
        import markdown  # type: ignore
        return markdown.markdown(text, extensions=["extra", "sane_lists"])
    except Exception:
        return "<pre>" + html.escape(text) + "</pre>"


def html_to_text(value: str) -> str:
    parser = _HTMLText()
    parser.feed(value)
    return re.sub(r"\n{3,}", "\n\n", "".join(parser.parts)).strip()


def read_docx(path: Path) -> str:
    try:
        from docx import Document  # type: ignore
    except Exception as exc:  # pragma: no cover - packaging error
        raise ImportFailure("The DOCX importer is unavailable in this installation.") from exc
    try:
        document = Document(str(path))
    except Exception as exc:
        raise ImportFailure(f"Could not safely read the DOCX document: {exc}") from exc
    blocks: list[str] = []
    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        if not text:
            blocks.append("")
            continue
        style = (paragraph.style.name or "").lower() if paragraph.style else ""
        if style.startswith("heading") or style.startswith("title"):
            blocks.extend(["", text, ""])
        else:
            blocks.append(text)
    # Tables are linearized; layout-sensitive tables may need manual review.
    for table in document.tables:
        blocks.append("")
        for row in table.rows:
            cells = [" ".join(cell.text.split()) for cell in row.cells]
            blocks.append(" | ".join(cells))
    return "\n".join(blocks)


def read_pdf(path: Path) -> tuple[str, ImportResult]:
    try:
        from pypdf import PdfReader  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise ImportFailure("The PDF importer is unavailable in this installation.") from exc
    try:
        reader = PdfReader(str(path))
        if reader.is_encrypted:
            try:
                reader.decrypt("")
            except Exception as exc:
                raise ImportFailure("This PDF is encrypted. Remove the password locally and try again.") from exc
        pages: list[str] = []
        for page in reader.pages:
            try:
                text = page.extract_text(extraction_mode="layout") or ""
            except TypeError:
                text = page.extract_text() or ""
            except Exception:
                text = page.extract_text() or ""
            pages.append(text)
    except ImportFailure:
        raise
    except Exception as exc:
        raise ImportFailure(f"Could not safely read the PDF: {exc}") from exc
    result = ImportResult(source_type="pdf", pages=len(pages))
    total_text = "".join(pages)
    alphanumeric = sum(c.isalnum() for c in total_text)
    if not pages or alphanumeric < max(50, len(pages) * 20):
        result.needs_ocr = True
        result.warnings.append(
            "This appears to be a scanned/image-only PDF. No accurate text extraction is possible without OCR. "
            "This 4 GB-memory build does not bundle an OCR engine; use a text-based PDF or run OCR locally before import."
        )
    removals = repeated_page_lines(pages) if len(pages) >= 3 else set()
    result.removed_lines = sorted(removals)
    cleaned_pages = [clean_extracted_text(page, removals) for page in pages]
    text = "\n\n".join(p for p in cleaned_pages if p.strip())
    if removals:
        result.warnings.append(f"Removed {len(removals)} repeated header/footer/page-number line(s). Review the preview before import.")
    result.warnings.append("PDF layout extraction is heuristic. Check quotations and page-break joins in the preview.")
    return text, result


def import_file(path: str | Path, *, clean_text: bool = True) -> ImportResult:
    p = validate_file(path)
    result = ImportResult(source_hash=_sha256_file(p))
    suffix = p.suffix.lower()
    if suffix in {".txt", ".text"}:
        text = read_txt(p)
        result.source_type = "txt"
    elif suffix in {".md", ".markdown"}:
        text = markdown_to_plain(read_txt(p))
        result.source_type = "markdown"
    elif suffix == ".docx":
        text = read_docx(p)
        result.source_type = "docx"
    elif suffix == ".pdf":
        text, pdf_result = read_pdf(p)
        result.source_type = "pdf"
        result.pages = pdf_result.pages
        result.needs_ocr = pdf_result.needs_ocr
        result.removed_lines = pdf_result.removed_lines
        result.warnings.extend(pdf_result.warnings)
    else:  # pragma: no cover
        raise ImportFailure(f"Unsupported file type: {suffix}")
    if clean_text and suffix != ".pdf":
        text = clean_extracted_text(text)
    result.chapters = detect_chapters(text)
    if not result.chapters:
        result.warnings.append("No readable text was found.")
    result.preview = "\n\n".join(f"## {c.title}\n\n{c.text[:1200]}" for c in result.chapters[:3])
    return result


def import_pasted_text(text: str, title: str = "Pasted Manuscript") -> ImportResult:
    cleaned = clean_extracted_text(text or "")
    result = ImportResult(
        source_type="paste",
        source_hash=hashlib.sha256((text or "").encode("utf-8")).hexdigest(),
        chapters=detect_chapters(cleaned, default_title=title),
        preview=cleaned[:3000],
    )
    if not cleaned.strip():
        result.warnings.append("The pasted text is empty.")
    return result
