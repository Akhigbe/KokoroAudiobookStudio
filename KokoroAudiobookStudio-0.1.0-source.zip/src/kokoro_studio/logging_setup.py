"""Local-only rotating logs; no telemetry or remote handlers."""
from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler

from .paths import ensure_dirs, logs_dir

_configured = False


def configure_logging(verbose: bool = False) -> None:
    global _configured
    if _configured:
        return
    ensure_dirs()
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    file_handler = RotatingFileHandler(logs_dir() / "studio.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)
    stream = logging.StreamHandler(sys.stderr)
    stream.setFormatter(logging.Formatter("%(levelname)s %(name)s: %(message)s"))
    root.addHandler(stream)
    _configured = True


def get_logger(name: str) -> logging.Logger:
    configure_logging()
    return logging.getLogger(name)
