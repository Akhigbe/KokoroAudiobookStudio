"""Serializable application data structures."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class NarrationSettings:
    default_voice: str = "af_heart"
    speed: float = 1.0
    sentence_pause_ms: int = 320
    clause_pause_ms: int = 140
    paragraph_pause_ms: int = 520
    chapter_transition_ms: int = 1200
    trim_silence: bool = False  # never remove natural pauses by default
    normalize_text: bool = True
    expand_abbreviations: bool = True
    expand_numbers: bool = True
    expand_dates: bool = True
    expand_currencies: bool = True
    expand_measurements: bool = True
    # User-controlled "say-as" respellings; original manuscript is never changed.
    pronunciation: dict[str, str] = field(default_factory=dict)
    chunk_target_chars: int = 210
    chunk_max_chars: int = 340
    language: str = "en-us"

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "NarrationSettings":
        data = dict(data or {})
        known = {k: data[k] for k in cls.__dataclass_fields__ if k in data}
        return cls(**known)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AppSettings:
    theme: str = "light"
    offline_mode: bool = True
    low_memory_mode: bool = True
    threads: int = 1
    output_format: str = "wav"
    mp3_bitrate: int = 128
    output_dir: str = ""
    provider: str = "cpu"
    setup_complete: bool = False
    model_id: str = "q8"
    last_project_id: str = ""
    narration: NarrationSettings = field(default_factory=NarrationSettings)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "AppSettings":
        data = dict(data or {})
        narration = NarrationSettings.from_dict(data.pop("narration", None))
        known = {k: data[k] for k in cls.__dataclass_fields__ if k in data and k != "narration"}
        return cls(narration=narration, **known)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        return data


@dataclass
class Chapter:
    id: str
    project_id: str
    idx: int
    title: str
    original_text: str = ""
    narration_text: str = ""
    voice: str = ""
    enabled: bool = True
    settings_json: str = "{}"
    created_at: str = ""
    updated_at: str = ""


@dataclass
class Chunk:
    id: str
    project_id: str
    chapter_id: str
    idx: int
    original_text: str
    narration_text: str
    text_hash: str
    settings_hash: str
    voice: str
    speed: float
    status: str = "pending"  # pending|done|error|stale|skipped
    audio_path: str = ""
    duration: float = 0.0
    size_bytes: int = 0
    tries: int = 0
    error: str = ""
    pause_before_ms: int = 0
    pause_after_ms: int = 0
    created_at: str = ""
    updated_at: str = ""


@dataclass
class Project:
    id: str
    name: str
    created_at: str
    updated_at: str
    author: str = ""
    source_path: str = ""
    source_hash: str = ""
    settings: NarrationSettings = field(default_factory=NarrationSettings)
    notes: str = ""


@dataclass
class Job:
    id: str
    project_id: str
    kind: str
    state: str = "pending"  # pending|running|paused|completed|cancelled|failed
    total: int = 0
    completed: int = 0
    current_chunk: str = ""
    message: str = ""
    started_at: str = ""
    finished_at: str = ""
    error: str = ""


@dataclass
class ExportRecord:
    id: str
    project_id: str
    kind: str
    format: str
    path: str
    status: str
    size_bytes: int = 0
    duration: float = 0.0
    created_at: str = ""


@dataclass
class VoiceInfo:
    id: str
    name: str
    language: str
    accent: str
    gender: str
    quality: str = ""
    size: int = 0
    sha256: str = ""
    installed: bool = False


@dataclass
class ResourceAsset:
    name: str
    url: str
    size: int
    sha256: str
    kind: str = "file"
    relative_path: str = ""


@dataclass
class SystemInfo:
    os: str
    architecture: str
    cpu_count: int
    total_memory_mb: float
    available_memory_mb: float
    free_disk_mb: float
    providers: list[str] = field(default_factory=list)
    directml_available: bool = False
