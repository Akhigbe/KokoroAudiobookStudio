"""A process-local network kill switch for enforced offline mode.

The application has no telemetry and no online TTS path.  When offline mode is
enabled this guard also blocks accidental outbound socket connections, while
allowing local/Unix sockets used by the desktop and loopback test servers.
It is deliberately reversible so the first-run downloader can be enabled only
while the user is explicitly setting up or adding voices.
"""
from __future__ import annotations

import ipaddress
import socket
import urllib.request
from contextlib import contextmanager
from typing import Any, Iterator


class OfflineNetworkError(RuntimeError):
    pass


class NetworkGuard:
    def __init__(self) -> None:
        self.enabled = False
        self._connect = socket.socket.connect
        self._connect_ex = socket.socket.connect_ex
        self._create_connection = socket.create_connection
        self._urlopen = urllib.request.urlopen
        self._patched_modules: list[tuple[Any, str, Any]] = []

    @staticmethod
    def _is_local(address: Any) -> bool:
        if isinstance(address, tuple):
            host = address[0] if address else ""
        else:
            host = str(address)
        if host in {"localhost", "127.0.0.1", "::1", "", "0.0.0.0"}:
            return True
        try:
            address = ipaddress.ip_address(host)
            return bool(address.is_loopback or address.is_link_local)
        except ValueError:
            return host.endswith(".local")

    def _guarded_connect(self, sock: socket.socket, address: Any) -> Any:
        if self.enabled and getattr(sock, "family", None) in (socket.AF_INET, socket.AF_INET6):
            if not self._is_local(address):
                raise OfflineNetworkError(f"Blocked outbound connection in offline mode: {address!r}")
        return self._connect(sock, address)

    def _guarded_connect_ex(self, sock: socket.socket, address: Any) -> Any:
        if self.enabled and getattr(sock, "family", None) in (socket.AF_INET, socket.AF_INET6):
            if not self._is_local(address):
                raise OfflineNetworkError(f"Blocked outbound connection in offline mode: {address!r}")
        return self._connect_ex(sock, address)

    def _guarded_create_connection(self, address: Any, *args: Any, **kwargs: Any) -> Any:
        if self.enabled and not self._is_local(address):
            raise OfflineNetworkError(f"Blocked outbound connection in offline mode: {address!r}")
        return self._create_connection(address, *args, **kwargs)

    def _guarded_urlopen(self, url: Any, *args: Any, **kwargs: Any) -> Any:
        if self.enabled:
            value = url.full_url if hasattr(url, "full_url") else str(url)
            if not value.startswith(("file:", "data:", "http://127.0.0.1", "http://localhost")):
                raise OfflineNetworkError(f"Blocked network request in offline mode: {value}")
        return self._urlopen(url, *args, **kwargs)

    def enable(self) -> None:
        if self.enabled:
            return
        self.enabled = True

        # These must be plain functions (not bound methods): Python passes the
        # socket instance as the first argument for class attributes.
        def guarded_connect(sock: socket.socket, address: Any) -> Any:
            return self._guarded_connect(sock, address)

        def guarded_connect_ex(sock: socket.socket, address: Any) -> Any:
            return self._guarded_connect_ex(sock, address)

        socket.socket.connect = guarded_connect  # type: ignore[assignment]
        socket.socket.connect_ex = guarded_connect_ex  # type: ignore[assignment]
        socket.create_connection = self._guarded_create_connection  # type: ignore[assignment]
        urllib.request.urlopen = self._guarded_urlopen  # type: ignore[assignment]
        # Patch references already imported by requests/urllib3, if loaded.
        for module_name, attr in (
            ("urllib3.util.connection", "create_connection"),
            ("urllib3.connectionpool", "connection.create_connection"),
        ):
            try:
                module = __import__(module_name, fromlist=["*"])
                target = module
                parts = attr.split(".")
                for part in parts[:-1]:
                    target = getattr(target, part)
                original = getattr(target, parts[-1])
                setattr(target, parts[-1], self._guarded_create_connection)
                self._patched_modules.append((target, parts[-1], original))
            except Exception:
                pass

    def disable(self) -> None:
        if not self.enabled:
            return
        self.enabled = False
        socket.socket.connect = self._connect  # type: ignore[assignment]
        socket.socket.connect_ex = self._connect_ex  # type: ignore[assignment]
        socket.create_connection = self._create_connection  # type: ignore[assignment]
        urllib.request.urlopen = self._urlopen  # type: ignore[assignment]
        for target, attr, original in self._patched_modules:
            try:
                setattr(target, attr, original)
            except Exception:
                pass
        self._patched_modules.clear()

    @contextmanager
    def temporary_online(self) -> Iterator[None]:
        was_enabled = self.enabled
        if was_enabled:
            self.disable()
        try:
            yield
        finally:
            if was_enabled:
                self.enable()


guard = NetworkGuard()


def set_offline(enabled: bool) -> None:
    guard.enable() if enabled else guard.disable()


def is_offline() -> bool:
    return guard.enabled
