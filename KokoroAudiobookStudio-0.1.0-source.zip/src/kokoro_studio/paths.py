"""Stable, upgrade-safe application paths.

Installed Windows layout:
  %LOCALAPPDATA%\\KokoroAudiobookStudio\\
      Resources\\   downloaded models and voices (kept across updates)
      Projects\\     SQLite metadata and per-chunk audio
      Exports\\      user-visible exports
      Logs\\, Cache\\

Portable layout: a ``portable.txt`` marker beside the executable switches the
data root to ``<app folder>\\Data``.  ``KAS_DATA_DIR`` is an explicit override
used by tests and repair tools.
"""
from __future__ import annotations

import os
import re
import sys
from pathlib import Path

from . import APP_ID


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def executable_dir() -> Path:
    return Path(sys.executable).resolve().parent


def app_root() -> Path:
    """Directory containing bundled application assets."""
    if getattr(sys, "_MEIPASS", None):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent.parent


def package_root() -> Path:
    return Path(__file__).resolve().parent


def resource_path(*parts: str) -> Path:
    return package_root().joinpath(*parts)


def portable_root() -> Path | None:
    marker = executable_dir() / "portable.txt"
    if marker.exists() and is_frozen():
        return executable_dir() / "Data"
    return None


def data_root() -> Path:
    override = os.environ.get("KAS_DATA_DIR")
    if override:
        root = Path(override).expanduser().resolve()
    elif (p := portable_root()) is not None:
        root = p
    elif os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        root = Path(base) / APP_ID
    else:
        base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
        root = Path(base) / APP_ID.lower()
    return root


def resources_dir() -> Path:
    return data_root() / "Resources"


def model_dir() -> Path:
    return resources_dir() / "models"


def voice_dir() -> Path:
    return resources_dir() / "voices"


def voice_pack_path() -> Path:
    return voice_dir() / "installed.npz"


def config_resource_dir() -> Path:
    return resources_dir() / "config"


def projects_dir() -> Path:
    return data_root() / "Projects"


def project_audio_dir(project_id: str) -> Path:
    return projects_dir() / project_id / "audio"


def exports_dir() -> Path:
    return data_root() / "Exports"


def logs_dir() -> Path:
    return data_root() / "Logs"


def cache_dir() -> Path:
    return data_root() / "Cache"


def database_path() -> Path:
    return data_root() / "studio.sqlite3"


def settings_path() -> Path:
    return data_root() / "settings.json"


def setup_report_path() -> Path:
    return data_root() / "setup-report.json"


def offline_ready_path() -> Path:
    return data_root() / "offline-ready.json"


def ensure_dirs() -> None:
    for p in (
        data_root(), resources_dir(), model_dir(), voice_dir(), config_resource_dir(),
        projects_dir(), exports_dir(), logs_dir(), cache_dir(),
    ):
        p.mkdir(parents=True, exist_ok=True)


_SAFE = re.compile(r"[^A-Za-z0-9._ -]+")


def safe_filename(name: str, max_length: int = 100) -> str:
    cleaned = _SAFE.sub("_", name).strip(" ._")
    cleaned = re.sub(r"\s+", " ", cleaned) or "untitled"
    return cleaned[:max_length]
