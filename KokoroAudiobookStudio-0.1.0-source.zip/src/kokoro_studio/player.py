"""Streaming local audio player with seek, volume, pause and review speed.

Files are decoded in small blocks; a complete book waveform is never loaded.
Review speed changes playback sample rate and therefore pitch (no time-stretch
DSP is used, keeping memory and CPU low).  Normal 1.0x playback is unaffected.
"""
from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

import numpy as np

try:
    import miniaudio  # type: ignore
except Exception:  # pragma: no cover - handled by UI
    miniaudio = None  # type: ignore


class PlayerError(RuntimeError):
    pass


class AudioPlayer:
    def __init__(self, backends: list[Any] | None = None):
        if miniaudio is None:
            raise PlayerError("miniaudio playback library is unavailable.")
        self.backends = backends
        self._lock = threading.RLock()
        self._device: Any = None
        self._stream: Any = None
        self._path: Path | None = None
        self._info: Any = None
        self._base_rate = 24000
        self._source_frame = 0
        self._pause_event = threading.Event()
        self._pause_event.set()
        self._stop_event = threading.Event()
        self._active = False
        self._finished = False
        self._volume = 1.0
        self._speed = 1.0

    @property
    def path(self) -> Path | None:
        return self._path

    @property
    def duration(self) -> float:
        return float(getattr(self._info, "duration", 0.0)) if self._info else 0.0

    @property
    def position(self) -> float:
        return self._source_frame / max(1, self._base_rate)

    @property
    def volume(self) -> float:
        return self._volume

    @property
    def speed(self) -> float:
        return self._speed

    @property
    def active(self) -> bool:
        return self._active and not self._finished

    @property
    def playing(self) -> bool:
        return self.active and self._pause_event.is_set()

    def load(self, path: str | Path) -> dict[str, Any]:
        p = Path(path)
        if not p.is_file():
            raise PlayerError(f"Audio file not found: {p}")
        try:
            info = miniaudio.get_file_info(str(p))
        except Exception as exc:
            raise PlayerError(f"Cannot decode audio file: {exc}") from exc
        with self._lock:
            self._path = p
            self._info = info
            self._base_rate = int(info.sample_rate) or 24000
            self._source_frame = 0
        return {"duration": float(info.duration), "sample_rate": self._base_rate,
                "channels": int(info.nchannels), "format": str(getattr(info, "file_format", ""))}

    def _generator(self, stream: Any):
        self._stop_event.clear()
        self._finished = False
        try:
            required = yield b""
            while not self._stop_event.is_set():
                while not self._pause_event.is_set() and not self._stop_event.is_set():
                    self._pause_event.wait(0.05)
                if self._stop_event.is_set():
                    break
                try:
                    block = stream.send(required)
                except StopIteration:
                    break
                if block is None or len(block) == 0:
                    break
                samples = np.array(block, dtype=np.float32, copy=True)
                if samples.ndim > 1:
                    samples = samples.mean(axis=1)
                samples *= np.float32(self._volume)
                np.clip(samples, -1.0, 1.0, out=samples)
                with self._lock:
                    self._source_frame += len(samples)
                required = yield samples.tobytes()
        finally:
            self._finished = True
            self._active = False

    def _start_stream(self, start_frame: int) -> None:
        with self._lock:
            if not self._path or not self._info:
                raise PlayerError("No audio file loaded.")
            self._stop_device()
            self._source_frame = max(0, min(int(start_frame), int(self._info.num_frames)))
            self._finished = False
            self._active = True
            self._stop_event.clear()
            self._pause_event.set()
            self._stream = miniaudio.stream_file(
                str(self._path), output_format=miniaudio.SampleFormat.FLOAT32,
                nchannels=1, sample_rate=self._base_rate, frames_to_read=2048,
                seek_frame=self._source_frame,
            )
            next(self._stream)
            generator = self._generator(self._stream)
            next(generator)
            kwargs: dict[str, Any] = {
                "output_format": miniaudio.SampleFormat.FLOAT32,
                "nchannels": 1,
                "sample_rate": max(8000, int(self._base_rate * self._speed)),
                "buffersize_msec": 100,
            }
            if self.backends is not None:
                kwargs["backends"] = self.backends
            self._device = miniaudio.PlaybackDevice(**kwargs)
            self._device.start(generator)

    def _stop_device(self) -> None:
        self._stop_event.set()
        self._pause_event.set()
        device, self._device = self._device, None
        stream, self._stream = self._stream, None
        if device:
            try:
                device.stop()
            except Exception:
                pass
            try:
                device.close()
            except Exception:
                pass
        if stream:
            try:
                stream.close()
            except Exception:
                pass

    def play(self, path: str | Path | None = None, start_seconds: float = 0.0) -> None:
        if path is not None:
            self.load(path)
        frame = int(max(0.0, start_seconds) * self._base_rate)
        self._start_stream(frame)

    def pause(self) -> None:
        self._pause_event.clear()

    def resume(self) -> None:
        if self.active:
            self._pause_event.set()

    def stop(self) -> None:
        with self._lock:
            self._stop_device()
            self._active = False
            self._finished = False
            self._source_frame = 0

    def seek(self, seconds: float) -> None:
        was_playing = self.playing
        frame = int(max(0.0, min(seconds, self.duration)) * self._base_rate)
        self._start_stream(frame)
        if not was_playing:
            self.pause()

    def set_volume(self, value: float) -> None:
        self._volume = max(0.0, min(1.5, float(value)))

    def set_speed(self, value: float) -> None:
        value = max(0.5, min(2.0, float(value)))
        if abs(value - self._speed) < 0.01:
            return
        was_playing = self.playing
        position = self.position
        self._speed = value
        if self.active:
            self._start_stream(int(position * self._base_rate))
            if not was_playing:
                self.pause()

    def tick(self) -> None:
        """Release the device after natural end-of-file. Call from the UI timer."""
        if self._finished and self._device is not None:
            self._stop_device()
            self._active = False

    def close(self) -> None:
        self.stop()
