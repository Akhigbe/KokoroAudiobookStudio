"""Standalone model/voice setup and verification utility.

The Windows build script produces a separate KokoroResourceSetup.exe from this
module.  CLI mode is useful for repair, benchmarking and unattended setup.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .config import load_settings
from .logging_setup import configure_logging
from .network_guard import set_offline
from .paths import ensure_dirs, setup_report_path
from .resources import ResourceManager


def print_json(value) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False))


def run_gui() -> int:
    import customtkinter as ctk
    from .ui.context import AppContext
    from .ui.setup_wizard import SetupWizard
    ctx = AppContext()
    ctx.set_offline(ctx.settings.offline_mode)
    root = ctk.CTk()
    root.withdraw()
    wizard = SetupWizard(root, ctx, on_complete=lambda: root.after(200, root.destroy))
    root.mainloop()
    return 0 if ctx.resources.offline_ready() else 1


def run_cli(args: argparse.Namespace) -> int:
    ensure_dirs()
    resources = ResourceManager()
    settings = load_settings()
    voices = [v.strip() for v in args.voices.split(",") if v.strip()] or list(resources.manifest["core_voices"])
    if args.verify:
        result = resources.verify_resources(args.model)
        print_json(result.to_dict())
        return 0 if result.ok else 1
    if args.offline_test:
        set_offline(True)
        report = resources.offline_readiness_test(model_id=args.model, voice=voices[0],
                                                   play=False, mark_ready=True)
        print_json(report)
        return 0 if report.get("ok") else 1
    if args.clear_ready:
        resources.clear_offline_ready()
        print_json({"offline_ready": False, "message": "Offline-ready marker removed."})
        return 0
    # Full download + verification + sample test.
    def progress(info):
        if not args.quiet:
            done = info.get("overall_done", info.get("bytes_done", 0))
            total = info.get("overall_total", info.get("bytes_total", 1))
            print(f"\r{info.get('name','')}: {done}/{total} bytes · {info.get('status','')}", end="", file=sys.stderr, flush=True)
    download = resources.download_selected(args.model, voices, progress=progress)
    if not args.quiet:
        print(file=sys.stderr)
    print_json(download)
    if download.get("status") not in {"downloaded", "skipped"}:
        return 1
    verification = resources.verify_resources(args.model)
    print_json(verification.to_dict())
    if not verification.ok:
        return 1
    set_offline(True)
    report = resources.offline_readiness_test(model_id=args.model, voice=voices[0],
                                               play=False, mark_ready=True)
    print_json(report)
    print(f"Setup report: {setup_report_path()}")
    return 0 if report.get("ok") else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="kokoro-resource-setup", description="Kokoro model/voice setup and offline verification")
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--gui", action="store_true", help="Open the graphical setup wizard (default).")
    parser.add_argument("--cli", action="store_true", help="Run in command-line mode; no GUI.")
    parser.add_argument("--model", default="q8", choices=["q8", "fp32"])
    parser.add_argument("--voices", default=",".join(["af_heart", "af_bella", "am_michael", "bf_emma"]),
                        help="Comma-separated upstream voice IDs.")
    parser.add_argument("--verify", action="store_true", help="Verify installed resources and exit.")
    parser.add_argument("--offline-test", action="store_true", help="Generate a real local sample with outbound sockets blocked and exit.")
    parser.add_argument("--clear-ready", action="store_true", help="Remove the Offline Ready marker for repair.")
    parser.add_argument("--quiet", action="store_true", help="Suppress per-file progress.")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args(argv)
    configure_logging(args.verbose)
    if args.cli or args.verify or args.offline_test or args.clear_ready:
        return run_cli(args)
    return run_gui()


if __name__ == "__main__":
    raise SystemExit(main())
