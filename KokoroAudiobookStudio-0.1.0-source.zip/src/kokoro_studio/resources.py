"""Pinned resource manifest, resumable downloader, verifier and offline report."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import platform
import shutil
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np
import psutil
import requests

from . import __version__
from .config import load_settings, save_settings
from .logging_setup import get_logger
from .models import ResourceAsset, SystemInfo, VoiceInfo
from .network_guard import is_offline, set_offline
from .paths import (
    config_resource_dir, data_root, ensure_dirs, model_dir, offline_ready_path,
    resource_path, resources_dir, setup_report_path, voice_dir, voice_pack_path,
)

log = get_logger(__name__)


@dataclass
class VerificationCheck:
    name: str
    ok: bool
    detail: str = ""


@dataclass
class VerificationResult:
    ok: bool
    checks: list[VerificationCheck] = field(default_factory=list)
    model_id: str = "q8"
    installed_voices: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "model_id": self.model_id,
                "installed_voices": self.installed_voices,
                "checks": [asdict(c) for c in self.checks]}


ProgressCallback = Callable[[dict[str, Any]], None]


class ResourceError(RuntimeError):
    pass


class OfflineViolation(ResourceError):
    pass


class ResourceManager:
    def __init__(self, manifest_path: Path | None = None):
        ensure_dirs()
        self.manifest_path = manifest_path or resource_path("assets", "resource_manifest.json")
        self.manifest = json.loads(self.manifest_path.read_text(encoding="utf-8"))

    # ---------- manifest helpers ----------

    @property
    def revision(self) -> str:
        return self.manifest["resource_revision"]

    def model(self, model_id: str) -> dict[str, Any]:
        for model in self.manifest["models"]:
            if model["id"] == model_id:
                return model
        raise ResourceError(f"Unknown model id: {model_id}")

    def voice(self, voice_id: str) -> dict[str, Any]:
        for voice in self.manifest["voices"]:
            if voice["id"] == voice_id:
                return voice
        raise ResourceError(f"Unknown voice id: {voice_id}")

    def voice_catalog(self) -> list[VoiceInfo]:
        installed = set(self.installed_voice_ids())
        return [VoiceInfo(
            id=v["id"], name=v["name"], language=v["language"], accent=v["accent"],
            gender=v["gender"], quality=v["quality"], size=v["size"], sha256=v["sha256"],
            installed=v["id"] in installed,
        ) for v in self.manifest["voices"]]

    def local_path(self, asset: dict[str, Any]) -> Path:
        return resources_dir() / asset["relative_path"]

    def model_path(self, model_id: str) -> Path:
        return self.local_path(self.model(model_id))

    def bundled_config_files(self) -> list[dict[str, Any]]:
        return [c for c in self.manifest["config_files"] if c.get("bundled")]

    def estimate_download(self, model_id: str, voice_ids: list[str]) -> dict[str, int]:
        model = self.model(model_id)
        voices = sum(self.voice(v)["size"] for v in voice_ids)
        download = model["size"] + voices
        # WAV chunks, voice-pack rebuild and temporary download headroom.
        return {"model": model["size"], "voices": voices, "download": download,
                "recommended_free": download + 250 * 1024 * 1024}

    # ---------- system info ----------

    def system_info(self) -> SystemInfo:
        """Describe the hardware without importing ONNX Runtime into the UI.

        Loading ORT just to enumerate providers would add native memory to the
        desktop process.  The isolated worker reports its actual providers when
        it starts; here we only detect whether an optional DirectML package is
        installed alongside the CPU runtime.
        """
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage(str(data_root()))
        directml = False
        try:
            directml = importlib.util.find_spec("onnxruntime_directml") is not None
        except Exception:
            directml = False
        providers = ["DmlExecutionProvider", "CPUExecutionProvider"] if directml else ["CPUExecutionProvider"]
        return SystemInfo(
            os=f"{platform.system()} {platform.release()} ({platform.version()})",
            architecture=f"{platform.machine()} / {platform.architecture()[0]}",
            cpu_count=psutil.cpu_count(logical=True) or 1,
            total_memory_mb=memory.total / 1048576,
            available_memory_mb=memory.available / 1048576,
            free_disk_mb=disk.free / 1048576,
            providers=providers,
            directml_available=directml,
        )

    # ---------- checksum and bundled files ----------

    @staticmethod
    def sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for block in iter(lambda: f.read(1024 * 1024), b""):
                h.update(block)
        return h.hexdigest()

    def verify_asset(self, asset: dict[str, Any], path: Path | None = None,
                     quarantine: bool = False) -> VerificationCheck:
        path = Path(path or self.local_path(asset))
        name = asset.get("name", path.name)
        if not path.is_file():
            return VerificationCheck(name, False, "missing")
        size = path.stat().st_size
        if size != int(asset["size"]):
            detail = f"size {size} does not match expected {asset['size']}"
            if quarantine:
                self._quarantine(path)
            return VerificationCheck(name, False, detail)
        digest = self.sha256_file(path)
        if digest.lower() != asset["sha256"].lower():
            detail = f"SHA-256 {digest[:12]}… does not match pinned checksum"
            if quarantine:
                self._quarantine(path)
            return VerificationCheck(name, False, detail)
        return VerificationCheck(name, True, f"verified {size} bytes, SHA-256 {digest[:12]}…")

    @staticmethod
    def _quarantine(path: Path) -> None:
        try:
            path.replace(path.with_name(path.name + ".corrupt"))
        except OSError:
            pass

    def sync_bundled_config(self) -> list[VerificationCheck]:
        checks: list[VerificationCheck] = []
        config_resource_dir().mkdir(parents=True, exist_ok=True)
        for asset in self.bundled_config_files():
            source = resource_path("assets", "runtime_config", asset["name"])
            target = config_resource_dir() / asset["name"]
            if not source.is_file():
                checks.append(VerificationCheck(asset["name"], False, "bundled file is missing"))
                continue
            if not target.is_file() or self.sha256_file(target) != asset["sha256"]:
                tmp = target.with_name(target.name + ".tmp")
                shutil.copy2(source, tmp)
                os.replace(tmp, target)
            checks.append(self.verify_asset(asset, target))
        return checks

    # ---------- resumable downloader ----------

    def download_asset(self, asset: dict[str, Any], *, progress: ProgressCallback | None = None,
                       pause_event: threading.Event | None = None,
                       cancel_event: threading.Event | None = None,
                       retries: int = 5) -> str:
        """Download with HTTP Range resume, checksum and recoverable retries.

        Returns ``complete``, ``skipped``, ``paused`` or ``cancelled``.  Partial
        state is kept in a ``.part`` file so an unexpected close can resume.
        """
        if is_offline():
            raise OfflineViolation("Offline mode is active. Turn it off explicitly before downloading resources.")
        target = self.local_path(asset)
        target.parent.mkdir(parents=True, exist_ok=True)
        existing = self.verify_asset(asset, target, quarantine=True)
        if existing.ok:
            self._report(progress, asset["name"], asset["size"], asset["size"], "verified")
            return "skipped"
        part = target.with_name(target.name + ".part")
        last_error: Exception | None = None
        for attempt in range(retries):
            if cancel_event and cancel_event.is_set():
                return "cancelled"
            if pause_event and not pause_event.is_set():
                return "paused"
            offset = part.stat().st_size if part.is_file() else 0
            if offset > int(asset["size"]):
                part.unlink(missing_ok=True)
                offset = 0
            headers = {"Range": f"bytes={offset}-"} if offset else {}
            digest = hashlib.sha256()
            if offset and part.is_file():
                with part.open("rb") as f:
                    for block in iter(lambda: f.read(1024 * 1024), b""):
                        digest.update(block)
            try:
                self._report(progress, asset["name"], offset, asset["size"],
                             f"connecting (attempt {attempt+1}/{retries})")
                response = requests.get(asset["url"], headers=headers, stream=True,
                                        timeout=(15, 90), allow_redirects=True)
                if response.status_code == 416 and part.is_file():
                    # Server says the range is complete; verify what we have.
                    response.close()
                    return self._finish_part(asset, part, target, digest, progress)
                if response.status_code not in (200, 206):
                    raise ResourceError(f"HTTP {response.status_code} downloading {asset['name']}")
                if offset and response.status_code == 200:
                    # Server ignored Range; restart cleanly.
                    part.unlink(missing_ok=True)
                    offset = 0
                    digest = hashlib.sha256()
                mode = "ab" if response.status_code == 206 and offset else "wb"
                with response, part.open(mode) as f:
                    for chunk in response.iter_content(1024 * 1024):
                        if not chunk:
                            continue
                        if cancel_event and cancel_event.is_set():
                            return "cancelled"
                        if pause_event and not pause_event.is_set():
                            return "paused"
                        f.write(chunk)
                        digest.update(chunk)
                        offset += len(chunk)
                        self._report(progress, asset["name"], offset, asset["size"], "downloading")
                return self._finish_part(asset, part, target, digest, progress)
            except (requests.RequestException, OSError, ResourceError) as exc:
                last_error = exc
                self._report(progress, asset["name"], offset, asset["size"],
                             f"retrying after error: {type(exc).__name__}")
                if attempt + 1 < retries:
                    time.sleep(min(8, 2 ** attempt))
        raise ResourceError(f"Download failed after {retries} attempts: {last_error}")

    @staticmethod
    def _report(progress: ProgressCallback | None, name: str, done: int, total: int, status: str) -> None:
        if progress:
            progress({"name": name, "bytes_done": done, "bytes_total": total, "status": status})

    def _finish_part(self, asset: dict[str, Any], part: Path, target: Path,
                     digest: "hashlib._Hash", progress: ProgressCallback | None) -> str:
        if not part.is_file():
            raise ResourceError(f"Partial download disappeared for {asset['name']}")
        if part.stat().st_size != int(asset["size"]):
            self._report(progress, asset["name"], part.stat().st_size, asset["size"], "incomplete; will resume")
            return "paused"
        actual = digest.hexdigest()
        if actual.lower() != asset["sha256"].lower():
            self._quarantine(part)
            raise ResourceError(f"Checksum mismatch for {asset['name']}: {actual[:12]}…")
        tmp = target.with_name(target.name + ".verified")
        os.replace(part, tmp)
        os.replace(tmp, target)
        self._report(progress, asset["name"], asset["size"], asset["size"], "verified")
        return "complete"

    def download_selected(self, model_id: str, voice_ids: list[str], *,
                          progress: ProgressCallback | None = None,
                          pause_event: threading.Event | None = None,
                          cancel_event: threading.Event | None = None) -> dict[str, Any]:
        set_offline(False)
        results: list[dict[str, Any]] = []
        config_checks = self.sync_bundled_config()
        results.extend({"name": c.name, "result": "bundled" if c.ok else f"error: {c.detail}"}
                       for c in config_checks)
        if not all(c.ok for c in config_checks):
            return {"status": "config_error", "files": results, "model_id": model_id, "voices": voice_ids}
        assets: list[dict[str, Any]] = [self.model(model_id)] + [self.voice(v) for v in voice_ids]
        total = sum(a["size"] for a in assets)
        done = 0
        for asset in assets:
            def per_file(info: dict[str, Any]) -> None:
                if progress:
                    progress({**info, "overall_done": done + info["bytes_done"], "overall_total": total})
            result = self.download_asset(asset, progress=per_file, pause_event=pause_event,
                                         cancel_event=cancel_event)
            if result in {"paused", "cancelled"}:
                return {"status": result, "files": results, "model_id": model_id, "voices": voice_ids}
            results.append({"name": asset["name"], "result": result, "size": asset["size"],
                            "sha256": asset["sha256"]})
            done += asset["size"]
        pack = self.build_voice_pack(voice_ids)
        results.append({"name": "installed.npz", "result": f"built with {len(pack)} voices"})
        return {"status": "downloaded", "files": results, "model_id": model_id,
                "voices": voice_ids, "voice_pack": str(voice_pack_path())}

    def install_voice(self, voice_id: str, **kwargs: Any) -> dict[str, Any]:
        asset = self.voice(voice_id)
        result = self.download_asset(asset, **kwargs)
        if result == "complete" or result == "skipped":
            voices = self.build_voice_pack()
            return {"status": "installed", "voice": voice_id, "voices": voices}
        return {"status": result, "voice": voice_id}

    # ---------- voice pack ----------

    def installed_voice_ids(self) -> list[str]:
        pack = voice_pack_path()
        if pack.is_file():
            try:
                with np.load(str(pack)) as data:
                    return sorted(data.files)
            except Exception:
                pass
        return sorted(p.stem for p in voice_dir().glob("*.bin") if p.is_file())

    def build_voice_pack(self, voice_ids: list[str] | None = None) -> list[str]:
        voice_dir().mkdir(parents=True, exist_ok=True)
        if voice_ids:
            candidates = [voice_dir() / f"{v}.bin" for v in voice_ids]
        else:
            candidates = sorted(voice_dir().glob("*.bin"))
        voices: dict[str, np.ndarray] = {}
        for path in candidates:
            if not path.is_file():
                continue
            # Only voice IDs present in the pinned manifest may enter the pack.
            asset = next((v for v in self.manifest["voices"] if v["id"] == path.stem), None)
            if asset is None:
                log.warning("Skipping unrecognized voice file %s: not in pinned manifest", path.name)
                continue
            check = self.verify_asset(asset, path)
            if not check.ok:
                log.warning("Skipping corrupt voice %s: %s", path.name, check.detail)
                continue
            try:
                array = np.fromfile(path, dtype=np.float32)
                voices[path.stem] = array.reshape(-1, 1, 256)
            except Exception as exc:
                log.warning("Skipping unreadable voice %s: %s", path.name, exc)
        if not voices:
            raise ResourceError("No verified voice files are available.")
        # numpy appends .npz unless the path already ends with it.
        tmp = voice_pack_path().with_name("installed.tmp.npz")
        tmp.unlink(missing_ok=True)
        np.savez(str(tmp), **voices)
        os.replace(tmp, voice_pack_path())
        voice_pack_path().with_name("installed.npz.tmp.npz").unlink(missing_ok=True)
        return sorted(voices)

    # ---------- verification ----------

    def verify_resources(self, model_id: str | None = None) -> VerificationResult:
        model_id = model_id or load_settings().model_id
        checks: list[VerificationCheck] = []
        checks.extend(self.sync_bundled_config())
        model = self.model(model_id)
        checks.append(self.verify_asset(model, self.model_path(model_id), quarantine=False))
        pack = voice_pack_path()
        installed = []
        if not pack.is_file():
            checks.append(VerificationCheck("installed.npz", False, "voice pack is missing"))
        else:
            try:
                with np.load(str(pack)) as data:
                    installed = sorted(data.files)
                    for voice_id in installed[:3]:
                        array = data[voice_id]
                        if array.shape[1:] != (1, 256):
                            raise ValueError(f"unexpected style shape {array.shape}")
                checks.append(VerificationCheck("installed.npz", True,
                                                f"{len(installed)} voice(s): {', '.join(installed[:6])}"))
            except Exception as exc:
                checks.append(VerificationCheck("installed.npz", False, f"cannot load voice pack: {exc}"))
        # Phonemization resources shipped with the application.
        try:
            import espeakng_loader  # type: ignore
            lib = Path(espeakng_loader.get_library_path())
            data = Path(espeakng_loader.get_data_path())
            ok = lib.exists() and data.is_dir()
            checks.append(VerificationCheck("eSpeak NG phonemizer", ok,
                                            f"library={'ok' if lib.exists() else 'missing'}, data={'ok' if data.is_dir() else 'missing'}"))
        except Exception as exc:
            checks.append(VerificationCheck("eSpeak NG phonemizer", False, str(exc)))
        try:
            from importlib import metadata
            ort_version = metadata.version("onnxruntime")
            kokoro_version = metadata.version("kokoro-onnx")
            specs_present = (importlib.util.find_spec("onnxruntime") is not None and
                             importlib.util.find_spec("kokoro_onnx") is not None)
            checks.append(VerificationCheck("inference runtime packages", bool(specs_present),
                                            f"onnxruntime {ort_version}, kokoro-onnx {kokoro_version}; "
                                            "session load is verified in the isolated worker"))
        except Exception as exc:
            checks.append(VerificationCheck("inference runtime packages", False, str(exc)))
        return VerificationResult(all(c.ok for c in checks), checks, model_id, installed)

    def offline_readiness_test(self, *, model_id: str | None = None, voice: str = "af_heart",
                               output_path: Path | None = None,
                               play: bool = False, player: Any = None,
                               mark_ready: bool = True) -> dict[str, Any]:
        """Generate real speech with the network guard enabled and validate it."""
        from .engine import EngineClient  # local import avoids loading ORT in UI process
        from .audio import probe_audio, read_wav
        model_id = model_id or load_settings().model_id
        verification = self.verify_resources(model_id)
        if not verification.ok:
            return {"ok": False, "reason": "resource verification failed",
                    "verification": verification.to_dict()}
        if voice not in verification.installed_voices:
            voice = verification.installed_voices[0]
        output_path = output_path or (data_root() / "Cache" / "offline-readiness.wav")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        text = ("Offline readiness confirmed. Kokoro generated this sentence locally, "
                "without a network connection, using the installed model and voice.")
        set_offline(True)
        client = EngineClient(model_path=str(self.model_path(model_id)),
                              voice_pack=str(voice_pack_path()), threads=1, provider="cpu")
        try:
            client.start()
            result = client.synthesize_chunk(text, str(output_path), voice=voice, speed=1.0,
                                            lang="en-us", sentence_pause_ms=320,
                                            clause_pause_ms=140, trim_silence=False)
        finally:
            client.stop()
        samples = read_wav(output_path)
        rms = float(np.sqrt(np.mean(samples ** 2)))
        peak = float(np.max(np.abs(samples))) if len(samples) else 0.0
        info = probe_audio(output_path)
        checks = [
            VerificationCheck("sample generated", output_path.is_file() and output_path.stat().st_size > 44),
            VerificationCheck("non-silent speech", rms > 0.005 and peak > 0.02,
                              f"RMS={rms:.4f}, peak={peak:.3f}"),
            VerificationCheck("audible duration", float(info["duration"]) > 2.0,
                              f"{float(info['duration']):.2f} seconds"),
            VerificationCheck("network guard active", is_offline(), "outbound sockets blocked"),
        ]
        played = False
        if play:
            try:
                if player is None:
                    from .player import AudioPlayer
                    player = AudioPlayer()
                player.play(output_path)
                played = True
            except Exception as exc:
                checks.append(VerificationCheck("sample playback", False, str(exc)))
        else:
            checks.append(VerificationCheck("sample decodable", True, "WAV decoded locally"))
        ok = all(c.ok for c in checks) and result.get("ok", False)
        report = {"ok": ok, "timestamp": datetime.now(timezone.utc).isoformat(),
                  "model_id": model_id, "voice": voice, "sample": str(output_path),
                  "generation": result, "audio": info, "network_guard": True,
                  "played": played, "verification": verification.to_dict(),
                  "checks": [asdict(c) for c in checks]}
        if ok and mark_ready:
            self.mark_offline_ready(report, model_id, voice)
        return report

    def mark_offline_ready(self, report: dict[str, Any], model_id: str | None = None,
                           voice: str = "af_heart") -> None:
        model_id = model_id or report.get("model_id") or load_settings().model_id
        installed = report.get("verification", {}).get("installed_voices", [voice])
        self.write_setup_report(model_id, installed, report)
        offline_ready_path().write_text(json.dumps(report, indent=2), encoding="utf-8")
        settings = load_settings()
        settings.setup_complete = True
        settings.offline_mode = True
        settings.model_id = model_id
        settings.narration.default_voice = voice
        save_settings(settings)
        set_offline(settings.offline_mode)

    def write_setup_report(self, model_id: str, voice_ids: list[str],
                           offline_test: dict[str, Any]) -> Path:
        verification = self.verify_resources(model_id)
        model = self.model(model_id)
        report = {
            "app_version": __version__,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "system": asdict(self.system_info()),
            "manifest_revision": self.revision,
            "model": {"id": model_id, "path": str(self.model_path(model_id)),
                      "size": model["size"], "sha256": model["sha256"]},
            "voices": [{"id": v, "size": self.voice(v)["size"],
                        "sha256": self.voice(v)["sha256"]} for v in voice_ids],
            "verification": verification.to_dict(),
            "offline_test": offline_test,
            "network_activity": "Only the explicit first-run download contacted huggingface.co. Normal generation is local-only.",
            "license": self.manifest["license"],
            "license_url": self.manifest["license_url"],
        }
        path = setup_report_path()
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)
        return path

    def voice_pack_size(self) -> int:
        pack = voice_pack_path()
        return pack.stat().st_size if pack.is_file() else 0

    def offline_report(self) -> dict[str, Any]:
        if not offline_ready_path().is_file():
            return {}
        try:
            data = json.loads(offline_ready_path().read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def offline_ready(self) -> bool:
        if not offline_ready_path().is_file():
            return False
        report = self.offline_report()
        return bool(report.get("ok")) and load_settings().setup_complete

    def clear_offline_ready(self) -> None:
        offline_ready_path().unlink(missing_ok=True)
        settings = load_settings()
        settings.setup_complete = False
        save_settings(settings)


def resource_manager() -> ResourceManager:
    return ResourceManager()
