"""SQLite project storage, chunk provenance and safe backup/restore."""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .models import Chapter, Chunk, ExportRecord, Job, NarrationSettings, Project
from .paths import database_path, ensure_dirs, project_audio_dir, projects_dir
from .text_processing import (
    NarrationPreprocessor,
    Transformation,
    clean_extracted_text,
    detect_chapters,
    settings_fingerprint,
    sha256_text,
    split_narration_chunks,
    transformation_log_json,
)

SCHEMA_VERSION = 1


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


class Storage:
    def __init__(self, path: Path | None = None):
        ensure_dirs()
        self.path = Path(path) if path else database_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=10000")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS meta (
                  key TEXT PRIMARY KEY, value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS projects (
                  id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at TEXT NOT NULL,
                  updated_at TEXT NOT NULL, author TEXT DEFAULT '', source_path TEXT DEFAULT '',
                  source_hash TEXT DEFAULT '', settings_json TEXT NOT NULL, notes TEXT DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS chapters (
                  id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                  idx INTEGER NOT NULL, title TEXT NOT NULL, original_text TEXT NOT NULL,
                  narration_text TEXT NOT NULL, transformations_json TEXT DEFAULT '[]',
                  voice TEXT DEFAULT '', enabled INTEGER DEFAULT 1, settings_json TEXT DEFAULT '{}',
                  created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                  UNIQUE(project_id, idx)
                );
                CREATE INDEX IF NOT EXISTS chapters_project_idx ON chapters(project_id, idx);
                CREATE TABLE IF NOT EXISTS chunks (
                  id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                  chapter_id TEXT NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
                  idx INTEGER NOT NULL, original_text TEXT NOT NULL, narration_text TEXT NOT NULL,
                  text_hash TEXT NOT NULL, settings_hash TEXT NOT NULL, voice TEXT NOT NULL,
                  speed REAL NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
                  audio_path TEXT DEFAULT '', duration REAL DEFAULT 0, size_bytes INTEGER DEFAULT 0,
                  tries INTEGER DEFAULT 0, error TEXT DEFAULT '',
                  pause_before_ms INTEGER DEFAULT 0, pause_after_ms INTEGER DEFAULT 0,
                  created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                  UNIQUE(chapter_id, idx)
                );
                CREATE INDEX IF NOT EXISTS chunks_project_status ON chunks(project_id, status);
                CREATE INDEX IF NOT EXISTS chunks_chapter_idx ON chunks(chapter_id, idx);
                CREATE TABLE IF NOT EXISTS jobs (
                  id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                  kind TEXT NOT NULL, state TEXT NOT NULL, total INTEGER DEFAULT 0,
                  completed INTEGER DEFAULT 0, current_chunk TEXT DEFAULT '', message TEXT DEFAULT '',
                  started_at TEXT, finished_at TEXT, error TEXT DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS exports (
                  id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                  kind TEXT NOT NULL, format TEXT NOT NULL, path TEXT NOT NULL, status TEXT NOT NULL,
                  size_bytes INTEGER DEFAULT 0, duration REAL DEFAULT 0, created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS events (
                  id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT, level TEXT NOT NULL,
                  message TEXT NOT NULL, created_at TEXT NOT NULL
                );
                """
            )
            conn.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))

    # ---------- row conversion ----------

    @staticmethod
    def _project(row: sqlite3.Row) -> Project:
        return Project(
            id=row["id"], name=row["name"], created_at=row["created_at"], updated_at=row["updated_at"],
            author=row["author"], source_path=row["source_path"], source_hash=row["source_hash"],
            settings=NarrationSettings.from_dict(json.loads(row["settings_json"])), notes=row["notes"],
        )

    @staticmethod
    def _chapter(row: sqlite3.Row) -> Chapter:
        return Chapter(
            id=row["id"], project_id=row["project_id"], idx=row["idx"], title=row["title"],
            original_text=row["original_text"], narration_text=row["narration_text"],
            voice=row["voice"], enabled=bool(row["enabled"]), settings_json=row["settings_json"],
            created_at=row["created_at"], updated_at=row["updated_at"],
        )

    @staticmethod
    def _chunk(row: sqlite3.Row) -> Chunk:
        return Chunk(
            id=row["id"], project_id=row["project_id"], chapter_id=row["chapter_id"], idx=row["idx"],
            original_text=row["original_text"], narration_text=row["narration_text"],
            text_hash=row["text_hash"], settings_hash=row["settings_hash"], voice=row["voice"],
            speed=row["speed"], status=row["status"], audio_path=row["audio_path"],
            duration=row["duration"], size_bytes=row["size_bytes"], tries=row["tries"],
            error=row["error"], pause_before_ms=row["pause_before_ms"],
            pause_after_ms=row["pause_after_ms"], created_at=row["created_at"], updated_at=row["updated_at"],
        )

    # ---------- events / jobs / exports ----------

    def add_event(self, level: str, message: str, project_id: str = "") -> None:
        with self._connect() as conn:
            conn.execute("INSERT INTO events(project_id,level,message,created_at) VALUES(?,?,?,?)",
                         (project_id or None, level, message, now()))

    def list_events(self, project_id: str = "", limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if project_id:
                rows = conn.execute("SELECT * FROM events WHERE project_id=? ORDER BY id DESC LIMIT ?", (project_id, limit)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def create_job(self, project_id: str, kind: str, total: int) -> Job:
        job = Job(id=new_id("job"), project_id=project_id, kind=kind, state="pending", total=total, started_at=now())
        with self._connect() as conn:
            conn.execute("INSERT INTO jobs(id,project_id,kind,state,total,started_at) VALUES(?,?,?,?,?,?)",
                         (job.id, job.project_id, job.kind, job.state, job.total, job.started_at))
        return job

    def update_job(self, job_id: str, **changes: Any) -> None:
        if not changes:
            return
        allowed = {"state", "total", "completed", "current_chunk", "message", "finished_at", "error"}
        pairs = [(k, v) for k, v in changes.items() if k in allowed]
        if not pairs:
            return
        sql = "UPDATE jobs SET " + ",".join(f"{k}=?" for k, _ in pairs) + ", finished_at=COALESCE(?,finished_at) WHERE id=?"
        values = [v for _, v in pairs]
        final = None
        if changes.get("state") in {"completed", "cancelled", "failed"}:
            final = changes.get("finished_at") or now()
        with self._connect() as conn:
            conn.execute(sql, (*values, final, job_id))

    def get_job(self, job_id: str) -> Job | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if not row:
            return None
        return Job(**{k: row[k] for k in Job.__dataclass_fields__})

    def add_export(self, record: ExportRecord) -> None:
        with self._connect() as conn:
            conn.execute("""INSERT OR REPLACE INTO exports(id,project_id,kind,format,path,status,size_bytes,duration,created_at)
                            VALUES(?,?,?,?,?,?,?,?,?)""",
                         (record.id, record.project_id, record.kind, record.format, record.path,
                          record.status, record.size_bytes, record.duration, record.created_at or now()))

    def list_exports(self, project_id: str) -> list[ExportRecord]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM exports WHERE project_id=? ORDER BY created_at DESC", (project_id,)).fetchall()
        return [ExportRecord(**{k: r[k] for k in ExportRecord.__dataclass_fields__}) for r in rows]

    # ---------- projects ----------

    def create_project(self, name: str, chapters: list[dict[str, str]] | None = None,
                       settings: NarrationSettings | None = None, source_path: str = "",
                       source_hash: str = "", author: str = "") -> Project:
        settings = settings or NarrationSettings()
        project = Project(id=new_id("prj"), name=name.strip() or "Untitled Audiobook",
                          created_at=now(), updated_at=now(), author=author,
                          source_path=source_path, source_hash=source_hash, settings=settings)
        project_audio_dir(project.id).mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.execute("""INSERT INTO projects(id,name,created_at,updated_at,author,source_path,source_hash,settings_json,notes)
                            VALUES(?,?,?,?,?,?,?,?,?)""",
                         (project.id, project.name, project.created_at, project.updated_at,
                          project.author, source_path, source_hash, json.dumps(settings.to_dict()), ""))
            for i, item in enumerate(chapters or [{"title": "Chapter 1", "text": ""}]):
                original = item.get("text", "")
                narration, transformations = NarrationPreprocessor(settings).transform(original)
                conn.execute("""INSERT INTO chapters(id,project_id,idx,title,original_text,narration_text,
                                transformations_json,voice,enabled,settings_json,created_at,updated_at)
                                VALUES(?,?,?,?,?,?,?,?,1,'{}',?,?)""",
                             (new_id("chp"), project.id, i, item.get("title", f"Chapter {i+1}"),
                              original, narration, transformation_log_json(transformations), settings.default_voice, now(), now()))
        self.rebuild_chunks(project.id)
        self.add_event("info", f"Created project '{project.name}'.", project.id)
        return project

    def get_project(self, project_id: str) -> Project | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
        return self._project(row) if row else None

    def list_projects(self) -> list[Project]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM projects ORDER BY updated_at DESC").fetchall()
        return [self._project(r) for r in rows]

    def update_project(self, project_id: str, **changes: Any) -> Project | None:
        allowed = {"name", "author", "source_path", "source_hash", "notes"}
        pairs = [(k, v) for k, v in changes.items() if k in allowed]
        if "settings" in changes and isinstance(changes["settings"], NarrationSettings):
            pairs.append(("settings_json", json.dumps(changes["settings"].to_dict())))
        if not pairs:
            return self.get_project(project_id)
        pairs.append(("updated_at", now()))
        with self._connect() as conn:
            conn.execute("UPDATE projects SET " + ",".join(f"{k}=?" for k, _ in pairs) + " WHERE id=?",
                         (*[v for _, v in pairs], project_id))
        return self.get_project(project_id)

    def rename_project(self, project_id: str, name: str) -> None:
        self.update_project(project_id, name=name.strip() or "Untitled Audiobook")

    def delete_project(self, project_id: str) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM projects WHERE id=?", (project_id,))
        shutil.rmtree(projects_dir() / project_id, ignore_errors=True)
        self.add_event("info", f"Deleted project {project_id}.")

    def duplicate_project(self, project_id: str, name: str) -> Project | None:
        source = self.get_project(project_id)
        if not source:
            return None
        new_project = self.create_project(name, chapters=[{"title": "Placeholder", "text": ""}], settings=source.settings,
                                          author=source.author, source_path=source.source_path, source_hash=source.source_hash)
        with self._connect() as conn:
            # Remove placeholder chapter and copy real rows with fresh IDs.
            conn.execute("DELETE FROM chapters WHERE project_id=?", (new_project.id,))
            chapter_map: dict[str, str] = {}
            for old in conn.execute("SELECT * FROM chapters WHERE project_id=? ORDER BY idx", (project_id,)).fetchall():
                cid = new_id("chp")
                chapter_map[old["id"]] = cid
                conn.execute("""INSERT INTO chapters(id,project_id,idx,title,original_text,narration_text,
                                transformations_json,voice,enabled,settings_json,created_at,updated_at)
                                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                             (cid, new_project.id, old["idx"], old["title"], old["original_text"],
                              old["narration_text"], old["transformations_json"], old["voice"], old["enabled"],
                              old["settings_json"], now(), now()))
            for old in conn.execute("SELECT * FROM chunks WHERE project_id=? ORDER BY chapter_id,idx", (project_id,)).fetchall():
                audio_path = ""
                if old["audio_path"] and Path(old["audio_path"]).exists():
                    src = Path(old["audio_path"])
                    dst = project_audio_dir(new_project.id) / src.name
                    shutil.copy2(src, dst)
                    audio_path = str(dst)
                conn.execute("""INSERT INTO chunks(id,project_id,chapter_id,idx,original_text,narration_text,
                                text_hash,settings_hash,voice,speed,status,audio_path,duration,size_bytes,
                                tries,error,pause_before_ms,pause_after_ms,created_at,updated_at)
                                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                             (new_id("chk"), new_project.id, chapter_map[old["chapter_id"]], old["idx"],
                              old["original_text"], old["narration_text"], old["text_hash"], old["settings_hash"],
                              old["voice"], old["speed"], old["status"], audio_path, old["duration"],
                              old["size_bytes"], old["tries"], old["error"], old["pause_before_ms"],
                              old["pause_after_ms"], now(), now()))
        return self.get_project(new_project.id)

    def project_stats(self, project_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            stats = conn.execute("""SELECT COUNT(*) AS total, SUM(status='done') AS done,
                                   SUM(status='error') AS errors, SUM(status='stale') AS stale,
                                   COALESCE(SUM(CASE WHEN status='done' THEN duration END),0) AS duration
                                   FROM chunks WHERE project_id=?""", (project_id,)).fetchone()
            chapter_count = conn.execute("SELECT COUNT(*) FROM chapters WHERE project_id=?", (project_id,)).fetchone()[0]
            bytes_count = conn.execute("SELECT COALESCE(SUM(size_bytes),0) FROM chunks WHERE project_id=? AND status='done'", (project_id,)).fetchone()[0]
        return {
            "chapters": chapter_count,
            "chunks": stats["total"] or 0,
            "done": stats["done"] or 0,
            "errors": stats["errors"] or 0,
            "stale": stats["stale"] or 0,
            "duration": stats["duration"] or 0.0,
            "bytes": bytes_count or 0,
        }

    def backup_project(self, project_id: str, output_zip: str | Path) -> Path:
        project = self.get_project(project_id)
        if not project:
            raise FileNotFoundError(project_id)
        output = Path(output_zip)
        output.parent.mkdir(parents=True, exist_ok=True)
        tmp = output.with_name(output.name + ".tmp")
        with self._connect() as conn, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
            data = {
                "format": "kas-project-backup", "version": 1,
                "project": {**project.__dict__, "settings": project.settings.to_dict()},
                "chapters": [dict(r) for r in conn.execute("SELECT * FROM chapters WHERE project_id=? ORDER BY idx", (project_id,))],
                "chunks": [dict(r) for r in conn.execute("SELECT * FROM chunks WHERE project_id=? ORDER BY chapter_id,idx", (project_id,))],
                "exports": [dict(r) for r in conn.execute("SELECT * FROM exports WHERE project_id=?", (project_id,))],
            }
            zf.writestr("metadata.json", json.dumps(data, ensure_ascii=False, indent=2))
            for row in data["chunks"]:
                path = Path(row["audio_path"])
                if row["audio_path"] and path.exists():
                    zf.write(path, f"audio/{path.name}")
        os.replace(tmp, output)
        self.add_event("info", f"Backed up project to {output}.", project_id)
        return output

    def restore_project(self, backup_zip: str | Path) -> Project:
        path = Path(backup_zip)
        with zipfile.ZipFile(path) as zf:
            data = json.loads(zf.read("metadata.json").decode("utf-8"))
            if data.get("format") != "kas-project-backup" or data.get("version") != 1:
                raise ValueError("Unsupported project backup format.")
            project_data = dict(data["project"])
            settings = NarrationSettings.from_dict(project_data.pop("settings", {}))
            project = Project(id=new_id("prj"), name=f"{project_data.get('name','Restored')} (restored)",
                              created_at=now(), updated_at=now(), author=project_data.get("author", ""),
                              source_path=project_data.get("source_path", ""), source_hash=project_data.get("source_hash", ""),
                              settings=settings, notes=project_data.get("notes", ""))
            project_audio_dir(project.id).mkdir(parents=True, exist_ok=True)
            with self._connect() as conn:
                conn.execute("""INSERT INTO projects(id,name,created_at,updated_at,author,source_path,source_hash,settings_json,notes)
                                VALUES(?,?,?,?,?,?,?,?,?)""",
                             (project.id, project.name, project.created_at, project.updated_at, project.author,
                              project.source_path, project.source_hash, json.dumps(settings.to_dict()), project.notes))
                chapter_map: dict[str, str] = {}
                for row in data["chapters"]:
                    cid = new_id("chp"); chapter_map[row["id"]] = cid
                    conn.execute("""INSERT INTO chapters(id,project_id,idx,title,original_text,narration_text,
                                    transformations_json,voice,enabled,settings_json,created_at,updated_at)
                                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                                 (cid, project.id, row["idx"], row["title"], row["original_text"],
                                  row["narration_text"], row.get("transformations_json", "[]"), row.get("voice", ""),
                                  row.get("enabled", 1), row.get("settings_json", "{}"), now(), now()))
                for row in data["chunks"]:
                    audio_path = ""
                    if row.get("audio_path"):
                        name = Path(row["audio_path"]).name
                        try:
                            payload = zf.read(f"audio/{name}")
                            dst = project_audio_dir(project.id) / name
                            dst.write_bytes(payload)
                            audio_path = str(dst)
                        except KeyError:
                            audio_path = ""
                    conn.execute("""INSERT INTO chunks(id,project_id,chapter_id,idx,original_text,narration_text,
                                    text_hash,settings_hash,voice,speed,status,audio_path,duration,size_bytes,
                                    tries,error,pause_before_ms,pause_after_ms,created_at,updated_at)
                                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                                 (new_id("chk"), project.id, chapter_map[row["chapter_id"]], row["idx"],
                                  row["original_text"], row["narration_text"], row["text_hash"], row["settings_hash"],
                                  row["voice"], row["speed"], row["status"] if audio_path or row["status"] != "done" else "stale",
                                  audio_path, row.get("duration", 0), row.get("size_bytes", 0), row.get("tries", 0),
                                  row.get("error", ""), row.get("pause_before_ms", 0), row.get("pause_after_ms", 0), now(), now()))
                for row in data.get("exports", []):
                    conn.execute("""INSERT INTO exports(id,project_id,kind,format,path,status,size_bytes,duration,created_at)
                                    VALUES(?,?,?,?,?,?,?,?,?)""",
                                 (new_id("exp"), project.id, row["kind"], row["format"], row["path"],
                                  row["status"], row.get("size_bytes", 0), row.get("duration", 0), now()))
        self.add_event("info", f"Restored project from {path}.", project.id)
        return project

    # ---------- chapters ----------

    def list_chapters(self, project_id: str) -> list[Chapter]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM chapters WHERE project_id=? ORDER BY idx", (project_id,)).fetchall()
        return [self._chapter(r) for r in rows]

    def get_chapter(self, chapter_id: str) -> Chapter | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM chapters WHERE id=?", (chapter_id,)).fetchone()
        return self._chapter(row) if row else None

    def transformations(self, chapter_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute("SELECT transformations_json FROM chapters WHERE id=?", (chapter_id,)).fetchone()
        return json.loads(row[0]) if row and row[0] else []

    def prepare_narration(self, chapter_id: str, settings: NarrationSettings | None = None) -> tuple[str, list[Transformation]]:
        chapter = self.get_chapter(chapter_id)
        if not chapter:
            raise KeyError(chapter_id)
        settings = settings or (self.get_project(chapter.project_id).settings if self.get_project(chapter.project_id) else NarrationSettings())
        narration, transformations = NarrationPreprocessor(settings).transform(chapter.original_text)
        with self._connect() as conn:
            conn.execute("UPDATE chapters SET narration_text=?, transformations_json=?, updated_at=? WHERE id=?",
                         (narration, transformation_log_json(transformations), now(), chapter_id))
        self.rebuild_chunks(chapter.project_id)
        return narration, transformations

    def update_chapter(self, chapter_id: str, **changes: Any) -> None:
        allowed = {"title", "original_text", "narration_text", "voice", "enabled", "settings_json"}
        pairs = [(k, int(v) if k == "enabled" else v) for k, v in changes.items() if k in allowed]
        if not pairs:
            return
        pairs.append(("updated_at", now()))
        with self._connect() as conn:
            conn.execute("UPDATE chapters SET " + ",".join(f"{k}=?" for k, _ in pairs) + " WHERE id=?",
                         (*[v for _, v in pairs], chapter_id))
            row = conn.execute("SELECT project_id FROM chapters WHERE id=?", (chapter_id,)).fetchone()
        if row:
            self.rebuild_chunks(row["project_id"])

    def create_chapter(self, project_id: str, title: str, text: str = "") -> Chapter:
        with self._connect() as conn:
            idx = conn.execute("SELECT COALESCE(MAX(idx),-1)+1 FROM chapters WHERE project_id=?", (project_id,)).fetchone()[0]
            chapter = Chapter(id=new_id("chp"), project_id=project_id, idx=idx, title=title,
                              original_text=text, narration_text=text, created_at=now(), updated_at=now())
            conn.execute("""INSERT INTO chapters(id,project_id,idx,title,original_text,narration_text,transformations_json,
                            voice,enabled,settings_json,created_at,updated_at) VALUES(?,?,?,?,?,?,'[]','',1,'{}',?,?)""",
                         (chapter.id, project_id, idx, title, text, text, now(), now()))
        self.rebuild_chunks(project_id)
        return chapter

    @staticmethod
    def _shift_indices(conn: sqlite3.Connection, project_id: str, from_idx: int, delta: int) -> None:
        """Shift indices safely despite UNIQUE(project_id, idx)."""
        rows = conn.execute("SELECT id,idx FROM chapters WHERE project_id=? AND idx>=? ORDER BY idx DESC",
                            (project_id, from_idx)).fetchall()
        for row in rows:
            conn.execute("UPDATE chapters SET idx=? WHERE id=?", (-100000 - row["idx"], row["id"]))
        for row in rows:
            conn.execute("UPDATE chapters SET idx=? WHERE id=?", (row["idx"] + delta, row["id"]))

    def delete_chapter(self, chapter_id: str) -> None:
        with self._connect() as conn:
            row = conn.execute("SELECT project_id,idx FROM chapters WHERE id=?", (chapter_id,)).fetchone()
            if not row:
                return
            project_id = row["project_id"]
            conn.execute("DELETE FROM chapters WHERE id=?", (chapter_id,))
            self._shift_indices(conn, project_id, row["idx"] + 1, -1)
        self.rebuild_chunks(project_id)

    def move_chapter(self, chapter_id: str, direction: int) -> None:
        with self._connect() as conn:
            row = conn.execute("SELECT project_id,idx FROM chapters WHERE id=?", (chapter_id,)).fetchone()
            if not row:
                return
            other = conn.execute("SELECT id,idx FROM chapters WHERE project_id=? AND idx=?",
                                 (row["project_id"], row["idx"] + direction)).fetchone()
            if not other:
                return
            conn.execute("UPDATE chapters SET idx=-1 WHERE id=?", (chapter_id,))
            conn.execute("UPDATE chapters SET idx=? WHERE id=?", (row["idx"], other["id"]))
            conn.execute("UPDATE chapters SET idx=? WHERE id=?", (other["idx"], chapter_id))
            project_id = row["project_id"]
        self.rebuild_chunks(project_id)

    def split_chapter(self, chapter_id: str, paragraph_index: int) -> str | None:
        chapter = self.get_chapter(chapter_id)
        if not chapter:
            return None
        paragraphs = [p.strip() for p in chapter.narration_text.split("\n\n") if p.strip()]
        index = max(1, min(paragraph_index, len(paragraphs) - 1))
        if len(paragraphs) < 2:
            return None
        first, second = "\n\n".join(paragraphs[:index]), "\n\n".join(paragraphs[index:])
        with self._connect() as conn:
            idx = chapter.idx
            self._shift_indices(conn, chapter.project_id, idx + 1, 1)
            new_chapter_id = new_id("chp")
            conn.execute("""INSERT INTO chapters(id,project_id,idx,title,original_text,narration_text,transformations_json,
                            voice,enabled,settings_json,created_at,updated_at)
                            VALUES(?,?,?,?,?,?,'[]',?,1,'{}',?,?)""",
                         (new_chapter_id, chapter.project_id, idx + 1, f"{chapter.title} (continued)",
                          second, second, chapter.voice, now(), now()))
            conn.execute("UPDATE chapters SET original_text=?, narration_text=?, updated_at=? WHERE id=?",
                         (first, first, now(), chapter_id))
        self.rebuild_chunks(chapter.project_id)
        return new_chapter_id

    def redetect_chapters(self, chapter_id: str) -> int:
        """Replace one chapter with headings found in its own source text."""
        chapter = self.get_chapter(chapter_id)
        if not chapter:
            return 0
        project = self.get_project(chapter.project_id)
        settings = project.settings if project else NarrationSettings()
        drafts = detect_chapters(chapter.original_text, default_title=chapter.title)
        if len(drafts) <= 1:
            return 0
        with self._connect() as conn:
            self._shift_indices(conn, chapter.project_id, chapter.idx + 1, len(drafts) - 1)
            conn.execute("DELETE FROM chapters WHERE id=?", (chapter_id,))
            for offset, draft in enumerate(drafts):
                narration, transformations = NarrationPreprocessor(settings).transform(draft.text)
                conn.execute("""INSERT INTO chapters(id,project_id,idx,title,original_text,narration_text,
                                transformations_json,voice,enabled,settings_json,created_at,updated_at)
                                VALUES(?,?,?,?,?,?,?,?,1,'{}',?,?)""",
                             (new_id("chp"), chapter.project_id, chapter.idx + offset,
                              draft.title or f"Chapter {chapter.idx + offset + 1}",
                              draft.text, narration, transformation_log_json(transformations),
                              chapter.voice or settings.default_voice, now(), now()))
        self.rebuild_chunks(chapter.project_id)
        self.add_event("info", f"Detected {len(drafts)} chapters in {chapter.title}.", chapter.project_id)
        return len(drafts)

    def merge_chapters(self, first_id: str, second_id: str) -> None:
        first, second = self.get_chapter(first_id), self.get_chapter(second_id)
        if not first or not second or first.project_id != second.project_id:
            return
        if second.idx != first.idx + 1:
            raise ValueError("Only adjacent chapters can be merged.")
        with self._connect() as conn:
            conn.execute("UPDATE chapters SET original_text=?, narration_text=?, updated_at=? WHERE id=?",
                         (first.original_text.rstrip() + "\n\n" + second.original_text.lstrip(),
                          first.narration_text.rstrip() + "\n\n" + second.narration_text.lstrip(), now(), first_id))
            conn.execute("DELETE FROM chapters WHERE id=?", (second_id,))
            self._shift_indices(conn, first.project_id, second.idx + 1, -1)
        self.rebuild_chunks(first.project_id)

    # ---------- chunks ----------

    def rebuild_chunks(self, project_id: str) -> list[str]:
        """Rebuild boundaries while preserving unchanged completed chunks.

        Returns an explicit list of chunk IDs whose text or settings changed;
        the UI uses this to tell the user which subsequent audio is affected.
        """
        project = self.get_project(project_id)
        if not project:
            return []
        settings = project.settings
        affected: list[str] = []
        with self._connect() as conn:
            for chapter in [self._chapter(r) for r in conn.execute("SELECT * FROM chapters WHERE project_id=? ORDER BY idx", (project_id,)).fetchall()]:
                voice = chapter.voice or settings.default_voice
                speed = settings.speed
                fingerprint = settings_fingerprint(settings, voice, speed)
                narration = chapter.narration_text.strip()
                new_chunks = split_narration_chunks(narration, settings) if narration else []
                old_rows = conn.execute("SELECT * FROM chunks WHERE chapter_id=? ORDER BY idx", (chapter.id,)).fetchall()
                old_by_idx = {r["idx"]: r for r in old_rows}
                original_paragraphs = [p.strip() for p in chapter.original_text.split("\n\n") if p.strip()]
                for i, nc in enumerate(new_chunks):
                    text_hash = sha256_text(nc.text)
                    old = old_by_idx.get(i)
                    audio_valid = bool(old and old["audio_path"] and Path(old["audio_path"]).exists() and old["status"] == "done")
                    unchanged = bool(old and old["text_hash"] == text_hash and old["settings_hash"] == fingerprint and audio_valid)
                    chunk_id = old["id"] if old else new_id("chk")
                    source_excerpt = original_paragraphs[min(nc.paragraph_index, len(original_paragraphs) - 1)] if original_paragraphs else nc.text
                    if old:
                        conn.execute("""UPDATE chunks SET original_text=?,narration_text=?,text_hash=?,settings_hash=?,
                                        voice=?,speed=?,status=?,error=?,pause_before_ms=?,pause_after_ms=?,updated_at=?
                                        WHERE id=?""",
                                     (source_excerpt, nc.text, text_hash, fingerprint, voice, speed,
                                      old["status"] if unchanged else "stale", "" if unchanged else old["error"],
                                      nc.pause_before_ms, nc.pause_after_ms, now(), chunk_id))
                        if not unchanged:
                            affected.append(chunk_id)
                    else:
                        conn.execute("""INSERT INTO chunks(id,project_id,chapter_id,idx,original_text,narration_text,
                                        text_hash,settings_hash,voice,speed,status,pause_before_ms,pause_after_ms,created_at,updated_at)
                                        VALUES(?,?,?,?,?,?,?,?,?,?, 'pending',?,?,?,?)""",
                                     (chunk_id, project_id, chapter.id, i, source_excerpt, nc.text, text_hash,
                                      fingerprint, voice, speed, nc.pause_before_ms, nc.pause_after_ms, now(), now()))
                        affected.append(chunk_id)
                max_idx = len(new_chunks)
                stale_ids = [r["id"] for r in old_rows if r["idx"] >= max_idx]
                for stale_id in stale_ids:
                    conn.execute("DELETE FROM chunks WHERE id=?", (stale_id,))
                    affected.append(stale_id)
            conn.execute("UPDATE projects SET updated_at=? WHERE id=?", (now(), project_id))
        return affected

    def list_chunks(self, project_id: str, chapter_id: str | None = None) -> list[Chunk]:
        with self._connect() as conn:
            if chapter_id:
                rows = conn.execute("""SELECT c.* FROM chunks c JOIN chapters h ON h.id=c.chapter_id
                                       WHERE c.project_id=? AND c.chapter_id=? ORDER BY h.idx,c.idx""",
                                    (project_id, chapter_id)).fetchall()
            else:
                rows = conn.execute("""SELECT c.* FROM chunks c JOIN chapters h ON h.id=c.chapter_id
                                       WHERE c.project_id=? ORDER BY h.idx,c.idx""", (project_id,)).fetchall()
        return [self._chunk(r) for r in rows]

    def get_chunk(self, chunk_id: str) -> Chunk | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM chunks WHERE id=?", (chunk_id,)).fetchone()
        return self._chunk(row) if row else None

    def pending_chunks(self, project_id: str, chapter_ids: set[str] | None = None) -> list[Chunk]:
        chunks = [c for c in self.list_chunks(project_id)
                  if c.status in {"pending", "stale"} or (c.status == "error" and c.tries < 3)]
        if chapter_ids:
            chunks = [c for c in chunks if c.chapter_id in chapter_ids]
        return chunks

    def regenerate_chunk(self, chunk_id: str) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE chunks SET status='stale', error='', tries=0, updated_at=? WHERE id=?", (now(), chunk_id))
        self.add_event("info", f"Marked chunk {chunk_id} for regeneration.")

    def regenerate_chapter(self, chapter_id: str) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE chunks SET status='stale', error='', tries=0, updated_at=? WHERE chapter_id=?", (now(), chapter_id))

    def mark_chunk_running(self, chunk_id: str) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE chunks SET error='', updated_at=? WHERE id=?", (now(), chunk_id))

    def mark_chunk_done(self, chunk_id: str, audio_path: str, duration: float, size_bytes: int) -> None:
        with self._connect() as conn:
            conn.execute("""UPDATE chunks SET status='done', audio_path=?, duration=?, size_bytes=?,
                            error='', updated_at=? WHERE id=?""",
                         (audio_path, duration, size_bytes, now(), chunk_id))

    def mark_chunk_error(self, chunk_id: str, error: str, max_retries: int = 3) -> str:
        with self._connect() as conn:
            row = conn.execute("SELECT tries FROM chunks WHERE id=?", (chunk_id,)).fetchone()
            tries = (row["tries"] if row else 0) + 1
            status = "pending" if tries < max_retries else "error"
            conn.execute("UPDATE chunks SET tries=?,status=?,error=?,updated_at=? WHERE id=?",
                         (tries, status, error[:2000], now(), chunk_id))
        return status

    def chunk_audio_path(self, chunk: Chunk) -> Path:
        project_audio_dir(chunk.project_id).mkdir(parents=True, exist_ok=True)
        return project_audio_dir(chunk.project_id) / f"{chunk.chapter_id}_{chunk.idx:04d}_{chunk.id[:8]}.wav"
