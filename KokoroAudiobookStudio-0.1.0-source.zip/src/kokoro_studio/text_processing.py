"""Local manuscript cleanup, chapter detection, narration preparation and chunking.

Design rule: source text is immutable.  All normalization, abbreviation
expansion and pronunciation respelling produces a separate narration string and
an explicit transformation log that the UI can display before generation.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from typing import Iterable, Iterator

from .models import NarrationSettings

_ROMAN = re.compile(r"^(?:[IVXLCDM]+|\d+|[A-Z][A-Z0-9 .,'-]{1,60})$")
_CHAPTER_PATTERNS = (
    re.compile(r"^\s*(?:chapter|chap\.?)\s+(\d+|[IVXLCDM]+|[A-Za-z]+)\b[:\.\-—\s]*(.*)$", re.I),
    re.compile(r"^\s*(?:part|book|section)\s+(\d+|[IVXLCDM]+)\b[:\.\-—\s]*(.*)$", re.I),
    re.compile(r"^\s*#{1,4}\s+(.+?)\s*#*\s*$"),
    re.compile(r"^\s*(\d+[.)])\s+(.+)$"),
)

_UNITS = {
    "kg": "kilograms", "kgs": "kilograms", "g": "grams", "mg": "milligrams",
    "km": "kilometers", "cm": "centimeters", "mm": "millimeters", "m": "meters",
    "ft": "feet", "in": "inches", "mi": "miles", "lb": "pounds", "lbs": "pounds",
    "oz": "ounces", "l": "liters", "ml": "milliliters", "°c": "degrees Celsius",
    "°f": "degrees Fahrenheit", "kph": "kilometers per hour", "mph": "miles per hour",
}
_ABBREVIATIONS = {
    "Mr.": "Mister", "Mrs.": "Missus", "Ms.": "Miz", "Dr.": "Doctor",
    "Prof.": "Professor", "Sr.": "Senior", "Jr.": "Junior",
    "etc.": "et cetera", "e.g.": "for example", "i.e.": "that is",
    "vs.": "versus", "No.": "number", "Approx.": "approximately",
    "Fig.": "Figure", "St.": "Saint", "Mt.": "Mount",
}
_ONES = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
         "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
         "seventeen", "eighteen", "nineteen"]
_TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
_SCALES = [(1_000_000_000, "billion"), (1_000_000, "million"), (1_000, "thousand")]


@dataclass
class Transformation:
    kind: str
    original: str
    replacement: str
    count: int = 1


@dataclass
class ChapterDraft:
    title: str
    text: str
    source_order: int


@dataclass
class NarrationChunk:
    text: str
    paragraph_index: int
    pause_before_ms: int = 0
    pause_after_ms: int = 0
    paragraph_end: bool = False
    source_start: int = 0
    source_end: int = 0


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def settings_fingerprint(settings: NarrationSettings, voice: str, speed: float) -> str:
    relevant = settings.to_dict()
    relevant["voice"] = voice
    relevant["speed"] = round(float(speed), 3)
    return sha256_text(json.dumps(relevant, sort_keys=True, ensure_ascii=False))


def normalize_newlines(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Repair line-break hyphenation without joining genuine compound words.
    return re.sub(r"(\w)-\n(\w)", r"\1\2", text)


def chapter_heading(line: str) -> str | None:
    stripped = line.strip()
    if not stripped or len(stripped) > 100 or stripped.endswith((".", ",", ";", ":")):
        return None
    labeled_heading = re.match(r"^\s*(?:chapter|chap\.?|part|book|section)\b", stripped, re.I)
    if labeled_heading:
        return stripped.title()[:100]
    for pattern in _CHAPTER_PATTERNS:
        m = pattern.match(stripped)
        if m:
            groups = [g for g in m.groups() if g]
            heading = " ".join(groups).strip(" .:-")
            if heading:
                return heading[:100]
    # A short all-uppercase line between blank lines is treated as a heading.
    letters = [c for c in stripped if c.isalpha()]
    if letters and all(c.isupper() for c in letters) and 2 <= len(stripped) <= 70 and len(stripped.split()) <= 10:
        return stripped.title()
    if _ROMAN.match(stripped) and len(stripped) <= 4:
        return stripped
    return None


def detect_chapters(text: str, default_title: str = "Full Manuscript") -> list[ChapterDraft]:
    """Return ordered chapter drafts; headings are removed from body text."""
    text = normalize_newlines(text)
    lines = text.split("\n")
    found: list[tuple[int, str]] = []
    for i, line in enumerate(lines):
        heading = chapter_heading(line)
        if not heading:
            continue
        # Require surrounding whitespace or a Markdown marker to reduce false positives.
        prev_blank = i == 0 or not lines[i - 1].strip()
        next_blank = i + 1 >= len(lines) or not lines[i + 1].strip()
        if prev_blank or next_blank or line.lstrip().startswith("#"):
            found.append((i, heading))
    if not found:
        body = text.strip()
        return [ChapterDraft(default_title, body, 0)] if body else []
    chapters: list[ChapterDraft] = []
    front = "\n".join(lines[: found[0][0]]).strip()
    if front and len(front) > 20:
        chapters.append(ChapterDraft("Front Matter", front, len(chapters)))
    for n, (line_index, title) in enumerate(found):
        end = found[n + 1][0] if n + 1 < len(found) else len(lines)
        body_lines = lines[line_index + 1 : end]
        body = "\n".join(body_lines).strip()
        # A heading immediately followed by another heading is usually a book
        # title/subtitle, not an empty narrated chapter.
        if not body and (chapters or len(found) > 1):
            continue
        chapters.append(ChapterDraft(title, body, len(chapters)))
    # Preserve source order even if front matter was added.
    for i, chapter in enumerate(chapters):
        chapter.source_order = i
    return chapters


def repeated_page_lines(pages: list[str], threshold: float = 0.6) -> set[str]:
    """Identify lines repeated on most pages (typical running headers/footers)."""
    counts: dict[str, int] = {}
    for page in pages:
        candidates = {line.strip() for line in page.splitlines() if line.strip()}
        for line in candidates:
            counts[line] = counts.get(line, 0) + 1
    needed = max(2, int(len(pages) * threshold))
    repeated = {line for line, count in counts.items() if count >= needed}
    # Bare page numbers and page-number decorations are always removable.
    for line in list(counts):
        if re.fullmatch(r"(?:[-–—]\s*)?(?:page\s*)?\d{1,4}(?:\s*[-–—])?", line, re.I):
            repeated.add(line)
    return repeated


def clean_extracted_text(text: str, remove_lines: Iterable[str] | None = None) -> str:
    text = normalize_newlines(text)
    removals = {str(x).strip() for x in (remove_lines or []) if str(x).strip()}
    kept: list[str] = []
    for line in text.split("\n"):
        if line.strip() in removals:
            continue
        if re.fullmatch(r"(?:[-–—]\s*)?(?:page\s*)?\d{1,4}(?:\s*(?:of|/)\s*\d{1,4})?\s*[-–—]?", line.strip(), re.I):
            continue
        kept.append(line)
    # Join soft-wrapped lines into paragraphs; keep blank lines as paragraph breaks.
    paragraphs: list[str] = []
    current: list[str] = []
    for line in kept:
        if not line.strip():
            if current:
                paragraphs.append(" ".join(current))
                current = []
            continue
        current.append(line.strip())
    if current:
        paragraphs.append(" ".join(current))
    return "\n\n".join(paragraphs)


def _under_hundred(n: int) -> str:
    if n < 20:
        return _ONES[n]
    tens, ones = divmod(n, 10)
    return _TENS[tens] + ("-" + _ONES[ones] if ones else "")


def _under_thousand(n: int) -> str:
    if n < 100:
        return _under_hundred(n)
    hundreds, rest = divmod(n, 100)
    prefix = f"{_ONES[hundreds]} hundred"
    return prefix + (" and " + _under_hundred(rest) if rest else "")


def number_to_words(number: int) -> str:
    if number == 0:
        return "zero"
    sign = "minus " if number < 0 else ""
    n = abs(number)
    if n >= 1_000_000_000_000:
        return str(number)  # do not guess very large magnitudes
    pieces: list[str] = []
    for scale, name in _SCALES:
        q, n = divmod(n, scale)
        if q:
            pieces.append(f"{_under_thousand(q)} {name}")
    if n:
        pieces.append(_under_thousand(n))
    return sign + " ".join(pieces)


def decimal_to_words(value: str) -> str:
    if re.fullmatch(r"-?\d+", value):
        return number_to_words(int(value))
    whole, _, frac = value.partition(".")
    prefix = number_to_words(int(whole)) if whole and whole != "-" else "zero"
    digits = " ".join(_ONES[int(c)] for c in frac if c.isdigit())
    return f"{prefix} point {digits}".strip()


def year_to_words(year: int) -> str:
    if 2000 <= year <= 2099:
        if year % 100 == 0:
            return "two thousand"
        return "twenty " + _under_hundred(year - 2000)
    if 1900 <= year <= 1999:
        return f"{_under_hundred(19)} {_under_hundred(year - 1900)}" if year % 100 else "nineteen hundred"
    if 1000 <= year <= 9999:
        left, right = divmod(year, 100)
        return f"{_under_hundred(left)} {_under_hundred(right)}" if right else f"{_under_hundred(left)} hundred"
    return number_to_words(year)


MONTHS = ["January", "February", "March", "April", "May", "June", "July",
          "August", "September", "October", "November", "December"]


class NarrationPreprocessor:
    """Deterministic, auditable text preparation. No network calls."""

    def __init__(self, settings: NarrationSettings):
        self.settings = settings
        self.transformations: list[Transformation] = []

    def _record(self, kind: str, original: str, replacement: str, count: int = 1) -> None:
        if original != replacement and count:
            self.transformations.append(Transformation(kind, original, replacement, count))

    def _replace(self, text: str, pattern: re.Pattern[str], repl, kind: str) -> str:
        hits: list[tuple[str, str]] = []

        def wrapped(match: re.Match[str]) -> str:
            original = match.group(0)
            replacement = repl(match) if callable(repl) else match.expand(repl)
            hits.append((original, replacement))
            return replacement

        result = pattern.sub(wrapped, text)
        for original, replacement in hits[:20]:
            self._record(kind, original, replacement)
        return result

    def transform(self, text: str) -> tuple[str, list[Transformation]]:
        self.transformations = []
        s = self.settings
        result = normalize_newlines(text)
        # Custom respellings are applied first and are visible in the preview.
        for original, replacement in s.pronunciation.items():
            if not original.strip() or not replacement.strip():
                continue
            pattern = re.compile(r"(?<!\w)" + re.escape(original.strip()) + r"(?!\w)", re.I)
            result, count = pattern.subn(lambda m, r=replacement.strip(): r, result)
            self._record("pronunciation", original, replacement.strip(), count)
        if s.expand_dates:
            result = self._replace(
                result,
                re.compile(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b"),
                lambda m: f"{MONTHS[int(m.group(2))-1]} {number_to_words(int(m.group(3)))}, {year_to_words(int(m.group(1)))}",
                "date",
            )
            result = self._replace(
                result,
                re.compile(r"\b(" + "|".join(MONTHS) + r")\s+(\d{1,2}),?\s+(\d{4})\b"),
                lambda m: f"{m.group(1)} {number_to_words(int(m.group(2)))}, {year_to_words(int(m.group(3)))}",
                "date",
            )
            result = self._replace(
                result,
                re.compile(r"\b(\d{1,2})\s+(" + "|".join(MONTHS) + r")\s+(\d{4})\b"),
                lambda m: f"{number_to_words(int(m.group(1)))} {m.group(2)} {year_to_words(int(m.group(3)))}",
                "date",
            )
        if s.expand_abbreviations:
            for abbreviation, expansion in _ABBREVIATIONS.items():
                pattern = re.compile(r"(?<!\w)" + re.escape(abbreviation) + r"(?!\w)")
                result, count = pattern.subn(expansion, result)
                self._record("abbreviation", abbreviation, expansion, count)
        if s.expand_currencies:
            currency_names = {"$": "dollars", "£": "pounds", "€": "euros", "₦": "naira"}
            symbols = re.escape("".join(currency_names))

            def currency(match: re.Match[str]) -> str:
                symbol, amount = match.group(1), match.group(2)
                whole, _, cents = amount.partition(".")
                words = decimal_to_words(whole)
                unit = currency_names[symbol]
                if cents:
                    return f"{words} {unit} and {number_to_words(int(cents))} cents"
                return f"{words} {unit}"

            result = self._replace(result, re.compile(rf"([{symbols}])\s*(\d[\d,]*(?:\.\d{{1,2}})?)"), currency, "currency")
        if s.expand_measurements:
            unit_pattern = "|".join(re.escape(k) for k in sorted(_UNITS, key=len, reverse=True))

            def measurement(match: re.Match[str]) -> str:
                return f"{decimal_to_words(match.group(1))} {_UNITS[match.group(2).lower()]}"

            result = self._replace(result, re.compile(rf"\b(\d+(?:\.\d+)?)\s*({unit_pattern})\b", re.I), measurement, "measurement")
        if s.expand_numbers:
            result = self._replace(result, re.compile(r"(?<!\w)(\d+(?:\.\d+)?)%(?!\w)"), lambda m: f"{decimal_to_words(m.group(1))} percent", "number")
            # Leave four-digit years to the date rules; expand other standalone numbers.
            result = self._replace(
                result,
                re.compile(r"(?<![\w./:-])(-?\d[\d,]*(?:\.\d+)?)(?![\w./:-])"),
                lambda m: decimal_to_words(m.group(1).replace(",", "")),
                "number",
            )
        if s.normalize_text:
            before = result
            result = (result.replace("“", '"').replace("”", '"')
                      .replace("‘", "'").replace("’", "'")
                      .replace("—", ", ").replace("–", ", "))
            result = re.sub(r"[ \t]+", " ", result)
            result = re.sub(r" *\n *", "\n", result)
            self._record("normalization", "typographic punctuation/whitespace", "speech-friendly punctuation")
        return result.strip(), list(self.transformations)


def _sentences(paragraph: str) -> list[str]:
    parts = re.findall(r"[^.!?…]+(?:[.!?…]+[\"'”’)\]]*|$)", paragraph, flags=re.S)
    return [p.strip() for p in parts if p.strip()]


def split_narration_chunks(text: str, settings: NarrationSettings | None = None) -> list[NarrationChunk]:
    """Split at paragraph, sentence, clause and word boundaries in that order.

    A chunk never exceeds ``chunk_max_chars`` unless a single word does.  The
    Kokoro worker additionally enforces the 510-phoneme model limit.
    """
    settings = settings or NarrationSettings()
    target = max(80, settings.chunk_target_chars)
    max_chars = max(target + 20, settings.chunk_max_chars)
    chunks: list[NarrationChunk] = []
    cursor = 0
    for p_index, paragraph in enumerate(re.split(r"\n\s*\n+", text)):
        paragraph = paragraph.strip()
        if not paragraph:
            continue
        paragraph_start = text.find(paragraph, cursor)
        cursor = paragraph_start + len(paragraph)
        sentences = _sentences(paragraph)
        pieces: list[str] = []
        for sentence in sentences:
            if len(sentence) <= max_chars:
                pieces.append(sentence)
                continue
            clauses = re.findall(r"[^,;:]+(?:[,;:]\s*|$)", sentence)
            if len(clauses) == 1:
                words = sentence.split()
                current = ""
                for word in words:
                    candidate = f"{current} {word}".strip()
                    if len(candidate) > max_chars and current:
                        pieces.append(current)
                        current = word
                    else:
                        current = candidate
                if current:
                    pieces.append(current)
            else:
                current = ""
                for clause in clauses:
                    candidate = f"{current} {clause}".strip()
                    if len(candidate) > max_chars and current:
                        pieces.append(current)
                        current = clause.strip()
                    else:
                        current = candidate
                if current:
                    pieces.append(current)
        current_piece = ""
        start_offset = 0
        for piece_index, piece in enumerate(pieces):
            candidate = f"{current_piece} {piece}".strip()
            if current_piece and len(candidate) > target:
                source_start = paragraph_start + start_offset
                chunks.append(NarrationChunk(
                    text=current_piece.strip(), paragraph_index=p_index,
                    pause_before_ms=settings.paragraph_pause_ms if p_index > 0 and not chunks else 0,
                    pause_after_ms=settings.sentence_pause_ms,
                    source_start=source_start, source_end=source_start + len(current_piece),
                ))
                start_offset += len(current_piece) + 1
                current_piece = piece
            else:
                current_piece = candidate
        if current_piece:
            source_start = paragraph_start + max(0, start_offset)
            chunks.append(NarrationChunk(
                text=current_piece.strip(), paragraph_index=p_index,
                pause_before_ms=settings.paragraph_pause_ms if p_index > 0 and not chunks else 0,
                pause_after_ms=settings.paragraph_pause_ms, paragraph_end=True,
                source_start=source_start, source_end=min(len(text), source_start + len(current_piece)),
            ))
    # Paragraph pauses belong before the first chunk of a new paragraph, not
    # after every chunk in that paragraph.
    last_paragraph = -1
    for chunk in chunks:
        if chunk.paragraph_index != last_paragraph:
            if chunk.paragraph_index > 0:
                chunk.pause_before_ms = max(chunk.pause_before_ms, settings.paragraph_pause_ms)
            last_paragraph = chunk.paragraph_index
        else:
            chunk.pause_before_ms = 0
    return chunks


def transformation_log_json(transformations: list[Transformation]) -> str:
    return json.dumps([asdict(t) for t in transformations], ensure_ascii=False, indent=2)
