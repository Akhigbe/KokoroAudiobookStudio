"""High-level UI actions shared by pages and the setup wizard."""
from __future__ import annotations

import os
import queue
import subprocess
import threading
from pathlib import Path
from typing import Any, Callable

import customtkinter as ctk
from tkinter import filedialog

from ..config import load_settings
from ..engine import EngineClient
from ..importers import ImportResult, import_file, import_pasted_text
from ..paths import cache_dir, voice_pack_path
from .dialogs import ImportPreviewDialog, PasteDialog
from .widgets import InfoDialog, font, palette

FILE_TYPES = [
    ("Supported manuscripts", "*.txt *.text *.md *.markdown *.docx *.pdf"),
    ("Text files", "*.txt *.text"), ("Markdown", "*.md *.markdown"),
    ("Word documents", "*.docx"), ("PDF documents", "*.pdf"), ("All files", "*.*"),
]


def run_async(parent, title: str, task: Callable[[], Any],
              on_done: Callable[[Any, Exception | None], None]) -> None:
    """Run a blocking local task off the Tk thread and report on the Tk thread."""
    colors = palette(ctk.get_appearance_mode().lower())
    dialog = ctk.CTkToplevel(parent)
    dialog.title(title)
    dialog.geometry("430x150")
    dialog.resizable(False, False)
    dialog.transient(parent)
    dialog.grab_set()
    dialog.configure(fg_color=colors["bg"])
    ctk.CTkLabel(dialog, text=title, font=font(16, "bold"), text_color=colors["text"]).pack(pady=(24, 8))
    bar = ctk.CTkProgressBar(dialog, mode="indeterminate", width=340)
    bar.pack(pady=(4, 10))
    bar.start()
    ctk.CTkLabel(dialog, text="Working locally. The interface remains available.",
                 font=font(11), text_color=colors["muted"]).pack()
    result_queue: queue.Queue[tuple[Any, Exception | None]] = queue.Queue()

    def worker() -> None:
        try:
            result_queue.put((task(), None))
        except Exception as exc:
            result_queue.put((None, exc))

    threading.Thread(target=worker, daemon=True, name="kas-async-task").start()

    def poll() -> None:
        try:
            result, error = result_queue.get_nowait()
        except queue.Empty:
            dialog.after(120, poll)
            return
        bar.stop()
        dialog.destroy()
        on_done(result, error)

    dialog.after(120, poll)


def create_project_from_result(ctx, result: ImportResult, name: str) -> None:
    chapters = [{"title": c.title, "text": c.text} for c in result.chapters]
    project = ctx.storage.create_project(
        name, chapters=chapters or [{"title": "Chapter 1", "text": ""}],
        settings=ctx.settings.narration, source_path=str(result.source_path) if hasattr(result, "source_path") else "",
        source_hash=result.source_hash,
    )
    ctx.set_active_project(project.id)
    ctx.refresh()


def new_project(ctx, parent) -> None:
    dialog = ctk.CTkInputDialog(text="Name your new audiobook project:", title="New project")
    name = dialog.get_input()
    if name and name.strip():
        project = ctx.storage.create_project(name.strip(), settings=ctx.settings.narration)
        ctx.set_active_project(project.id)
        ctx.refresh()


def import_project(ctx, parent, path: str | None = None) -> None:
    if not path:
        path = filedialog.askopenfilename(parent=parent, title="Import manuscript", filetypes=FILE_TYPES)
    if not path:
        return
    try:
        result = import_file(path)
    except Exception as exc:
        InfoDialog(parent, "Import failed", str(exc))
        return
    result.source_path = path  # type: ignore[attr-defined]
    name = Path(path).stem or "Imported manuscript"
    ImportPreviewDialog(parent, result, lambda: create_project_from_result(ctx, result, name))


def paste_project(ctx, parent) -> None:
    def on_import(title: str, text: str) -> None:
        result = import_pasted_text(text, title=title or "Pasted Manuscript")
        create_project_from_result(ctx, result, title or "Pasted Manuscript")
    PasteDialog(parent, on_import)


def backup_project(ctx, parent, project_id: str) -> None:
    project = ctx.storage.get_project(project_id)
    if not project:
        return
    path = filedialog.asksaveasfilename(parent=parent, title="Backup project",
                                        defaultextension=".kasbackup",
                                        initialfile=f"{project.name}.kasbackup",
                                        filetypes=[("Kokoro project backup", "*.kasbackup")])
    if not path:
        return
    try:
        ctx.storage.backup_project(project_id, path)
        InfoDialog(parent, "Backup complete", f"Project metadata and generated WAV chunks were saved to:\n{path}")
    except Exception as exc:
        InfoDialog(parent, "Backup failed", str(exc))


def restore_project(ctx, parent) -> None:
    path = filedialog.askopenfilename(parent=parent, title="Restore project backup",
                                      filetypes=[("Kokoro project backup", "*.kasbackup"), ("All files", "*.*")])
    if not path:
        return
    try:
        project = ctx.storage.restore_project(path)
        ctx.set_active_project(project.id)
        ctx.refresh()
        InfoDialog(parent, "Restore complete", f"Restored '{project.name}' as a new project. Existing projects were not modified.")
    except Exception as exc:
        InfoDialog(parent, "Restore failed", str(exc))


def reveal_path(parent, path: str | Path) -> None:
    p = Path(path)
    try:
        if os.name == "nt":
            if p.is_file():
                subprocess.Popen(["explorer", "/select,", str(p)])
            else:
                os.startfile(str(p))  # type: ignore[attr-defined]
        elif p.is_file():
            subprocess.Popen(["xdg-open", str(p.parent)])
        else:
            subprocess.Popen(["xdg-open", str(p)])
    except Exception as exc:
        InfoDialog(parent, "Could not open folder", str(exc))


def generate_voice_sample(ctx, voice_id: str) -> tuple[dict[str, Any], str]:
    """Generate and start playing a local sample for one installed voice."""
    from ..network_guard import set_offline
    settings = load_settings()
    set_offline(True)
    output = cache_dir() / f"voice_sample_{voice_id}.wav"
    client = EngineClient(model_path=str(ctx.resources.model_path(settings.model_id)),
                          voice_pack=str(voice_pack_path()), threads=settings.threads,
                          provider=settings.provider)
    try:
        result = client.synthesize_chunk(
            f"Hello. This is the {voice_id.replace('_', ' ')} voice, generated locally by Kokoro Audiobook Studio.",
            str(output), voice=voice_id, speed=1.0, lang="en-us",
        )
    finally:
        client.stop()
    if ctx.player:
        ctx.player.play(output)
    return result, str(output)


def offline_test(ctx, parent, *, mark_ready: bool = True,
                 on_done: Callable[[dict[str, Any], Exception | None], None] | None = None) -> None:
    def task() -> dict[str, Any]:
        return ctx.resources.offline_readiness_test(
            play=ctx.player is not None, player=ctx.player, mark_ready=mark_ready)

    def done(result: Any, error: Exception | None) -> None:
        if on_done:
            on_done(result, error)
        elif error:
            InfoDialog(parent, "Offline test failed", str(error))
        elif isinstance(result, dict) and not result.get("ok"):
            InfoDialog(parent, "Offline test failed",
                       "The local sample could not be fully verified. Open Model & Offline Status for details.")
        else:
            ctx.settings = load_settings(force=True)
            ctx.refresh()
            InfoDialog(parent, "Offline readiness confirmed",
                       "Kokoro generated and decoded a real speech sample with outbound network connections blocked.")

    run_async(parent, "Testing offline speech generation…", task, done)
