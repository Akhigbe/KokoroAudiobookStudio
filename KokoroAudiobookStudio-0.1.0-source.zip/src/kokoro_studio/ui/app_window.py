"""Main desktop shell: sidebar navigation, live status and event polling."""
from __future__ import annotations

import os
import time
from typing import Any

import customtkinter as ctk

from .. import APP_NAME, __version__
from ..config import load_settings
from .context import AppContext
from .pages_audio import LibraryPage, QueuePage, SettingsPage, StatusPage
from .pages_base import DashboardPage, ProjectsPage
from .pages_editor import ChaptersPage, ManuscriptPage, VoicesPage
from .setup_wizard import SetupWizard
from .widgets import ConfirmDialog, StatusPill, font, palette

NAV = [
    ("dashboard", "Dashboard", "◈", DashboardPage),
    ("projects", "My Projects", "◫", ProjectsPage),
    ("manuscript", "Manuscript Editor", "✎", ManuscriptPage),
    ("chapters", "Chapters", "☰", ChaptersPage),
    ("voices", "Voice Library", "♫", VoicesPage),
    ("queue", "Generation Queue", "◩", QueuePage),
    ("library", "Audio Library", "▷", LibraryPage),
    ("settings", "Settings", "⚙", SettingsPage),
    ("status", "Model & Offline Status", "◇", StatusPage),
]


class AppWindow(ctk.CTk):
    def __init__(self, *, headless: bool = False, skip_setup: bool = False):
        super().__init__()
        self.ctx = AppContext(headless=headless)
        self.ctx.set_offline(self.ctx.settings.offline_mode)
        self.skip_setup = skip_setup or bool(os.environ.get("KAS_SKIP_SETUP"))
        self.title(f"{APP_NAME} — local audiobook production")
        self.geometry("1320x840")
        self.minsize(1120, 720)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self.pages: dict[str, Any] = {}
        self.nav_buttons: dict[str, ctk.CTkButton] = {}
        self.current_key = "dashboard"
        self.wizard: SetupWizard | None = None
        self.last_refresh = 0.0
        self.protocol("WM_DELETE_WINDOW", self.close_app)
        self.build_shell()
        self.show_page("dashboard")
        self.after(150, self.poll_events)
        if not self.skip_setup:
            self.after(600, self.check_first_run)

    # ---------- shell ----------

    def build_shell(self) -> None:
        colors = palette(self.ctx.settings.theme)
        self.configure(fg_color=colors["bg"])
        sidebar = ctk.CTkFrame(self, width=232, corner_radius=0, fg_color=colors["sidebar"])
        sidebar.grid(row=0, column=0, rowspan=2, sticky="nsew")
        sidebar.grid_columnconfigure(0, weight=1)
        sidebar.grid_rowconfigure(20, weight=1)
        brand = ctk.CTkFrame(sidebar, fg_color="transparent")
        brand.grid(row=0, column=0, sticky="ew", padx=16, pady=(22, 18))
        brand.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(brand, text="K", font=font(24, "bold"), text_color="#FFFFFF",
                     fg_color=colors["accent"], corner_radius=10, width=42, height=42).grid(row=0, column=0, rowspan=2, padx=(0, 10))
        ctk.CTkLabel(brand, text="Kokoro", font=font(17, "bold"), text_color=colors["text"], anchor="w").grid(row=0, column=1, sticky="ew")
        ctk.CTkLabel(brand, text="Audiobook Studio", font=font(11), text_color=colors["muted"], anchor="w").grid(row=1, column=1, sticky="ew")
        for i, (key, label, icon, _) in enumerate(NAV):
            button = ctk.CTkButton(sidebar, text=f"  {icon}   {label}", anchor="w", height=38,
                                   corner_radius=9, font=font(12),
                                   fg_color="transparent", text_color=colors["muted"],
                                   hover_color=colors["surface_alt"],
                                   command=lambda k=key: self.show_page(k))
            button.grid(row=i + 1, column=0, sticky="ew", padx=10, pady=2)
            self.nav_buttons[key] = button
        ctk.CTkLabel(sidebar, text="LOCAL WORKSTATION", font=font(9, "bold"),
                     text_color=colors["muted"]).grid(row=19, column=0, sticky="w", padx=18, pady=(18, 4))
        self.offline_pill = StatusPill(sidebar, "Offline", "good" if self.ctx.settings.offline_mode else "warn")
        self.offline_pill.grid(row=20, column=0, sticky="sw", padx=14, pady=(0, 8))
        self.theme_button = ctk.CTkButton(sidebar, text="◐  Dark theme" if self.ctx.settings.theme != "dark" else "☀  Light theme",
                                           command=self.toggle_theme, height=34, corner_radius=9,
                                           fg_color=colors["surface_alt"], text_color=colors["text"])
        self.theme_button.grid(row=21, column=0, sticky="ew", padx=14, pady=(0, 8))
        ctk.CTkLabel(sidebar, text=f"v{__version__} · CPU-first · no telemetry", font=font(9),
                     text_color=colors["muted"]).grid(row=22, column=0, sticky="ew", padx=14, pady=(0, 16))

        topbar = ctk.CTkFrame(self, height=70, corner_radius=0, fg_color=colors["surface"],
                              border_width=0)
        topbar.grid(row=0, column=1, sticky="ew")
        topbar.grid_columnconfigure(1, weight=1)
        self.page_title = ctk.CTkLabel(topbar, text="Dashboard", font=font(20, "bold"),
                                        text_color=colors["text"], anchor="w")
        self.page_title.grid(row=0, column=0, padx=(26, 14), pady=16)
        self.project_menu = ctk.CTkOptionMenu(topbar, values=["No projects"], width=230,
                                               command=self.on_project_selected, font=font(11))
        self.project_menu.grid(row=0, column=1, sticky="w", padx=8)
        self.top_status = ctk.CTkLabel(topbar, text="", font=font(11), text_color=colors["muted"], anchor="e")
        self.top_status.grid(row=0, column=2, sticky="ew", padx=10)
        ctk.CTkButton(topbar, text="Setup", width=80, command=self.open_setup,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=3, padx=6, pady=14)
        ctk.CTkButton(topbar, text="Status", width=80, command=lambda: self.show_page("status"),
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=4, padx=(0, 22), pady=14)
        self.content = ctk.CTkFrame(self, fg_color=colors["bg"], corner_radius=0)
        self.content.grid(row=1, column=1, sticky="nsew")
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(0, weight=1)
        self.update_project_menu()
        self.update_status()

    def toggle_theme(self) -> None:
        self.ctx.toggle_theme()
        for widget in self.winfo_children():
            widget.destroy()
        self.pages.clear()
        self.nav_buttons.clear()
        self.ctx.clear_refresh_callbacks()
        self.build_shell()
        self.show_page(self.current_key)

    # ---------- pages ----------

    def show_page(self, key: str) -> None:
        if key not in {item[0] for item in NAV}:
            return
        self.current_key = key
        if key not in self.pages:
            cls = next(item[3] for item in NAV if item[0] == key)
            page = cls(self.content, self.ctx)
            page.grid(row=0, column=0, sticky="nsew")
            self.pages[key] = page
        for page_key, page in self.pages.items():
            page.grid_forget() if page_key != key else page.grid(row=0, column=0, sticky="nsew")
        for nav_key, button in self.nav_buttons.items():
            colors = palette(self.ctx.settings.theme)
            if nav_key == key:
                button.configure(fg_color=colors["accent"], text_color="#FFFFFF")
            else:
                button.configure(fg_color="transparent", text_color=colors["muted"])
        label = next(item[1] for item in NAV if item[0] == key)
        self.page_title.configure(text=label)
        self.pages[key].refresh()
        self.update_status()

    def update_project_menu(self) -> None:
        projects = self.ctx.storage.list_projects()
        self.project_map = {p.name: p.id for p in projects}
        values = list(self.project_map) or ["No projects"]
        self.project_menu.configure(values=values)
        active = self.ctx.active_project()
        if active and active.name in self.project_map:
            self.project_menu.set(active.name)
        else:
            self.project_menu.set(values[0])

    def on_project_selected(self, name: str) -> None:
        project_id = self.project_map.get(name)
        if project_id:
            self.ctx.set_active_project(project_id)

    def update_status(self) -> None:
        if not hasattr(self, "top_status"):
            return
        status = self.ctx.controller.snapshot()
        ready = self.ctx.resources.offline_ready()
        self.offline_pill.set_state("good" if self.ctx.settings.offline_mode else "warn",
                                    "Offline Ready" if ready and self.ctx.settings.offline_mode else
                                    "Offline mode" if self.ctx.settings.offline_mode else "Online for setup")
        self.top_status.configure(text=f"{status.state.title()} · {status.completed}/{status.total} chunks · "
                                       f"{'Low memory ON' if self.ctx.settings.low_memory_mode else 'Standard memory'} · "
                                       f"{self.ctx.settings.model_id}")

    # ---------- events ----------

    def poll_events(self) -> None:
        refresh = False
        generation_refresh = False
        try:
            while True:
                event = self.ctx.events.get_nowait()
                kind, data = event.get("type"), event.get("data", {})
                if kind == "navigate":
                    self.show_page(data.get("page", "dashboard"))
                    refresh = True
                elif kind == "setup":
                    self.open_setup()
                elif kind == "setup_complete":
                    self.ctx.settings = load_settings(force=True)
                    self.show_page("dashboard")
                    refresh = True
                elif kind == "generation":
                    generation_refresh = True
                elif kind in {"project", "offline"}:
                    refresh = True
        except Exception:
            pass
        now = time.monotonic()
        if refresh and now - self.last_refresh > 0.2:
            self.last_refresh = now
            self.update_project_menu()
            self.ctx.refresh()
            self.update_status()
        elif generation_refresh and now - self.last_refresh > 1.0:
            # Rebuilding every page on each worker progress event can starve Tk
            # on a 2-core/4 GB machine. One progress refresh per second is
            # smooth and keeps the event loop responsive.
            self.last_refresh = now
            self.ctx.refresh()
            self.update_status()
        elif generation_refresh:
            self.update_status()
        page = self.pages.get("library")
        if page and hasattr(page, "tick_player"):
            try:
                page.tick_player()
            except Exception:
                pass
        self.after(200, self.poll_events)

    def check_first_run(self) -> None:
        if self.skip_setup:
            return
        if not self.ctx.resources.offline_ready():
            self.open_setup()

    def open_setup(self) -> None:
        if self.wizard and self.wizard.winfo_exists():
            self.wizard.lift()
            return
        self.wizard = SetupWizard(self, self.ctx, on_complete=self.on_setup_complete)

    def on_setup_complete(self) -> None:
        self.ctx.settings = load_settings(force=True)
        self.update_project_menu()
        self.update_status()
        self.show_page("dashboard")

    def close_app(self) -> None:
        status = self.ctx.controller.snapshot()
        if status.state in {"running", "paused"}:
            ConfirmDialog(self, "Generation in progress",
                          "A generation job is active. Completed chunks are already saved and can be resumed later. Quit anyway?",
                          self._destroy)
            return
        self._destroy()

    def _destroy(self) -> None:
        try:
            self.ctx.controller.cancel()
        except Exception:
            pass
        if self.ctx.player:
            try:
                self.ctx.player.close()
            except Exception:
                pass
        self.destroy()
