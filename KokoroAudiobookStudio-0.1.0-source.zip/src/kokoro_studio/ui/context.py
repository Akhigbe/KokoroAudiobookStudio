"""Shared application state passed to every page."""
from __future__ import annotations

import queue
from typing import Any, Callable

from ..config import load_settings, save_settings
from ..generation import GenerationController
from ..logging_setup import get_logger
from ..models import AppSettings
from ..paths import resource_path
from ..player import AudioPlayer, PlayerError
from ..resources import ResourceManager
from ..storage import Storage
import customtkinter as ctk

log = get_logger(__name__)


class AppContext:
    def __init__(self, *, headless: bool = False):
        self.settings: AppSettings = load_settings()
        self.storage = Storage()
        self.resources = ResourceManager()
        self.events: queue.Queue[dict[str, Any]] = queue.Queue()
        self.controller = GenerationController(self.storage, self.resources,
                                               status_callback=lambda data: self.events.put({"type": "generation", "data": data}))
        self.player: AudioPlayer | None = None
        self.player_error = ""
        self.headless = headless
        self.active_project_id = self.settings.last_project_id
        self.refresh_callbacks: list[Callable[[], None]] = []
        self._player_backend = None
        if headless:
            try:
                import miniaudio
                self._player_backend = [miniaudio.Backend.NULL]
            except Exception:
                pass
        self.apply_theme(self.settings.theme)
        self.player = self._create_player()

    def _create_player(self) -> AudioPlayer | None:
        try:
            return AudioPlayer(backends=self._player_backend)
        except PlayerError as exc:
            self.player_error = str(exc)
            log.warning("Audio player unavailable: %s", exc)
            return None

    def apply_theme(self, theme: str) -> None:
        ctk.set_appearance_mode("light" if theme != "dark" else "dark")
        try:
            ctk.set_default_color_theme(str(resource_path("assets", "themes", "kokoro.json")))
        except Exception as exc:
            log.warning("Could not load custom theme: %s", exc)
            ctk.set_default_color_theme("blue")
        self.settings.theme = "light" if theme != "dark" else "dark"
        save_settings(self.settings)

    def toggle_theme(self) -> str:
        self.apply_theme("dark" if self.settings.theme != "dark" else "light")
        return self.settings.theme

    def set_offline(self, enabled: bool) -> None:
        from ..network_guard import set_offline
        self.settings.offline_mode = enabled
        save_settings(self.settings)
        set_offline(enabled)
        self.notify("offline", {"enabled": enabled})

    def active_project(self):
        if not self.active_project_id:
            return None
        project = self.storage.get_project(self.active_project_id)
        if not project:
            self.active_project_id = ""
            return None
        return project

    def set_active_project(self, project_id: str) -> None:
        self.active_project_id = project_id
        self.settings.last_project_id = project_id
        save_settings(self.settings)
        self.notify("project", {"id": project_id})

    def notify(self, kind: str, data: dict[str, Any] | None = None) -> None:
        self.events.put({"type": kind, "data": data or {}})

    def on_refresh(self, callback: Callable[[], None]) -> None:
        self.refresh_callbacks.append(callback)

    def clear_refresh_callbacks(self) -> None:
        self.refresh_callbacks.clear()

    def refresh(self) -> None:
        for callback in list(self.refresh_callbacks):
            try:
                callback()
            except Exception as exc:
                log.warning("page refresh failed: %s", exc)

    def status(self) -> dict[str, Any]:
        return self.controller.snapshot().to_dict()
