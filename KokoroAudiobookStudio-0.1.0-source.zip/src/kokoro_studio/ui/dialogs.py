"""Modal dialogs used by the desktop pages."""
from __future__ import annotations

from typing import Callable

import customtkinter as ctk

from .widgets import Card, font, palette


class ImportPreviewDialog(ctk.CTkToplevel):
    def __init__(self, master, result, on_import: Callable[[], None]):
        super().__init__(master)
        self.title("Review imported manuscript")
        self.geometry("760x660")
        self.minsize(640, 520)
        self.transient(master)
        self.grab_set()
        colors = palette(ctk.get_appearance_mode().lower())
        self.configure(fg_color=colors["bg"])
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=20, pady=(18, 8))
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(header, text=f"Import preview · {result.source_type.upper()}",
                     font=font(20, "bold"), text_color=colors["text"]).grid(row=0, column=0, sticky="w")
        summary = f"{len(result.chapters)} chapter(s) detected · {result.pages or 1} page(s) · SHA-256 {result.source_hash[:12]}…"
        ctk.CTkLabel(header, text=summary, font=font(12), text_color=colors["muted"]).grid(row=1, column=0, sticky="w", pady=(2, 0))
        card = Card(self)
        card.grid(row=1, column=0, sticky="nsew", padx=20, pady=8)
        card.grid_rowconfigure(0, weight=1)
        text = ctk.CTkTextbox(card, font=font(12), fg_color=colors["surface_alt"],
                              text_color=colors["text"], border_width=0, wrap="word")
        text.grid(row=0, column=0, sticky="nsew", padx=14, pady=14)
        warnings = "\n".join(f"• {w}" for w in result.warnings) or "• No extraction warnings."
        content = "EXTRACTION WARNINGS\n" + warnings + "\n\nCHAPTERS\n" + "\n".join(
            f"{i+1}. {c.title} — {len(c.text.split())} words" for c in result.chapters
        ) + "\n\nTEXT PREVIEW\n" + result.preview
        text.insert("1.0", content)
        text.configure(state="disabled")
        buttons = ctk.CTkFrame(self, fg_color="transparent")
        buttons.grid(row=2, column=0, sticky="e", padx=20, pady=(0, 18))
        ctk.CTkButton(buttons, text="Cancel", width=100, command=self.destroy,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=0, padx=6)
        ctk.CTkButton(buttons, text="Import project", width=140, font=font(12, "bold"),
                      command=lambda: (on_import(), self.destroy())).grid(row=0, column=1, padx=6)


class PasteDialog(ctk.CTkToplevel):
    def __init__(self, master, on_import: Callable[[str, str], None]):
        super().__init__(master)
        self.title("Paste manuscript text")
        self.geometry("720x560")
        self.minsize(600, 440)
        self.transient(master)
        self.grab_set()
        colors = palette(ctk.get_appearance_mode().lower())
        self.configure(fg_color=colors["bg"])
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=18, pady=(16, 6))
        header.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(header, text="Project title", font=font(12), text_color=colors["muted"]).grid(row=0, column=0, padx=(0, 8))
        title = ctk.CTkEntry(header, font=font(12))
        title.grid(row=0, column=1, sticky="ew")
        title.insert(0, "Pasted Manuscript")
        text = ctk.CTkTextbox(self, font=font(12), fg_color=colors["surface"],
                              text_color=colors["text"], border_width=1,
                              border_color=colors["border"], wrap="word")
        text.grid(row=1, column=0, sticky="nsew", padx=18, pady=8)
        buttons = ctk.CTkFrame(self, fg_color="transparent")
        buttons.grid(row=2, column=0, sticky="e", padx=18, pady=(0, 16))
        ctk.CTkButton(buttons, text="Cancel", width=100, command=self.destroy,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=0, padx=6)
        ctk.CTkButton(buttons, text="Create project", width=140, font=font(12, "bold"),
                      command=lambda: (on_import(title.get().strip(), text.get("1.0", "end-1c")), self.destroy())).grid(row=0, column=1, padx=6)


class KeyValueDialog(ctk.CTkToplevel):
    def __init__(self, master, title: str, key_label: str, value_label: str,
                 on_save: Callable[[str, str], None], initial_key: str = "", initial_value: str = ""):
        super().__init__(master)
        self.title(title)
        self.geometry("480x250")
        self.resizable(False, False)
        self.transient(master)
        self.grab_set()
        colors = palette(ctk.get_appearance_mode().lower())
        self.configure(fg_color=colors["bg"])
        card = Card(self, title=title)
        card.pack(fill="both", expand=True, padx=18, pady=18)
        card.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(card, text=key_label, font=font(12), text_color=colors["muted"]).grid(row=card.row, column=0, sticky="w", padx=18, pady=6)
        key_entry = ctk.CTkEntry(card, font=font(12))
        key_entry.grid(row=card.row, column=1, sticky="ew", padx=18, pady=6)
        key_entry.insert(0, initial_key)
        card.row += 1
        ctk.CTkLabel(card, text=value_label, font=font(12), text_color=colors["muted"]).grid(row=card.row, column=0, sticky="w", padx=18, pady=6)
        value_entry = ctk.CTkEntry(card, font=font(12))
        value_entry.grid(row=card.row, column=1, sticky="ew", padx=18, pady=6)
        value_entry.insert(0, initial_value)
        card.row += 1
        buttons = ctk.CTkFrame(card, fg_color="transparent")
        buttons.grid(row=card.row, column=0, columnspan=2, sticky="e", padx=18, pady=(16, 12))
        ctk.CTkButton(buttons, text="Cancel", width=90, command=self.destroy,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=0, padx=6)
        ctk.CTkButton(buttons, text="Save", width=90, font=font(12, "bold"),
                      command=lambda: (on_save(key_entry.get().strip(), value_entry.get().strip()), self.destroy())).grid(row=0, column=1, padx=6)


class SplitDialog(ctk.CTkToplevel):
    def __init__(self, master, chapter_title: str, paragraph_count: int,
                 on_split: Callable[[int], None]):
        super().__init__(master)
        self.title("Split chapter")
        self.geometry("500x260")
        self.resizable(False, False)
        self.transient(master)
        self.grab_set()
        colors = palette(ctk.get_appearance_mode().lower())
        self.configure(fg_color=colors["bg"])
        card = Card(self, title="Split chapter", subtitle=chapter_title)
        card.pack(fill="both", expand=True, padx=18, pady=18)
        ctk.CTkLabel(card, text=f"Split before paragraph (1–{max(1, paragraph_count-1)}):",
                     font=font(12), text_color=colors["text"]).grid(row=card.row, column=0, sticky="w", padx=18, pady=(6, 4))
        slider = ctk.CTkSlider(card, from_=1, to=max(1, paragraph_count - 1), number_of_steps=max(0, paragraph_count - 2))
        slider.set(max(1, paragraph_count // 2))
        slider.grid(row=card.row + 1, column=0, sticky="ew", padx=18, pady=6)
        value = ctk.CTkLabel(card, text=f"Paragraph {int(slider.get())}", font=font(12, "bold"), text_color=colors["accent"])
        value.grid(row=card.row + 2, column=0, sticky="w", padx=18)
        slider.configure(command=lambda v: value.configure(text=f"Paragraph {int(v)}"))
        buttons = ctk.CTkFrame(card, fg_color="transparent")
        buttons.grid(row=card.row + 3, column=0, sticky="e", padx=18, pady=(18, 12))
        ctk.CTkButton(buttons, text="Cancel", width=90, command=self.destroy,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=0, padx=6)
        ctk.CTkButton(buttons, text="Split", width=90, font=font(12, "bold"),
                      command=lambda: (on_split(int(slider.get())), self.destroy())).grid(row=0, column=1, padx=6)
