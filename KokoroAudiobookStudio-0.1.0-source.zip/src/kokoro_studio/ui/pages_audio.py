"""Generation queue, audio library/player, settings and model/offline status."""
from __future__ import annotations

from pathlib import Path

import customtkinter as ctk
from tkinter import filedialog

from ..config import load_settings, save_settings
from ..generation import Exporter
from ..paths import data_root, exports_dir, setup_report_path, voice_pack_path
from .actions import offline_test, reveal_path, run_async
from .pages_base import Page
from .widgets import (
    Card, ConfirmDialog, EmptyState, InfoDialog, StatusPill, Toolbar,
    font, format_bytes, format_clock, format_duration, palette,
)


class QueuePage(Page):
    def __init__(self, master, ctx):
        super().__init__(master, ctx, "Generation Queue",
                         "Sequential, resumable chunk generation with bounded memory and persistent progress",
                         "Generate all", lambda: self.start())
        self.selected_ids: set[str] = set()
        self.build()

    def build(self) -> None:
        self.clear()
        colors = self.colors
        top = Card(self.scroll, title="Job controls", subtitle="Only one inference step runs at a time. Completed WAV chunks are saved immediately.")
        top.grid(row=0, column=0, sticky="ew", padx=6, pady=(2, 8))
        controls = ctk.CTkFrame(top, fg_color="transparent")
        controls.grid(row=top.row, column=0, sticky="ew", padx=14, pady=(0, 8))
        for i, (text, command) in enumerate([
            ("Start / resume", self.start), ("Pause", lambda: self.ctx.controller.pause()),
            ("Resume", lambda: self.ctx.controller.resume()), ("Cancel", lambda: self.ctx.controller.cancel()),
            ("Regenerate selected", self.regenerate_selected), ("Retry failed", self.retry_failed),
        ]):
            ctk.CTkButton(controls, text=text, command=command, width=140, corner_radius=8,
                          fg_color=colors["accent"] if i in (0, 4) else colors["surface_alt"],
                          text_color="#FFFFFF" if i in (0, 4) else colors["text"],
                          font=font(11, "bold")).grid(row=0, column=i, padx=4, pady=4)
        controls.grid_columnconfigure(6, weight=1)
        self.progress_bar = ctk.CTkProgressBar(top, height=12)
        self.progress_bar.grid(row=top.row + 1, column=0, sticky="ew", padx=18, pady=(4, 6))
        self.progress_label = ctk.CTkLabel(top, text="Idle", font=font(12), text_color=colors["text"], anchor="w")
        self.progress_label.grid(row=top.row + 2, column=0, sticky="ew", padx=18, pady=(0, 5))
        self.memory_label = ctk.CTkLabel(top, text="", font=font(11), text_color=colors["muted"], anchor="w")
        self.memory_label.grid(row=top.row + 3, column=0, sticky="ew", padx=18, pady=(0, 12))
        chunks_card = Card(self.scroll, title="Chunks", subtitle="Select specific chunks to regenerate without rebuilding the rest of the audiobook.")
        chunks_card.grid(row=1, column=0, sticky="ew", padx=6, pady=8)
        self.chunks_frame = ctk.CTkFrame(chunks_card, fg_color="transparent")
        self.chunks_frame.grid(row=chunks_card.row, column=0, sticky="ew", padx=14, pady=(0, 14))
        self.chunks_frame.grid_columnconfigure(0, weight=1)
        self.refresh()

    def _project(self):
        return self.ctx.active_project()

    def start(self) -> None:
        project = self._project()
        if not project:
            InfoDialog(self.winfo_toplevel(), "No active project", "Open or create a project first.")
            return
        self.ctx.controller.start(project.id)

    def regenerate_selected(self) -> None:
        if not self.selected_ids:
            InfoDialog(self.winfo_toplevel(), "No chunks selected", "Select one or more chunks first.")
            return
        for chunk_id in self.selected_ids:
            self.ctx.storage.regenerate_chunk(chunk_id)
        self.start()

    def retry_failed(self) -> None:
        project = self._project()
        if not project:
            return
        failed = [c for c in self.ctx.storage.list_chunks(project.id) if c.status == "error"]
        for chunk in failed:
            self.ctx.storage.regenerate_chunk(chunk.id)
        if failed:
            self.start()
        else:
            InfoDialog(self.winfo_toplevel(), "No failed chunks", "There are no chunks above the retry limit.")

    def refresh(self) -> None:
        if not hasattr(self, "progress_bar"):
            return
        status = self.ctx.controller.snapshot()
        self.progress_bar.set(min(1.0, status.fraction))
        self.progress_label.configure(
            text=f"{status.state.title()} · {status.completed}/{status.total} chunks · elapsed {format_duration(status.elapsed)} · {status.message}")
        self.memory_label.configure(
            text=f"Available RAM: {status.memory_available_mb:.0f} MB · Worker RSS: {status.worker_rss_mb:.0f} MB · "
                 f"Low-memory mode: {'ON' if self.ctx.settings.low_memory_mode else 'OFF'} · "
                 + ("PAUSED: low memory" if status.low_memory_pause else "No estimated completion time is shown; progress is actual chunk completion."))
        for child in self.chunks_frame.winfo_children():
            child.destroy()
        project = self._project()
        chunks = self.ctx.storage.list_chunks(project.id) if project else []
        if not chunks:
            EmptyState(self.chunks_frame, "◩", "No chunks yet", "Import a manuscript, save the manuscript editor, then start generation.",
                       "Open manuscript", lambda: self.ctx.notify("navigate", {"page": "manuscript"})).grid(row=0, column=0, sticky="ew", pady=20)
            return
        chapters = {c.id: c for c in self.ctx.storage.list_chapters(project.id)}
        state_map = {"done": "good", "error": "error", "stale": "warn", "pending": "neutral"}
        for i, chunk in enumerate(chunks[:300]):
            row = ctk.CTkFrame(self.chunks_frame, fg_color=self.colors["surface_alt"], corner_radius=9)
            row.grid(row=i, column=0, sticky="ew", pady=3)
            row.grid_columnconfigure(3, weight=1)
            var = ctk.StringVar(value="on" if chunk.id in self.selected_ids else "off")
            checkbox = ctk.CTkCheckBox(row, text="", variable=var, onvalue="on", offvalue="off", width=24,
                                       command=lambda cid=chunk.id, v=var: self.selected_ids.add(cid) if v.get() == "on" else self.selected_ids.discard(cid))
            checkbox.grid(row=0, column=0, rowspan=2, padx=(10, 4), pady=8)
            StatusPill(row, chunk.status.upper(), state_map.get(chunk.status, "neutral")).grid(row=0, column=1, padx=4, pady=(8, 2), sticky="w")
            chapter = chapters.get(chunk.chapter_id)
            title = f"{chapter.idx+1:02d}. {chapter.title}" if chapter else "Unknown chapter"
            ctk.CTkLabel(row, text=f"{title} · chunk {chunk.idx+1} · {chunk.voice}", font=font(11, "bold"),
                         text_color=self.colors["text"], anchor="w").grid(row=0, column=2, sticky="w", padx=6, pady=(8, 2))
            snippet = chunk.narration_text.replace("\n", " ")[:150]
            ctk.CTkLabel(row, text=snippet, font=font(11), text_color=self.colors["muted"], anchor="w",
                         wraplength=720, justify="left").grid(row=1, column=2, columnspan=2, sticky="ew", padx=6, pady=(0, 6))
            detail = f"{format_duration(chunk.duration)} · {format_bytes(chunk.size_bytes)} · tries {chunk.tries}"
            if chunk.error:
                detail += f" · {chunk.error[:100]}"
            ctk.CTkLabel(row, text=detail, font=font(10), text_color=self.colors["red"] if chunk.error else self.colors["muted"],
                         anchor="w", wraplength=700, justify="left").grid(row=2, column=2, columnspan=2, sticky="ew", padx=6, pady=(0, 8))
        if len(chunks) > 300:
            ctk.CTkLabel(self.chunks_frame, text=f"Showing first 300 of {len(chunks)} chunks.",
                         font=font(11), text_color=self.colors["muted"]).grid(row=301, column=0, pady=8)


class LibraryPage(Page):
    def __init__(self, master, ctx):
        super().__init__(master, ctx, "Audio Library",
                         "Play completed chunks immediately, navigate chapters, and export WAV or MP3",
                         "Open export folder", lambda: reveal_path(master, exports_dir()))
        self.audio_items: list[dict] = []
        self.current_index = -1
        self.seeking = False
        self.build()

    def build(self) -> None:
        self.clear()
        colors = self.colors
        player = Card(self.scroll, title="Built-in player", subtitle="Streams one chunk or chapter file at a time; a full book waveform is never loaded into memory.")
        player.grid(row=0, column=0, sticky="ew", padx=6, pady=(2, 8))
        player.grid_columnconfigure(0, weight=1)
        controls = ctk.CTkFrame(player, fg_color="transparent")
        controls.grid(row=player.row, column=0, sticky="ew", padx=14, pady=(0, 6))
        self.play_button = ctk.CTkButton(controls, text="Play", command=self.play_current, width=80, corner_radius=8, font=font(12, "bold"))
        self.play_button.grid(row=0, column=0, padx=4, pady=6)
        ctk.CTkButton(controls, text="Pause", command=lambda: self.ctx.player and self.ctx.player.pause(), width=80,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=1, padx=4)
        ctk.CTkButton(controls, text="Resume", command=lambda: self.ctx.player and self.ctx.player.resume(), width=80,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=2, padx=4)
        ctk.CTkButton(controls, text="Stop", command=lambda: self.ctx.player and self.ctx.player.stop(), width=80,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=3, padx=4)
        ctk.CTkButton(controls, text="◀ Chunk", command=lambda: self.navigate(-1), width=90,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=4, padx=4)
        ctk.CTkButton(controls, text="Chunk ▶", command=lambda: self.navigate(1), width=90,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=5, padx=4)
        self.chapter_menu = ctk.CTkOptionMenu(controls, values=["All chapters"], width=190, command=self.on_chapter_selected)
        self.chapter_menu.grid(row=0, column=6, padx=4)
        controls.grid_columnconfigure(7, weight=1)
        self.seek_slider = ctk.CTkSlider(player, from_=0, to=1, command=self.on_seek)
        self.seek_slider.grid(row=player.row + 1, column=0, sticky="ew", padx=18, pady=(4, 2))
        self.seek_slider.bind("<ButtonPress-1>", lambda e: setattr(self, "seeking", True))
        self.seek_slider.bind("<ButtonRelease-1>", self.finish_seek)
        self.time_label = ctk.CTkLabel(player, text="0:00 / 0:00", font=font(11), text_color=colors["muted"], anchor="w")
        self.time_label.grid(row=player.row + 2, column=0, sticky="w", padx=18, pady=(0, 4))
        extra = ctk.CTkFrame(player, fg_color="transparent")
        extra.grid(row=player.row + 3, column=0, sticky="ew", padx=18, pady=(0, 12))
        extra.grid_columnconfigure(4, weight=1)
        ctk.CTkLabel(extra, text="Volume", font=font(11), text_color=colors["muted"]).grid(row=0, column=0, padx=(0, 6))
        self.volume = ctk.CTkSlider(extra, from_=0, to=1.5, command=lambda v: self.ctx.player and self.ctx.player.set_volume(v))
        self.volume.set(1.0)
        self.volume.grid(row=0, column=1, sticky="ew", padx=6)
        ctk.CTkLabel(extra, text="Review speed", font=font(11), text_color=colors["muted"]).grid(row=0, column=2, padx=(16, 6))
        self.speed_menu = ctk.CTkOptionMenu(extra, values=["0.75x", "1.0x", "1.25x", "1.5x", "2.0x"], width=90,
                                             command=lambda v: self.ctx.player and self.ctx.player.set_speed(float(v.rstrip("x"))))
        self.speed_menu.set("1.0x")
        self.speed_menu.grid(row=0, column=3, padx=6)
        self.player_status = ctk.CTkLabel(extra, text="", font=font(11), text_color=colors["muted"], anchor="e")
        self.player_status.grid(row=0, column=4, sticky="ew", padx=10)

        export = Card(self.scroll, title="Export", subtitle="Combine existing WAV chunks in source order, without loading the complete audiobook waveform into RAM.")
        export.grid(row=1, column=0, sticky="ew", padx=6, pady=8)
        export.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(export, text="Format", font=font(11), text_color=colors["muted"]).grid(row=export.row, column=0, padx=(18, 6), pady=8)
        self.format_menu = ctk.CTkOptionMenu(export, values=["wav", "mp3"], width=100, command=lambda v: self.on_format(v))
        self.format_menu.set(self.ctx.settings.output_format)
        self.format_menu.grid(row=export.row, column=1, sticky="w", padx=6, pady=8)
        ctk.CTkButton(export, text="Complete book", command=lambda: self.do_export("book"), width=140,
                      corner_radius=8, font=font(11, "bold")).grid(row=export.row, column=2, padx=5)
        ctk.CTkButton(export, text="Each chapter", command=lambda: self.do_export("chapters"), width=120,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=export.row, column=3, padx=5)
        ctk.CTkButton(export, text="Selected chapter", command=lambda: self.do_export("selected"), width=140,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=export.row, column=4, padx=5)
        self.bitrate_label = ctk.CTkLabel(export, text="", font=font(11), text_color=colors["muted"], anchor="w")
        self.bitrate_label.grid(row=export.row + 1, column=0, columnspan=5, sticky="ew", padx=18, pady=(0, 10))

        chunks = Card(self.scroll, title="Completed chunks", subtitle="Click Play to review any finished chunk before the rest of the book is generated.")
        chunks.grid(row=2, column=0, sticky="ew", padx=6, pady=8)
        self.chunks_frame = ctk.CTkFrame(chunks, fg_color="transparent")
        self.chunks_frame.grid(row=chunks.row, column=0, sticky="ew", padx=14, pady=(0, 14))
        self.chunks_frame.grid_columnconfigure(0, weight=1)
        exports = Card(self.scroll, title="Export files", subtitle="Final duration, size, location and completion status.")
        exports.grid(row=3, column=0, sticky="ew", padx=6, pady=8)
        self.exports_frame = ctk.CTkFrame(exports, fg_color="transparent")
        self.exports_frame.grid(row=exports.row, column=0, sticky="ew", padx=14, pady=(0, 14))
        self.exports_frame.grid_columnconfigure(0, weight=1)
        self.refresh()

    def on_format(self, value: str) -> None:
        self.ctx.settings.output_format = value
        save_settings(self.ctx.settings)
        self.bitrate_label.configure(text=f"MP3 bitrate: {self.ctx.settings.mp3_bitrate} kbps · WAV: 24 kHz PCM16." if value == "mp3" else "WAV: 24 kHz PCM16, lossless chunk assembly.")

    def on_chapter_selected(self, value: str) -> None:
        for i, item in enumerate(self.audio_items):
            if item["chapter_title"] == value:
                self.current_index = i
                self.play_current()
                return

    def on_seek(self, value: float) -> None:
        if self.ctx.player and self.ctx.player.duration:
            self.time_label.configure(text=f"{format_clock(value * self.ctx.player.duration)} / {format_clock(self.ctx.player.duration)}")

    def finish_seek(self, event=None) -> None:
        self.seeking = False
        if self.ctx.player and self.ctx.player.duration:
            self.ctx.player.seek(float(self.seek_slider.get()) * self.ctx.player.duration)

    def play_item(self, index: int) -> None:
        if not self.ctx.player:
            InfoDialog(self.winfo_toplevel(), "Playback unavailable", self.ctx.player_error or "No audio output device was detected.")
            return
        if not self.audio_items:
            return
        self.current_index = max(0, min(index, len(self.audio_items) - 1))
        item = self.audio_items[self.current_index]
        try:
            self.ctx.player.play(item["path"])
            self.player_status.configure(text=f"Playing {item['chapter_title']} · chunk {item['chunk_idx']+1}")
        except Exception as exc:
            InfoDialog(self.winfo_toplevel(), "Playback failed", str(exc))

    def play_current(self) -> None:
        self.play_item(self.current_index if self.current_index >= 0 else 0)

    def navigate(self, delta: int) -> None:
        self.play_item(self.current_index + delta)

    def do_export(self, kind: str) -> None:
        project = self.ctx.active_project()
        if not project:
            return
        chapter_ids = None
        if kind == "selected":
            selected_title = self.chapter_menu.get()
            chapters = [c for c in self.ctx.storage.list_chapters(project.id) if c.title == selected_title]
            if not chapters:
                InfoDialog(self.winfo_toplevel(), "Select a chapter", "Choose a chapter in the player first.")
                return
            chapter_ids = {chapters[0].id}

        def task():
            return Exporter(self.ctx.storage).export_project(project.id, kind=kind, chapter_ids=chapter_ids)

        def done(result, error) -> None:
            if error:
                InfoDialog(self.winfo_toplevel(), "Export failed", str(error))
            else:
                summary = "\n".join(f"• {r['path']} — {format_duration(r['duration'])}, {format_bytes(r['size'])}, completed" for r in result)
                InfoDialog(self.winfo_toplevel(), "Export complete", summary)
            self.ctx.refresh()
        run_async(self.winfo_toplevel(), "Assembling audio export…", task, done)

    def tick_player(self) -> None:
        if not hasattr(self, "seek_slider") or not self.ctx.player:
            return
        player = self.ctx.player
        player.tick()
        if player.duration and not self.seeking:
            self.seek_slider.set(min(1.0, player.position / player.duration))
            self.time_label.configure(text=f"{format_clock(player.position)} / {format_clock(player.duration)}")
        self.player_status.configure(text=("Playing" if player.playing else "Paused" if player.active else "Stopped") +
                                     (f" · {player.speed:.2f}x" if player.active else ""))

    def refresh(self) -> None:
        if not hasattr(self, "chunks_frame"):
            return
        for frame in (self.chunks_frame, self.exports_frame):
            for child in frame.winfo_children():
                child.destroy()
        project = self.ctx.active_project()
        self.audio_items = []
        if project:
            chapters = {c.id: c for c in self.ctx.storage.list_chapters(project.id)}
            for chunk in self.ctx.storage.list_chunks(project.id):
                if chunk.status == "done" and chunk.audio_path:
                    chapter = chapters.get(chunk.chapter_id)
                    self.audio_items.append({"path": chunk.audio_path, "chapter_title": chapter.title if chapter else "Unknown",
                                             "chapter_id": chunk.chapter_id, "chunk_idx": chunk.idx,
                                             "duration": chunk.duration, "size": chunk.size_bytes})
            values = ["All chapters"] + sorted({item["chapter_title"] for item in self.audio_items})
            self.chapter_menu.configure(values=values)
            if self.chapter_menu.get() not in values:
                self.chapter_menu.set(values[0])
        self.bitrate_label.configure(text=f"MP3 bitrate: {self.ctx.settings.mp3_bitrate} kbps · WAV: 24 kHz PCM16 · Export folder: {self.ctx.settings.output_dir or exports_dir()}")
        if not self.audio_items:
            ctk.CTkLabel(self.chunks_frame, text="No completed audio chunks yet.", font=font(12),
                         text_color=self.colors["muted"]).grid(row=0, column=0, sticky="w", pady=8)
        for i, item in enumerate(self.audio_items[:250]):
            row = ctk.CTkFrame(self.chunks_frame, fg_color=self.colors["surface_alt"], corner_radius=8)
            row.grid(row=i, column=0, sticky="ew", pady=3)
            row.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(row, text=f"{item['chapter_title']} · chunk {item['chunk_idx']+1} · {format_duration(item['duration'])} · {format_bytes(item['size'])}",
                         font=font(11), text_color=self.colors["text"], anchor="w").grid(row=0, column=0, sticky="ew", padx=12, pady=7)
            ctk.CTkButton(row, text="Play", width=70, command=lambda idx=i: self.play_item(idx), corner_radius=7).grid(row=0, column=1, padx=8, pady=5)
        exports = self.ctx.storage.list_exports(project.id) if project else []
        if not exports:
            ctk.CTkLabel(self.exports_frame, text="No exports yet.", font=font(12), text_color=self.colors["muted"]).grid(row=0, column=0, sticky="w", pady=8)
        for i, record in enumerate(exports[:30]):
            row = ctk.CTkFrame(self.exports_frame, fg_color=self.colors["surface_alt"], corner_radius=8)
            row.grid(row=i, column=0, sticky="ew", pady=3)
            row.grid_columnconfigure(0, weight=1)
            StatusPill(row, record.status.upper(), "good" if record.status == "completed" else "error" if record.status == "failed" else "warn").grid(row=0, column=0, sticky="w", padx=10, pady=(8, 2))
            ctk.CTkLabel(row, text=f"{record.path} · {format_duration(record.duration)} · {format_bytes(record.size_bytes)} · {record.format.upper()}",
                         font=font(11), text_color=self.colors["text"], anchor="w", wraplength=820,
                         justify="left").grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 8))
            ctk.CTkButton(row, text="Open folder", width=100, command=lambda p=record.path: reveal_path(self.winfo_toplevel(), p),
                          fg_color=self.colors["surface"], text_color=self.colors["text"]).grid(row=0, column=1, rowspan=2, padx=8, pady=6)


class SettingsPage(Page):
    def __init__(self, master, ctx):
        super().__init__(master, ctx, "Settings", "Narration, performance, privacy and output preferences",
                         "Save settings", lambda: self.save())
        self.widgets: dict[str, object] = {}
        self.build()

    def add_slider(self, parent, row: int, key: str, label: str, from_: float, to: float,
                   value: float, suffix: str = "", steps: int = 100):
        colors = self.colors
        ctk.CTkLabel(parent, text=label, font=font(12), text_color=colors["text"], anchor="w").grid(row=row, column=0, sticky="w", padx=18, pady=(7, 2))
        value_label = ctk.CTkLabel(parent, text=f"{value:g}{suffix}", font=font(11, "bold"), text_color=colors["accent"])
        value_label.grid(row=row, column=2, sticky="e", padx=18, pady=(7, 2))
        slider = ctk.CTkSlider(parent, from_=from_, to=to, number_of_steps=steps,
                               command=lambda v, k=key, vl=value_label, s=suffix: vl.configure(text=f"{v:.0f}{s}" if s == " ms" else f"{v:.2f}{s}"))
        slider.set(value)
        slider.grid(row=row + 1, column=0, columnspan=3, sticky="ew", padx=18, pady=(0, 8))
        self.widgets[key] = slider

    def add_switch(self, parent, row: int, key: str, label: str, value: bool):
        switch = ctk.CTkSwitch(parent, text=label, font=font(12), text_color=self.colors["text"])
        switch.grid(row=row, column=0, columnspan=3, sticky="w", padx=18, pady=6)
        if value:
            switch.select()
        self.widgets[key] = switch

    def build(self) -> None:
        self.clear()
        colors = self.colors
        s = self.ctx.settings
        n = s.narration
        narration = Card(self.scroll, title="Narration", subtitle="These rules affect the separate narration text, never the original manuscript.")
        narration.grid(row=0, column=0, sticky="ew", padx=6, pady=(2, 8))
        narration.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(narration, text="Default voice", font=font(12), text_color=colors["text"]).grid(row=narration.row, column=0, sticky="w", padx=18, pady=8)
        voices = self.ctx.resources.installed_voice_ids() or [n.default_voice]
        self.widgets["voice"] = ctk.CTkOptionMenu(narration, values=voices, width=180)
        self.widgets["voice"].set(n.default_voice if n.default_voice in voices else voices[0])
        self.widgets["voice"].grid(row=narration.row, column=1, sticky="w", padx=8, pady=8)
        narration.row += 1
        self.add_slider(narration, narration.row, "speed", "Speech rate", 0.75, 1.5, n.speed, "x", 75); narration.row += 2
        self.add_slider(narration, narration.row, "sentence_pause_ms", "Sentence pause", 0, 1000, n.sentence_pause_ms, " ms", 50); narration.row += 2
        self.add_slider(narration, narration.row, "clause_pause_ms", "Clause pause", 0, 600, n.clause_pause_ms, " ms", 30); narration.row += 2
        self.add_slider(narration, narration.row, "paragraph_pause_ms", "Paragraph pause", 0, 2000, n.paragraph_pause_ms, " ms", 50); narration.row += 2
        self.add_slider(narration, narration.row, "chapter_transition_ms", "Chapter transition", 0, 5000, n.chapter_transition_ms, " ms", 50); narration.row += 2
        toggle_frame = ctk.CTkFrame(narration, fg_color="transparent")
        toggle_frame.grid(row=narration.row, column=0, columnspan=3, sticky="ew", padx=12, pady=(0, 12))
        toggle_frame.grid_columnconfigure(0, weight=1)
        toggle_frame.grid_columnconfigure(1, weight=1)
        toggles = [
            ("normalize_text", "Normalize punctuation/whitespace", n.normalize_text),
            ("expand_abbreviations", "Expand common abbreviations", n.expand_abbreviations),
            ("expand_numbers", "Expand numbers and percentages", n.expand_numbers),
            ("expand_dates", "Expand dates", n.expand_dates),
            ("expand_currencies", "Expand currency amounts", n.expand_currencies),
            ("expand_measurements", "Expand measurements", n.expand_measurements),
            ("trim_silence", "Trim model edge silence (explicit opt-in)", n.trim_silence),
        ]
        for i, (key, label, value) in enumerate(toggles):
            switch = ctk.CTkSwitch(toggle_frame, text=label, font=font(11), text_color=colors["text"])
            switch.grid(row=i // 2, column=i % 2, sticky="w", padx=8, pady=5)
            if value:
                switch.select()
            self.widgets[key] = switch

        performance = Card(self.scroll, title="Performance & output", subtitle="Low-memory mode is ON by default and is the supported setting for 4 GB RAM computers.")
        performance.grid(row=1, column=0, sticky="ew", padx=6, pady=8)
        performance.grid_columnconfigure(1, weight=1)
        self.add_switch(performance, performance.row, "low_memory_mode", "Low-memory mode (one chunk at a time, model reload every 20 chunks)", s.low_memory_mode)
        performance.row += 1
        ctk.CTkLabel(performance, text="Inference threads", font=font(12), text_color=colors["text"]).grid(row=performance.row, column=0, sticky="w", padx=18, pady=6)
        self.widgets["threads"] = ctk.CTkOptionMenu(performance, values=["1", "2", "3", "4"], width=100)
        self.widgets["threads"].set(str(s.threads))
        self.widgets["threads"].grid(row=performance.row, column=1, sticky="w", padx=8, pady=6)
        performance.row += 1
        system = self.ctx.resources.system_info()
        providers = ["cpu"] + (["directml"] if system.directml_available else [])
        ctk.CTkLabel(performance, text="Execution provider", font=font(12), text_color=colors["text"]).grid(row=performance.row, column=0, sticky="w", padx=18, pady=6)
        self.widgets["provider"] = ctk.CTkOptionMenu(performance, values=providers, width=140)
        self.widgets["provider"].set(s.provider if s.provider in providers else "cpu")
        self.widgets["provider"].grid(row=performance.row, column=1, sticky="w", padx=8, pady=6)
        performance.row += 1
        ctk.CTkLabel(performance, text="Default export", font=font(12), text_color=colors["text"]).grid(row=performance.row, column=0, sticky="w", padx=18, pady=6)
        self.widgets["output_format"] = ctk.CTkOptionMenu(performance, values=["wav", "mp3"], width=100, command=lambda v: setattr(self.ctx.settings, "output_format", v))
        self.widgets["output_format"].set(s.output_format)
        self.widgets["output_format"].grid(row=performance.row, column=1, sticky="w", padx=8, pady=6)
        performance.row += 1
        self.add_slider(performance, performance.row, "mp3_bitrate", "MP3 bitrate", 64, 192, s.mp3_bitrate, " kbps", 16)
        performance.row += 2
        ctk.CTkLabel(performance, text="Export folder", font=font(12), text_color=colors["text"]).grid(row=performance.row, column=0, sticky="w", padx=18, pady=6)
        self.widgets["output_dir"] = ctk.CTkEntry(performance, font=font(11), placeholder_text=str(exports_dir()))
        self.widgets["output_dir"].insert(0, s.output_dir)
        self.widgets["output_dir"].grid(row=performance.row, column=1, sticky="ew", padx=8, pady=6)
        ctk.CTkButton(performance, text="Browse", width=90, command=self.browse_output,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=performance.row, column=2, padx=(0, 16), pady=6)

        privacy = Card(self.scroll, title="Privacy, theme and offline mode", subtitle="No account, telemetry, ads, cloud sync or online TTS fallback.")
        privacy.grid(row=2, column=0, sticky="ew", padx=6, pady=8)
        self.add_switch(privacy, privacy.row, "offline_mode", "Enforced offline mode (block outbound network calls in this process)", s.offline_mode)
        privacy.row += 1
        ctk.CTkLabel(privacy, text="Appearance", font=font(12), text_color=colors["text"]).grid(row=privacy.row, column=0, sticky="w", padx=18, pady=8)
        self.widgets["theme"] = ctk.CTkOptionMenu(privacy, values=["light", "dark"], width=120)
        self.widgets["theme"].set(s.theme)
        self.widgets["theme"].grid(row=privacy.row, column=1, sticky="w", padx=8, pady=8)
        privacy.row += 1
        ctk.CTkLabel(privacy, text=("Network is permitted only during first-run setup, explicit voice installation, or an explicit repair. "
                                    "Generation, import, playback, export and project storage are local-only."),
                     font=font(11), text_color=colors["muted"], wraplength=850, justify="left",
                     anchor="w").grid(row=privacy.row, column=0, columnspan=3, sticky="ew", padx=18, pady=(0, 14))
        ctk.CTkButton(self.scroll, text="Save settings", command=self.save, height=40, corner_radius=10,
                      font=font(13, "bold")).grid(row=3, column=0, sticky="ew", padx=8, pady=(4, 16))

    def browse_output(self) -> None:
        path = filedialog.askdirectory(parent=self.winfo_toplevel(), title="Choose export folder")
        if path:
            entry = self.widgets["output_dir"]
            entry.delete(0, "end")
            entry.insert(0, path)

    def save(self) -> None:
        s = self.ctx.settings
        w = self.widgets
        n = s.narration
        n.default_voice = w["voice"].get()
        n.speed = round(float(w["speed"].get()), 2)
        n.sentence_pause_ms = int(w["sentence_pause_ms"].get())
        n.clause_pause_ms = int(w["clause_pause_ms"].get())
        n.paragraph_pause_ms = int(w["paragraph_pause_ms"].get())
        n.chapter_transition_ms = int(w["chapter_transition_ms"].get())
        for key in ("normalize_text", "expand_abbreviations", "expand_numbers", "expand_dates",
                    "expand_currencies", "expand_measurements", "trim_silence"):
            setattr(n, key, bool(w[key].get()))
        s.low_memory_mode = bool(w["low_memory_mode"].get())
        s.threads = int(w["threads"].get())
        s.provider = w["provider"].get()
        s.output_format = w["output_format"].get()
        s.mp3_bitrate = int(w["mp3_bitrate"].get())
        s.output_dir = w["output_dir"].get().strip()
        new_offline = bool(w["offline_mode"].get())
        new_theme = w["theme"].get()
        save_settings(s)
        project = self.ctx.active_project()
        affected = 0
        if project:
            self.ctx.storage.update_project(project.id, settings=n)
            affected = len(self.ctx.storage.rebuild_chunks(project.id))
        if new_theme != s.theme:
            self.ctx.apply_theme(new_theme)
        self.ctx.set_offline(new_offline)
        self.ctx.refresh()
        InfoDialog(self.winfo_toplevel(), "Settings saved",
                   f"Preferences saved locally. {affected} chunk(s) were marked for regeneration because voice, rate or narration settings changed.")

    def refresh(self) -> None:
        # Rebuild only when the app explicitly refreshes all pages; avoid
        # discarding unsaved slider edits on every generation status event.
        if getattr(self, "_built_once", False):
            return
        self._built_once = True


class StatusPage(Page):
    def __init__(self, master, ctx):
        super().__init__(master, ctx, "Model & Offline Status",
                         "Pinned resource verification, local sample test, runtime provider and setup report",
                         "Run offline test", lambda: offline_test(ctx, master, on_done=lambda r, e: self.refresh()))
        self.build()

    def build(self) -> None:
        self.clear()
        colors = self.colors
        settings = load_settings()
        verification = self.ctx.resources.verify_resources(settings.model_id)
        system = self.ctx.resources.system_info()
        ready = self.ctx.resources.offline_ready()
        top = Card(self.scroll, title="Offline readiness", subtitle="This status is only true when a real local speech sample passed verification.")
        top.grid(row=0, column=0, sticky="ew", padx=6, pady=(2, 8))
        self.pill = StatusPill(top, "Offline Ready" if ready else "Not verified", "good" if ready else "warn")
        self.pill.grid(row=top.row, column=0, sticky="w", padx=18, pady=(2, 8))
        top.row += 1
        controls = ctk.CTkFrame(top, fg_color="transparent")
        controls.grid(row=top.row, column=0, sticky="w", padx=14, pady=(0, 12))
        ctk.CTkButton(controls, text="Generate & verify sample", command=lambda: offline_test(self.ctx, self.winfo_toplevel(), on_done=lambda r, e: self.refresh()),
                      corner_radius=8, font=font(11, "bold")).grid(row=0, column=0, padx=4)
        ctk.CTkButton(controls, text="Play last sample", command=self.play_sample,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=1, padx=4)
        ctk.CTkButton(controls, text="Open setup report", command=self.save_report,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=2, padx=4)
        ctk.CTkButton(controls, text="Run setup wizard", command=lambda: self.ctx.notify("setup"),
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=3, padx=4)
        self.offline_switch = ctk.CTkSwitch(top, text="Enforced offline mode", font=font(12),
                                            command=lambda: self.ctx.set_offline(bool(self.offline_switch.get())))
        if settings.offline_mode:
            self.offline_switch.select()
        self.offline_switch.grid(row=top.row + 1, column=0, sticky="w", padx=18, pady=(0, 12))

        model = self.ctx.resources.model(settings.model_id)
        model_path = self.ctx.resources.model_path(settings.model_id)
        model_check = self.ctx.resources.verify_asset(model, model_path)
        model_card = Card(self.scroll, title="Selected model", subtitle="Official Kokoro v1.0 ONNX, pinned to a known commit.")
        model_card.grid(row=1, column=0, sticky="ew", padx=6, pady=8)
        model_text = (f"Model: {model['label']} ({settings.model_id})\n"
                      f"Source: {model['url']}\n"
                      f"Pinned revision: {self.ctx.resources.revision}\n"
                      f"Local path: {model_path}\n"
                      f"Size: {format_bytes(model['size'])} · SHA-256: {model['sha256']}\n"
                      f"Verification: {'PASS' if model_check.ok else 'FAIL'} — {model_check.detail}\n"
                      f"License: Apache-2.0 · 24 kHz mono output · 510-phoneme context")
        ctk.CTkLabel(model_card, text=model_text, font=font(11), text_color=colors["text"],
                     justify="left", anchor="nw", wraplength=950).grid(row=model_card.row, column=0, sticky="ew", padx=18, pady=(0, 14))

        runtime = Card(self.scroll, title="Runtime, voices and language resources", subtitle="No runtime files are downloaded during normal production.")
        runtime.grid(row=2, column=0, sticky="ew", padx=6, pady=8)
        try:
            import espeakng_loader
            espeak = f"{espeakng_loader.get_library_path()} · data {espeakng_loader.get_data_path()}"
        except Exception as exc:
            espeak = f"unavailable: {exc}"
        voices = verification.installed_voices
        runtime_text = (f"Application version: {__import__('kokoro_studio').__version__}\n"
                        f"Runtime: kokoro-onnx 0.6.1 · ONNX Runtime 1.22.1 · {'/'.join(system.providers[:3])}\n"
                        f"Optional DirectML: {'detected' if system.directml_available else 'not installed — CPU is the supported default'}\n"
                        f"OS: {system.os} · {system.architecture} · {system.cpu_count} logical CPUs · {system.total_memory_mb:.0f} MB RAM\n"
                        f"Voice pack: {format_bytes(self.ctx.resources.voice_pack_size())} · {len(voices)} voices: {', '.join(voices[:12])}{'…' if len(voices)>12 else ''}\n"
                        f"eSpeak NG phonemizer: {espeak}\n"
                        f"Data root: {data_root()}\n"
                        f"Low-memory mode: {'ON' if settings.low_memory_mode else 'OFF'} · threads: {settings.threads} · provider: {settings.provider}")
        ctk.CTkLabel(runtime, text=runtime_text, font=font(11), text_color=colors["text"],
                     justify="left", anchor="nw", wraplength=950).grid(row=runtime.row, column=0, sticky="ew", padx=18, pady=(0, 14))

        checks = Card(self.scroll, title="Resource verification", subtitle="Checksums and bundled phonemizer data are checked on demand.")
        checks.grid(row=3, column=0, sticky="ew", padx=6, pady=8)
        self.checks_frame = ctk.CTkFrame(checks, fg_color="transparent")
        self.checks_frame.grid(row=checks.row, column=0, sticky="ew", padx=14, pady=(0, 14))
        self.checks_frame.grid_columnconfigure(0, weight=1)
        for i, check in enumerate(verification.checks):
            row = ctk.CTkFrame(self.checks_frame, fg_color=colors["surface_alt"], corner_radius=8)
            row.grid(row=i, column=0, sticky="ew", pady=3)
            StatusPill(row, "PASS" if check.ok else "FAIL", "good" if check.ok else "error").grid(row=0, column=0, padx=10, pady=7, sticky="w")
            ctk.CTkLabel(row, text=f"{check.name} — {check.detail}", font=font(11), text_color=colors["text"],
                         anchor="w", wraplength=820, justify="left").grid(row=0, column=1, sticky="ew", padx=8, pady=7)

        policy = Card(self.scroll, title="Network policy", subtitle="Transparent by design.")
        policy.grid(row=4, column=0, sticky="ew", padx=6, pady=8)
        ctk.CTkLabel(policy, text=("Setup downloads only the selected model and voice .bin files from a pinned Hugging Face commit, using checksum verification. "
                                   "Adding a voice later or repairing resources requires an explicit online action. The application has no telemetry, no account, "
                                   "no cloud inference, no mandatory update synchronization, and no hidden online TTS fallback. When offline mode is on, the process blocks outbound sockets."),
                     font=font(11), text_color=colors["muted"], wraplength=950, justify="left",
                     anchor="nw").grid(row=policy.row, column=0, sticky="ew", padx=18, pady=(0, 14))
        if ready:
            report = self.ctx.resources.offline_report()
            ctk.CTkLabel(policy, text=f"Last verified sample: {report.get('timestamp','unknown')} · voice {report.get('voice','unknown')} · "
                                      f"WAV {report.get('sample','unknown')} · generated: {'yes' if report.get('ok') else 'no'}",
                         font=font(10), text_color=colors["muted"], wraplength=950,
                         justify="left", anchor="w").grid(row=policy.row + 1, column=0, sticky="ew", padx=18, pady=(0, 14))

    def play_sample(self) -> None:
        report = self.ctx.resources.offline_report()
        path = report.get("sample")
        if not path or not Path(path).is_file():
            InfoDialog(self.winfo_toplevel(), "No sample", "Run the offline readiness test first.")
            return
        if not self.ctx.player:
            InfoDialog(self.winfo_toplevel(), "Playback unavailable", self.ctx.player_error)
            return
        try:
            self.ctx.player.play(path)
            InfoDialog(self.winfo_toplevel(), "Playing sample", f"Playing the locally generated WAV sample:\n{path}")
        except Exception as exc:
            InfoDialog(self.winfo_toplevel(), "Playback failed", str(exc))

    def save_report(self) -> None:
        source = setup_report_path()
        if not source.is_file():
            InfoDialog(self.winfo_toplevel(), "Report unavailable", "Run first-time setup or the offline readiness test first.")
            return
        path = filedialog.asksaveasfilename(parent=self.winfo_toplevel(), title="Save setup report",
                                            defaultextension=".json", initialfile="kokoro-setup-report.json",
                                            filetypes=[("JSON report", "*.json")])
        if path:
            import shutil
            shutil.copy2(source, path)
            InfoDialog(self.winfo_toplevel(), "Report saved", f"Setup report copied to:\n{path}")

    def refresh(self) -> None:
        self.build()
