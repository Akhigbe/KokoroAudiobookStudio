"""Base page, dashboard and project management page."""
from __future__ import annotations

import time
import customtkinter as ctk

from ..config import load_settings
from .actions import backup_project, import_project, new_project, offline_test, paste_project, restore_project
from .dialogs import ImportPreviewDialog
from .widgets import (
    Card, ConfirmDialog, EmptyState, InfoDialog, SectionHeader, StatCard,
    StatusPill, Toolbar, font, format_bytes, format_duration, palette,
)


class Page(ctk.CTkFrame):
    def __init__(self, master, ctx, title: str, subtitle: str = "", action_text: str = "", action=None):
        colors = palette(ctk.get_appearance_mode().lower())
        super().__init__(master, fg_color=colors["bg"], corner_radius=0)
        self.ctx = ctx
        self.colors = colors
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self.header = SectionHeader(self, title, subtitle, action_text, action)
        self.header.grid(row=0, column=0, sticky="ew", padx=28, pady=(24, 12))
        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent",
                                             scrollbar_button_color=colors["border"],
                                             scrollbar_button_hover_color=colors["muted"])
        self.scroll.grid(row=1, column=0, sticky="nsew", padx=22, pady=(0, 20))
        self.scroll.grid_columnconfigure(0, weight=1)
        ctx.on_refresh(self.refresh)

    def clear(self) -> None:
        for child in self.scroll.winfo_children():
            child.destroy()

    def refresh(self) -> None:
        pass


class DashboardPage(Page):
    def __init__(self, master, ctx):
        super().__init__(master, ctx, "Dashboard", "Local production status at a glance",
                         "New project", lambda: new_project(ctx, master))
        self._last_system_update = 0.0
        self._last_event_ids: tuple | None = None
        self.build()

    def build(self) -> None:
        self.clear()
        colors = self.colors
        stats = ctk.CTkFrame(self.scroll, fg_color="transparent")
        stats.grid(row=0, column=0, sticky="ew", pady=(2, 12))
        for i in range(4):
            stats.grid_columnconfigure(i, weight=1, uniform="stat")
        self.stat_projects = StatCard(stats, "Projects", "0", "local SQLite projects", "◫")
        self.stat_chapters = StatCard(stats, "Chapters", "0", "detected in active project", "☰")
        self.stat_chunks = StatCard(stats, "Chunks", "0 / 0", "completed / total", "◩")
        self.stat_audio = StatCard(stats, "Generated audio", "0:00", "saved immediately as WAV", "♫")
        for i, card in enumerate((self.stat_projects, self.stat_chapters, self.stat_chunks, self.stat_audio)):
            card.grid(row=0, column=i, sticky="ew", padx=6, pady=4)

        row = ctk.CTkFrame(self.scroll, fg_color="transparent")
        row.grid(row=1, column=0, sticky="ew", pady=8)
        row.grid_columnconfigure(0, weight=2)
        row.grid_columnconfigure(1, weight=1)

        readiness = Card(row, title="Offline readiness", subtitle="A verified local sample is required before the app reports Offline Ready.")
        readiness.grid(row=0, column=0, sticky="nsew", padx=6, pady=4)
        self.readiness_pill = StatusPill(readiness, "Checking…", "warn")
        self.readiness_pill.grid(row=readiness.row, column=0, sticky="w", padx=18, pady=(2, 8))
        readiness.row += 1
        self.readiness_label = ctk.CTkLabel(readiness, text="", font=font(12), text_color=colors["muted"],
                                             wraplength=520, justify="left", anchor="nw")
        self.readiness_label.grid(row=readiness.row, column=0, sticky="ew", padx=18, pady=(0, 8))
        readiness.row += 1
        actions = ctk.CTkFrame(readiness, fg_color="transparent")
        actions.grid(row=readiness.row, column=0, sticky="w", padx=14, pady=(0, 14))
        ctk.CTkButton(actions, text="Run offline readiness test", command=lambda: offline_test(self.ctx, self.winfo_toplevel()),
                      corner_radius=9, font=font(12, "bold")).grid(row=0, column=0, padx=4)
        ctk.CTkButton(actions, text="Model & status", command=lambda: self.ctx.notify("navigate", {"page": "status"}),
                      corner_radius=9, fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=1, padx=4)

        system = Card(row, title="This computer", subtitle="Measured locally; no hardware data is uploaded.")
        system.grid(row=0, column=1, sticky="nsew", padx=6, pady=4)
        self.system_label = ctk.CTkLabel(system, text="", font=font(12), text_color=colors["text"],
                                          justify="left", anchor="nw", wraplength=340)
        self.system_label.grid(row=system.row, column=0, sticky="ew", padx=18, pady=(0, 16))

        progress = Card(self.scroll, title="Generation queue", subtitle="Actual chunk completion — no invented completion time.")
        progress.grid(row=2, column=0, sticky="ew", padx=6, pady=8)
        self.progress_bar = ctk.CTkProgressBar(progress, height=12, corner_radius=6)
        self.progress_bar.grid(row=progress.row, column=0, sticky="ew", padx=18, pady=(2, 8))
        self.progress_bar.set(0)
        self.progress_label = ctk.CTkLabel(progress, text="Idle", font=font(12), text_color=colors["muted"], anchor="w")
        self.progress_label.grid(row=progress.row + 1, column=0, sticky="ew", padx=18, pady=(0, 8))
        actions2 = ctk.CTkFrame(progress, fg_color="transparent")
        actions2.grid(row=progress.row + 2, column=0, sticky="w", padx=14, pady=(0, 14))
        ctk.CTkButton(actions2, text="Import manuscript", command=lambda: import_project(self.ctx, self.winfo_toplevel()),
                      corner_radius=9, font=font(12, "bold")).grid(row=0, column=0, padx=4)
        ctk.CTkButton(actions2, text="Paste text", command=lambda: paste_project(self.ctx, self.winfo_toplevel()),
                      corner_radius=9, fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=1, padx=4)
        ctk.CTkButton(actions2, text="Generate all", command=self.start_generation,
                      corner_radius=9, fg_color=colors["teal"]).grid(row=0, column=2, padx=4)
        ctk.CTkButton(actions2, text="Open queue", command=lambda: self.ctx.notify("navigate", {"page": "queue"}),
                      corner_radius=9, fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=3, padx=4)

        activity = Card(self.scroll, title="Recent activity", subtitle="Stored locally in the project database.")
        activity.grid(row=3, column=0, sticky="ew", padx=6, pady=8)
        self.activity_frame = ctk.CTkFrame(activity, fg_color="transparent")
        self.activity_frame.grid(row=activity.row, column=0, sticky="ew", padx=18, pady=(0, 16))
        self.activity_frame.grid_columnconfigure(0, weight=1)
        self.refresh()

    def start_generation(self) -> None:
        project = self.ctx.active_project()
        if not project:
            InfoDialog(self.winfo_toplevel(), "No active project", "Create or open a project before generating audio.")
            return
        self.ctx.controller.start(project.id)
        self.ctx.notify("navigate", {"page": "queue"})

    def refresh(self) -> None:
        if not hasattr(self, "stat_projects"):
            return
        projects = self.ctx.storage.list_projects()
        project = self.ctx.active_project()
        stats = self.ctx.storage.project_stats(project.id) if project else {}
        self.stat_projects.set_value(str(len(projects)), f"{'Active: ' + project.name if project else 'No active project'}")
        self.stat_chapters.set_value(str(stats.get("chapters", 0)), "in active project")
        self.stat_chunks.set_value(f"{stats.get('done', 0)} / {stats.get('chunks', 0)}",
                                   f"{stats.get('stale', 0)} stale · {stats.get('errors', 0)} errors")
        self.stat_audio.set_value(format_duration(stats.get("duration", 0.0)),
                                  f"{format_bytes(stats.get('bytes', 0))} of WAV chunks")
        ready = self.ctx.resources.offline_ready()
        self.readiness_pill.set_state("good" if ready else "warn", "Offline Ready" if ready else "Setup Required")
        settings = load_settings()
        self.readiness_label.configure(
            text=f"Mode: {'enforced OFFLINE' if settings.offline_mode else 'online for setup'} · "
                 f"Low-memory mode: {'ON' if settings.low_memory_mode else 'OFF'} · "
                 f"Default model: {settings.model_id} · "
                 + ("A verified sample exists in stable app data." if ready else "Run setup or the readiness test to generate a verified speech sample."))
        now = time.monotonic()
        if now - self._last_system_update > 5.0:
            system = self.ctx.resources.system_info()
            self.system_label.configure(
                text=f"OS: {system.os}\nArchitecture: {system.architecture}\n"
                     f"Logical CPUs: {system.cpu_count}\nRAM: {system.total_memory_mb:.0f} MB total / {system.available_memory_mb:.0f} MB available\n"
                     f"Free disk: {system.free_disk_mb/1024:.1f} GB\nRuntime: {', '.join(system.providers[:3])}\n"
                     f"Optional DirectML: {'detected' if system.directml_available else 'not installed (CPU works)'}")
            self._last_system_update = now
        status = self.ctx.controller.snapshot()
        self.progress_bar.set(min(1.0, status.fraction))
        label = f"{status.state.title()} · {status.completed}/{status.total} chunks · {status.message}"
        if status.worker_rss_mb:
            label += f" · worker {status.worker_rss_mb:.0f} MB"
        self.progress_label.configure(text=label)
        events = self.ctx.storage.list_events(limit=6)
        event_ids = tuple(event["id"] for event in events)
        if event_ids == self._last_event_ids:
            return
        self._last_event_ids = event_ids
        for child in self.activity_frame.winfo_children():
            child.destroy()
        if not events:
            ctk.CTkLabel(self.activity_frame, text="No activity yet.", font=font(12),
                         text_color=self.colors["muted"]).grid(row=0, column=0, sticky="w", pady=4)
        for i, event in enumerate(events):
            frame = ctk.CTkFrame(self.activity_frame, fg_color=self.colors["surface_alt"], corner_radius=8)
            frame.grid(row=i, column=0, sticky="ew", pady=3)
            frame.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(frame, text=event["message"], font=font(11), text_color=self.colors["text"],
                         anchor="w", wraplength=700, justify="left").grid(row=0, column=0, sticky="ew", padx=12, pady=6)
            ctk.CTkLabel(frame, text=event["created_at"].replace("T", " ")[:16], font=font(10),
                         text_color=self.colors["muted"]).grid(row=0, column=1, padx=10)


class ProjectsPage(Page):
    def __init__(self, master, ctx):
        super().__init__(master, ctx, "My Projects", "Create, back up, restore and organize local audiobook projects",
                         "New project", lambda: new_project(ctx, master))
        self.build()

    def build(self) -> None:
        self.clear()
        colors = self.colors
        toolbar = Toolbar(self.scroll)
        toolbar.grid(row=0, column=0, sticky="ew", padx=6, pady=(2, 12))
        toolbar.configure(fg_color=colors["surface"])
        toolbar.add("New project", lambda: new_project(self.ctx, self.winfo_toplevel()), primary=True)
        toolbar.add("Import file", lambda: import_project(self.ctx, self.winfo_toplevel()))
        toolbar.add("Paste text", lambda: paste_project(self.ctx, self.winfo_toplevel()))
        toolbar.add("Restore backup", lambda: restore_project(self.ctx, self.winfo_toplevel()))
        projects = self.ctx.storage.list_projects()
        if not projects:
            empty = EmptyState(self.scroll, "◫", "No projects yet",
                               "Start with a new project, import TXT/Markdown/DOCX/PDF, or paste manuscript text. Everything stays in stable local app data.",
                               "Import manuscript", lambda: import_project(self.ctx, self.winfo_toplevel()))
            empty.grid(row=1, column=0, sticky="ew", padx=6, pady=30)
            return
        for i, project in enumerate(projects):
            stats = self.ctx.storage.project_stats(project.id)
            card = Card(self.scroll)
            card.grid(row=i + 1, column=0, sticky="ew", padx=6, pady=6)
            card.grid_columnconfigure(1, weight=1)
            active = project.id == self.ctx.active_project_id
            pill = StatusPill(card, "Active" if active else "Local", "accent" if active else "neutral")
            pill.grid(row=0, column=0, padx=(18, 8), pady=(14, 4), sticky="w")
            ctk.CTkLabel(card, text=project.name, font=font(17, "bold"),
                         text_color=colors["text"], anchor="w").grid(row=0, column=1, sticky="ew", pady=(14, 4))
            detail = (f"{stats['chapters']} chapters · {stats['done']}/{stats['chunks']} chunks · "
                      f"{format_duration(stats['duration'])} audio · updated {project.updated_at.replace('T',' ')[:16]}")
            ctk.CTkLabel(card, text=detail, font=font(11), text_color=colors["muted"],
                         anchor="w").grid(row=1, column=0, columnspan=3, sticky="ew", padx=18, pady=(0, 10))
            buttons = ctk.CTkFrame(card, fg_color="transparent")
            buttons.grid(row=2, column=0, columnspan=3, sticky="w", padx=14, pady=(0, 14))
            actions = [
                ("Open", lambda p=project: self.open_project(p.id)),
                ("Rename", lambda p=project: self.rename(p.id, p.name)),
                ("Duplicate", lambda p=project: self.duplicate(p.id, p.name)),
                ("Backup", lambda p=project: backup_project(self.ctx, self.winfo_toplevel(), p.id)),
                ("Delete", lambda p=project: self.delete(p.id, p.name)),
            ]
            for j, (text, command) in enumerate(actions):
                fg = colors["red"] if text == "Delete" else colors["surface_alt"]
                tc = "#FFFFFF" if text == "Delete" else colors["text"]
                ctk.CTkButton(buttons, text=text, command=command, width=90, corner_radius=8,
                              fg_color=fg, hover_color=colors["red_bg"] if text == "Delete" else colors["border"],
                              text_color=tc).grid(row=0, column=j, padx=4)

    def open_project(self, project_id: str) -> None:
        self.ctx.set_active_project(project_id)
        self.ctx.notify("navigate", {"page": "manuscript"})

    def rename(self, project_id: str, current: str) -> None:
        dialog = ctk.CTkInputDialog(text="Project name:", title="Rename project")
        name = dialog.get_input()
        if name and name.strip():
            self.ctx.storage.rename_project(project_id, name.strip())
            self.ctx.refresh()

    def duplicate(self, project_id: str, name: str) -> None:
        project = self.ctx.storage.duplicate_project(project_id, f"{name} (copy)")
        if project:
            self.ctx.set_active_project(project.id)
            self.ctx.refresh()

    def delete(self, project_id: str, name: str) -> None:
        ConfirmDialog(self.winfo_toplevel(), "Delete project",
                      f"Delete '{name}' and its locally generated audio? Export files outside the project folder are not deleted. This cannot be undone.",
                      lambda: (self.ctx.storage.delete_project(project_id), self.ctx.refresh()))

    def refresh(self) -> None:
        self.build()
