"""Manuscript, chapter and voice-library pages."""
from __future__ import annotations

import customtkinter as ctk

from ..config import save_settings
from ..text_processing import clean_extracted_text
from .actions import generate_voice_sample, import_project, paste_project, run_async
from .dialogs import KeyValueDialog, SplitDialog
from .pages_base import Page
from .widgets import Card, ConfirmDialog, EmptyState, InfoDialog, StatusPill, Toolbar, font, format_bytes, palette


class ManuscriptPage(Page):
    def __init__(self, master, ctx):
        super().__init__(master, ctx, "Manuscript Editor",
                         "Original text stays separate from the narration text that will be synthesized",
                         "Import file", lambda: import_project(ctx, master))
        self.selected_chapter_id = ""
        self.chapter_by_title: dict[str, str] = {}
        self.dirty = False
        self._loading = False
        self.build()

    def build(self) -> None:
        self.clear()
        colors = self.colors
        toolbar = Toolbar(self.scroll)
        toolbar.grid(row=0, column=0, sticky="ew", padx=6, pady=(2, 10))
        self.chapter_menu = ctk.CTkOptionMenu(toolbar, values=["No chapters"], command=self.on_chapter_selected,
                                              width=250, font=font(12))
        self.chapter_menu.grid(row=0, column=0, padx=(8, 6), pady=8)
        toolbar.add("Paste text", lambda: paste_project(self.ctx, self.winfo_toplevel()), width=95)
        toolbar.add("Clean text", self.clean_text, width=95)
        toolbar.add("Detect chapters", self.detect_chapters, width=120)
        toolbar.add("Reapply rules", self.reapply_rules, width=110)
        toolbar.add("Dictionary", self.add_pronunciation, width=100)
        toolbar.add("Save changes", self.save_changes, primary=True, width=120)
        self.status_label = ctk.CTkLabel(self.scroll, text="", font=font(11), text_color=colors["muted"], anchor="w")
        self.status_label.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 8))

        split = ctk.CTkFrame(self.scroll, fg_color="transparent")
        split.grid(row=2, column=0, sticky="nsew", padx=6, pady=4)
        split.grid_columnconfigure(0, weight=1, uniform="editor")
        split.grid_columnconfigure(1, weight=1, uniform="editor")
        left = Card(split, title="Original manuscript", subtitle="Correct extraction here. This text is never silently rewritten.")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 5), pady=4)
        right = Card(split, title="Narration text — what will be spoken", subtitle="Editable preview after abbreviations, numbers and pronunciation rules.")
        right.grid(row=0, column=1, sticky="nsew", padx=(5, 0), pady=4)
        self.original_box = ctk.CTkTextbox(left, height=430, font=font(12), wrap="word",
                                            fg_color=colors["surface_alt"], text_color=colors["text"],
                                            border_width=0)
        self.original_box.grid(row=left.row, column=0, sticky="nsew", padx=12, pady=(0, 12))
        left.grid_rowconfigure(left.row, weight=1)
        self.narration_box = ctk.CTkTextbox(right, height=430, font=font(12), wrap="word",
                                             fg_color=colors["surface_alt"], text_color=colors["text"],
                                             border_width=0)
        self.narration_box.grid(row=right.row, column=0, sticky="nsew", padx=12, pady=(0, 12))
        right.grid_rowconfigure(right.row, weight=1)
        for box in (self.original_box, self.narration_box):
            box.bind("<KeyRelease>", self.text_changed)

        log_card = Card(self.scroll, title="Text transformation log", subtitle="Every rule applied to create the narration preview is listed here.")
        log_card.grid(row=3, column=0, sticky="ew", padx=6, pady=8)
        self.log_box = ctk.CTkTextbox(log_card, height=110, font=font(11), wrap="word",
                                       fg_color=colors["surface_alt"], text_color=colors["text"], border_width=0)
        self.log_box.grid(row=log_card.row, column=0, sticky="ew", padx=12, pady=(0, 12))
        self.log_box.configure(state="disabled")
        dict_card = Card(self.scroll, title="Pronunciation dictionary", subtitle="Case-insensitive whole-word say-as respellings. Original text is preserved.")
        dict_card.grid(row=4, column=0, sticky="ew", padx=6, pady=8)
        self.dictionary_label = ctk.CTkLabel(dict_card, text="", font=font(12), text_color=colors["text"],
                                              anchor="w", justify="left", wraplength=900)
        self.dictionary_label.grid(row=dict_card.row, column=0, sticky="ew", padx=18, pady=(0, 14))
        self.refresh()

    def _current_chapter(self):
        return self.ctx.storage.get_chapter(self.selected_chapter_id) if self.selected_chapter_id else None

    def on_chapter_selected(self, display: str) -> None:
        chapter_id = self.chapter_by_title.get(display, "")
        if chapter_id and chapter_id != self.selected_chapter_id:
            self.selected_chapter_id = chapter_id
            self.dirty = False
            self.load_chapter()

    def text_changed(self, event=None) -> None:
        if not self._loading:
            self.dirty = True
            self.status_label.configure(text="Unsaved edits — click Save changes to update chunks.")

    def load_chapter(self) -> None:
        self._loading = True
        chapter = self._current_chapter()
        self.original_box.delete("1.0", "end")
        self.narration_box.delete("1.0", "end")
        self.log_box.configure(state="normal")
        self.log_box.delete("1.0", "end")
        if chapter:
            self.original_box.insert("1.0", chapter.original_text)
            self.narration_box.insert("1.0", chapter.narration_text)
            transformations = self.ctx.storage.transformations(chapter.id)
            if transformations:
                lines = [f"{t.get('kind','rule').title()}: “{t.get('original','')}” → “{t.get('replacement','')}” (×{t.get('count',1)})"
                         for t in transformations]
            else:
                lines = ["No automatic transformations. The narration text may have been edited manually."]
            self.log_box.insert("1.0", "\n".join(lines))
        else:
            self.log_box.insert("1.0", "No chapter selected.")
        self.log_box.configure(state="disabled")
        self._loading = False
        self.dirty = False

    def save_changes(self) -> None:
        chapter = self._current_chapter()
        if not chapter:
            return
        self.ctx.storage.update_chapter(
            chapter.id,
            original_text=self.original_box.get("1.0", "end-1c"),
            narration_text=self.narration_box.get("1.0", "end-1c"),
        )
        affected = self.ctx.storage.rebuild_chunks(chapter.project_id)
        self.dirty = False
        self.ctx.refresh()
        InfoDialog(self.winfo_toplevel(), "Manuscript saved",
                   f"Saved. {len(affected)} chunk(s) were marked for regeneration because their text, voice or settings changed. Unchanged completed audio was preserved.")

    def clean_text(self) -> None:
        text = clean_extracted_text(self.original_box.get("1.0", "end-1c"))
        self.original_box.delete("1.0", "end")
        self.original_box.insert("1.0", text)
        self.text_changed()
        InfoDialog(self.winfo_toplevel(), "Cleanup preview",
                   "Soft line breaks were joined and bare page numbers were removed in the original text. Review both panels, then click Save changes.")

    def detect_chapters(self) -> None:
        chapter = self._current_chapter()
        if not chapter:
            return
        count = self.ctx.storage.redetect_chapters(chapter.id)
        self.selected_chapter_id = ""
        self.ctx.refresh()
        InfoDialog(self.winfo_toplevel(), "Chapter detection",
                   f"Detected {count} chapters in this chapter's text and replaced it with {count} chapters." if count else
                   "No additional headings were detected. Try Markdown headings or lines such as 'Chapter 2: The Journey'.")

    def reapply_rules(self) -> None:
        chapter = self._current_chapter()
        if not chapter:
            return
        ConfirmDialog(self.winfo_toplevel(), "Reapply narration rules",
                      "This replaces the narration text with a freshly preprocessed version of the original text. Manual narration edits in this chapter will be lost.",
                      lambda: (self.ctx.storage.prepare_narration(chapter.id, self.ctx.settings.narration),
                               setattr(self, "selected_chapter_id", chapter.id),
                               self.ctx.refresh()))

    def add_pronunciation(self) -> None:
        def on_save(key: str, value: str) -> None:
            if not key or not value:
                return
            self.ctx.settings.narration.pronunciation[key] = value
            save_settings(self.ctx.settings)
            project = self.ctx.active_project()
            if project:
                self.ctx.storage.update_project(project.id, settings=self.ctx.settings.narration)
                self.ctx.storage.rebuild_chunks(project.id)
            self.ctx.refresh()
        KeyValueDialog(self.winfo_toplevel(), "Add pronunciation", "Word or phrase", "Say as (phonetic respelling)", on_save)

    def refresh(self) -> None:
        if not hasattr(self, "chapter_menu"):
            return
        project = self.ctx.active_project()
        chapters = self.ctx.storage.list_chapters(project.id) if project else []
        self.chapter_by_title = {f"{c.idx+1:02d}. {c.title[:55]}": c.id for c in chapters}
        values = list(self.chapter_by_title) or ["No chapters"]
        self.chapter_menu.configure(values=values)
        if self.selected_chapter_id not in [c.id for c in chapters]:
            self.selected_chapter_id = chapters[0].id if chapters else ""
            self.dirty = False
        if self.selected_chapter_id:
            display = next((k for k, v in self.chapter_by_title.items() if v == self.selected_chapter_id), values[0])
            self.chapter_menu.set(display)
            if not self.dirty:
                self.load_chapter()
        else:
            self.chapter_menu.set("No chapters")
            self._loading = True
            self.original_box.delete("1.0", "end")
            self.narration_box.delete("1.0", "end")
            self._loading = False
        dictionary = self.ctx.settings.narration.pronunciation
        self.dictionary_label.configure(text="\n".join(f"• {k}  →  {v}" for k, v in dictionary.items()) or
                                        "No custom respellings yet. Example: 'Kokoro' → 'Koh koh roh'.")
        self.status_label.configure(text=f"Project: {project.name if project else 'none'} · Chapter: {self.chapter_menu.get()} · "
                                         f"{'Unsaved edits' if self.dirty else 'Saved'}")


class ChaptersPage(Page):
    def __init__(self, master, ctx):
        super().__init__(master, ctx, "Chapters", "Reorder, rename, split, merge, assign voices and regenerate chapters",
                         "New chapter", lambda: self.new_chapter())
        self.selected_id = ""
        self.build()

    def build(self) -> None:
        self.clear()
        colors = self.colors
        toolbar = Toolbar(self.scroll)
        toolbar.grid(row=0, column=0, sticky="ew", padx=6, pady=(2, 10))
        for text, command in [
            ("↑ Up", lambda: self.move(-1)), ("↓ Down", lambda: self.move(1)),
            ("Rename", self.rename), ("Split", self.split), ("Merge with next", self.merge),
            ("Regenerate", self.regenerate), ("Delete", self.delete),
        ]:
            toolbar.add(text, command, width=120 if text == "Merge with next" else 88)
        self.list_frame = ctk.CTkFrame(self.scroll, fg_color="transparent")
        self.list_frame.grid(row=1, column=0, sticky="nsew", padx=6, pady=4)
        self.list_frame.grid_columnconfigure(0, weight=1)
        self.refresh()

    def _chapters(self):
        project = self.ctx.active_project()
        return self.ctx.storage.list_chapters(project.id) if project else []

    def _selected(self):
        return self.ctx.storage.get_chapter(self.selected_id) if self.selected_id else None

    def new_chapter(self) -> None:
        project = self.ctx.active_project()
        if not project:
            InfoDialog(self.winfo_toplevel(), "No active project", "Open or create a project first.")
            return
        dialog = ctk.CTkInputDialog(text="Chapter title:", title="New chapter")
        title = dialog.get_input()
        if title and title.strip():
            chapter = self.ctx.storage.create_chapter(project.id, title.strip())
            self.selected_id = chapter.id
            self.ctx.refresh()

    def select(self, chapter_id: str) -> None:
        self.selected_id = chapter_id
        self.refresh()

    def move(self, direction: int) -> None:
        if self.selected_id:
            self.ctx.storage.move_chapter(self.selected_id, direction)
            self.ctx.refresh()

    def rename(self) -> None:
        chapter = self._selected()
        if not chapter:
            return
        dialog = ctk.CTkInputDialog(text="New chapter title:", title="Rename chapter")
        title = dialog.get_input()
        if title and title.strip():
            self.ctx.storage.update_chapter(chapter.id, title=title.strip())
            self.ctx.refresh()

    def split(self) -> None:
        chapter = self._selected()
        if not chapter:
            return
        paragraphs = [p for p in chapter.narration_text.split("\n\n") if p.strip()]
        if len(paragraphs) < 2:
            InfoDialog(self.winfo_toplevel(), "Cannot split", "This chapter needs at least two paragraphs to split.")
            return
        SplitDialog(self.winfo_toplevel(), chapter.title, len(paragraphs),
                    lambda index: (self.ctx.storage.split_chapter(chapter.id, index), self.ctx.refresh()))

    def merge(self) -> None:
        chapter = self._selected()
        if not chapter:
            return
        chapters = self._chapters()
        next_chapter = next((c for c in chapters if c.idx == chapter.idx + 1), None)
        if not next_chapter:
            InfoDialog(self.winfo_toplevel(), "Cannot merge", "Select a chapter that is followed by another chapter.")
            return
        ConfirmDialog(self.winfo_toplevel(), "Merge chapters",
                      f"Merge '{chapter.title}' with '{next_chapter.title}'? The combined text is preserved and affected chunks will be regenerated.",
                      lambda: (self.ctx.storage.merge_chapters(chapter.id, next_chapter.id), self.ctx.refresh()))

    def regenerate(self) -> None:
        chapter = self._selected()
        project = self.ctx.active_project()
        if not chapter or not project:
            return
        self.ctx.storage.regenerate_chapter(chapter.id)
        self.ctx.controller.start(project.id, {chapter.id})
        self.ctx.notify("navigate", {"page": "queue"})

    def delete(self) -> None:
        chapter = self._selected()
        if not chapter:
            return
        ConfirmDialog(self.winfo_toplevel(), "Delete chapter",
                      f"Delete '{chapter.title}' and its chunk metadata? Generated WAV files remain on disk until project cleanup.",
                      lambda: (self.ctx.storage.delete_chapter(chapter.id), setattr(self, "selected_id", ""), self.ctx.refresh()))

    def set_voice(self, chapter_id: str, voice: str) -> None:
        if voice and voice != "Not installed":
            self.ctx.storage.update_chapter(chapter_id, voice=voice)

    def refresh(self) -> None:
        if not hasattr(self, "list_frame"):
            return
        for child in self.list_frame.winfo_children():
            child.destroy()
        chapters = self._chapters()
        if self.selected_id not in [c.id for c in chapters]:
            self.selected_id = chapters[0].id if chapters else ""
        if not chapters:
            EmptyState(self.list_frame, "☰", "No chapters", "Import a manuscript or create a chapter to begin.",
                       "New chapter", self.new_chapter).grid(row=0, column=0, sticky="ew", pady=30)
            return
        installed = self.ctx.resources.installed_voice_ids() or ["Not installed"]
        for i, chapter in enumerate(chapters):
            selected = chapter.id == self.selected_id
            card = Card(self.list_frame)
            card.grid(row=i, column=0, sticky="ew", padx=4, pady=5)
            card.configure(border_color=self.colors["accent"] if selected else self.colors["border"],
                           border_width=2 if selected else 1)
            card.grid_columnconfigure(1, weight=1)
            ctk.CTkButton(card, text="✓" if selected else f"{chapter.idx+1:02d}", width=42,
                          command=lambda cid=chapter.id: self.select(cid),
                          fg_color=self.colors["accent"] if selected else self.colors["surface_alt"],
                          text_color="#FFFFFF" if selected else self.colors["text"]).grid(row=0, column=0, rowspan=2, padx=(14, 10), pady=14)
            ctk.CTkLabel(card, text=chapter.title, font=font(15, "bold"), text_color=self.colors["text"], anchor="w").grid(row=0, column=1, sticky="ew", pady=(12, 2))
            words = len(chapter.narration_text.split())
            paragraphs = len([p for p in chapter.narration_text.split("\n\n") if p.strip()])
            chunks = len(self.ctx.storage.list_chunks(chapter.project_id, chapter.id))
            ctk.CTkLabel(card, text=f"{paragraphs} paragraphs · {words} words · {chunks} audio chunks",
                         font=font(11), text_color=self.colors["muted"], anchor="w").grid(row=1, column=1, sticky="w", pady=(0, 10))
            voice_menu = ctk.CTkOptionMenu(card, values=installed, width=150, font=font(11),
                                           command=lambda v, cid=chapter.id: self.set_voice(cid, v))
            voice_menu.set(chapter.voice if chapter.voice in installed else installed[0])
            voice_menu.grid(row=0, column=2, padx=8, pady=12)
            enabled = ctk.CTkSwitch(card, text="Include", font=font(11))
            enabled.configure(command=lambda cid=chapter.id, switch=enabled: self.ctx.storage.update_chapter(cid, enabled=bool(switch.get())))
            if chapter.enabled:
                enabled.select()
            enabled.grid(row=1, column=2, padx=8, pady=(0, 10))


class VoicesPage(Page):
    def __init__(self, master, ctx):
        super().__init__(master, ctx, "Voice Library",
                         "Installed voices, documented languages/accents, local samples and optional additions",
                         "Offline status", lambda: ctx.notify("navigate", {"page": "status"}))
        self.language_filter = "All languages"
        self.search_text = ""
        self.build()

    def build(self) -> None:
        self.clear()
        colors = self.colors
        controls = Card(self.scroll, title="Voice selection", subtitle="Only selected voice files are downloaded. Samples are generated locally on demand.")
        controls.grid(row=0, column=0, sticky="ew", padx=6, pady=(2, 8))
        controls.grid_columnconfigure(3, weight=1)
        catalog = self.ctx.resources.voice_catalog()
        languages = ["All languages"] + sorted({v.language for v in catalog})
        ctk.CTkLabel(controls, text="Language", font=font(11), text_color=colors["muted"]).grid(row=controls.row, column=0, padx=(18, 6), pady=8)
        self.filter_menu = ctk.CTkOptionMenu(controls, values=languages, width=160,
                                              command=lambda v: (setattr(self, "language_filter", v), self.refresh()))
        self.filter_menu.set(self.language_filter)
        self.filter_menu.grid(row=controls.row, column=1, padx=6, pady=8)
        ctk.CTkLabel(controls, text="Search", font=font(11), text_color=colors["muted"]).grid(row=controls.row, column=2, padx=(16, 6), pady=8)
        search = ctk.CTkEntry(controls, placeholder_text="name or voice ID", font=font(11))
        search.grid(row=controls.row, column=3, sticky="ew", padx=6, pady=8)
        search.bind("<KeyRelease>", lambda e: (setattr(self, "search_text", search.get().strip().lower()), self.refresh()))
        self.default_label = ctk.CTkLabel(controls, text="", font=font(12), text_color=colors["text"], anchor="w")
        self.default_label.grid(row=controls.row + 1, column=0, columnspan=4, sticky="ew", padx=18, pady=(0, 12))
        self.offline_warning = ctk.CTkLabel(controls, text="", font=font(11), text_color=colors["amber"],
                                             anchor="w", wraplength=900)
        self.offline_warning.grid(row=controls.row + 2, column=0, columnspan=4, sticky="ew", padx=18, pady=(0, 12))

        installed_card = Card(self.scroll, title="Installed voices", subtitle="Play a sample, set the default, or use a per-chapter voice.")
        installed_card.grid(row=1, column=0, sticky="ew", padx=6, pady=8)
        self.installed_frame = ctk.CTkFrame(installed_card, fg_color="transparent")
        self.installed_frame.grid(row=installed_card.row, column=0, sticky="ew", padx=14, pady=(0, 14))
        self.installed_frame.grid_columnconfigure(0, weight=1)

        available_card = Card(self.scroll, title="Add voices later", subtitle="Pinned upstream voice list. Downloads require an explicit online action.")
        available_card.grid(row=2, column=0, sticky="ew", padx=6, pady=8)
        self.available_frame = ctk.CTkFrame(available_card, fg_color="transparent")
        self.available_frame.grid(row=available_card.row, column=0, sticky="ew", padx=14, pady=(0, 14))
        self.available_frame.grid_columnconfigure(0, weight=1)
        self.refresh()

    def set_default(self, voice_id: str) -> None:
        self.ctx.settings.narration.default_voice = voice_id
        save_settings(self.ctx.settings)
        project = self.ctx.active_project()
        if project:
            self.ctx.storage.update_project(project.id, settings=self.ctx.settings.narration)
            self.ctx.storage.rebuild_chunks(project.id)
        self.ctx.refresh()
        InfoDialog(self.winfo_toplevel(), "Default voice updated",
                   f"{voice_id} is now the default. Chapters that have their own voice assignment keep that assignment.")

    def play_sample(self, voice_id: str) -> None:
        def done(result, error) -> None:
            if error:
                InfoDialog(self.winfo_toplevel(), "Sample failed", str(error))
            else:
                InfoDialog(self.winfo_toplevel(), "Playing local sample",
                           f"A short sample for {voice_id} was generated locally and is playing (if an output device is available).")
        run_async(self.winfo_toplevel(), "Generating local voice sample…",
                  lambda: generate_voice_sample(self.ctx, voice_id), done)

    def download_voice(self, voice_id: str) -> None:
        def perform() -> None:
            def task():
                return self.ctx.resources.install_voice(voice_id)

            def done(result, error) -> None:
                self.ctx.set_offline(True)
                self.ctx.settings = self.ctx.settings
                if error:
                    InfoDialog(self.winfo_toplevel(), "Voice download failed", str(error))
                else:
                    InfoDialog(self.winfo_toplevel(), "Voice installed",
                               f"{voice_id} was downloaded, checksum-verified and added to the local voice pack. Offline mode is enforced again.")
                self.ctx.refresh()
            run_async(self.winfo_toplevel(), f"Downloading {voice_id}…", task, done)

        if self.ctx.settings.offline_mode:
            ConfirmDialog(self.winfo_toplevel(), "Allow one voice download",
                          f"Offline mode is enforced. Temporarily allow a checksum-verified download of {voice_id} from the pinned Hugging Face commit? Normal generation stays local.",
                          lambda: (self.ctx.set_offline(False), perform()))
        else:
            perform()

    def refresh(self) -> None:
        if not hasattr(self, "installed_frame"):
            return
        for frame in (self.installed_frame, self.available_frame):
            for child in frame.winfo_children():
                child.destroy()
        catalog = self.ctx.resources.voice_catalog()
        installed = [v for v in catalog if v.installed]
        available = [v for v in catalog if not v.installed]
        if self.language_filter != "All languages":
            available = [v for v in available if v.language == self.language_filter]
        if self.search_text:
            available = [v for v in available if self.search_text in v.id.lower() or self.search_text in v.name.lower()]
        self.default_label.configure(text=f"Default voice: {self.ctx.settings.narration.default_voice} · Installed: {len(installed)} / {len(catalog)}")
        self.offline_warning.configure(text=("Offline mode is ON: downloads are blocked until you explicitly allow one." if self.ctx.settings.offline_mode else
                                              "Offline mode is OFF for setup. Re-enable it after installing voices.") +
                                       "  Non-English G2P quality was not part of the measured CPU benchmark.")
        if not installed:
            ctk.CTkLabel(self.installed_frame, text="No voices installed. Run first-time setup.",
                         font=font(12), text_color=self.colors["muted"]).grid(row=0, column=0, sticky="w", pady=8)
        for i, voice in enumerate(installed):
            row = ctk.CTkFrame(self.installed_frame, fg_color=self.colors["surface_alt"], corner_radius=10)
            row.grid(row=i, column=0, sticky="ew", pady=4)
            row.grid_columnconfigure(0, weight=1)
            StatusPill(row, voice.id, "accent" if voice.id == self.ctx.settings.narration.default_voice else "neutral").grid(row=0, column=0, sticky="w", padx=12, pady=(10, 2))
            ctk.CTkLabel(row, text=f"{voice.name} · {voice.gender} · {voice.language} ({voice.accent}) · upstream grade {voice.quality}",
                         font=font(12), text_color=self.colors["text"], anchor="w").grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 10))
            ctk.CTkButton(row, text="Play sample", width=105, command=lambda v=voice.id: self.play_sample(v),
                          corner_radius=8, font=font(11, "bold")).grid(row=0, column=1, rowspan=2, padx=5, pady=8)
            ctk.CTkButton(row, text="Set default", width=100, command=lambda v=voice.id: self.set_default(v),
                          corner_radius=8, fg_color=self.colors["surface"], text_color=self.colors["text"]).grid(row=0, column=2, rowspan=2, padx=(0, 10), pady=8)
        if not available:
            ctk.CTkLabel(self.available_frame, text="No matching uninstalled voices.",
                         font=font(12), text_color=self.colors["muted"]).grid(row=0, column=0, sticky="w", pady=8)
        for i, voice in enumerate(available[:80]):
            row = ctk.CTkFrame(self.available_frame, fg_color=self.colors["surface_alt"], corner_radius=9)
            row.grid(row=i, column=0, sticky="ew", pady=3)
            row.grid_columnconfigure(0, weight=1)
            label = f"{voice.id} · {voice.name} · {voice.gender} · {voice.language} ({voice.accent}) · grade {voice.quality} · {format_bytes(voice.size)}"
            ctk.CTkLabel(row, text=label, font=font(11), text_color=self.colors["text"],
                         anchor="w", wraplength=760, justify="left").grid(row=0, column=0, sticky="ew", padx=12, pady=8)
            ctk.CTkButton(row, text="Download", width=100, command=lambda v=voice.id: self.download_voice(v),
                          corner_radius=8, font=font(11)).grid(row=0, column=1, padx=8, pady=6)
