"""First-run and re-run resource setup wizard."""
from __future__ import annotations

import json
import queue
import threading
from pathlib import Path
from tkinter import StringVar
from typing import Any, Callable

import customtkinter as ctk

from ..config import load_settings
from ..paths import data_root, setup_report_path
from .actions import reveal_path, run_async
from .widgets import Card, InfoDialog, StatusPill, font, format_bytes, palette


class SetupWizard(ctk.CTkToplevel):
    STEPS = ["Welcome", "Storage", "Voices", "Download", "Verify", "Complete"]

    def __init__(self, master, ctx, on_complete: Callable[[], None] | None = None):
        super().__init__(master)
        self.ctx = ctx
        self.on_complete = on_complete
        self.title("Kokoro Audiobook Studio — Setup")
        self.geometry("880x700")
        self.minsize(760, 620)
        self.transient(master)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.close_wizard)
        self.was_offline = bool(ctx.settings.offline_mode)
        self.colors = palette(ctk.get_appearance_mode().lower())
        self.configure(fg_color=self.colors["bg"])
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self.current = 0
        self.model_var = StringVar(value="q8")
        self.selected_voices: set[str] = {"af_heart", "af_bella", "am_michael", "bf_emma"}
        self.voice_vars: dict[str, StringVar] = {}
        self.download_queue: queue.Queue[dict[str, Any]] = queue.Queue()
        self.download_result_queue: queue.Queue[tuple[Any, Exception | None]] = queue.Queue()
        self.pause_event = threading.Event()
        self.pause_event.set()
        self.cancel_event = threading.Event()
        self.download_thread: threading.Thread | None = None
        self.download_status = "idle"
        self.download_attempt = 0
        self.verification_result: Any = None
        self.sample_report: dict[str, Any] = {}
        self.play_attempted = False
        self.playback_confirmed = False
        self.finalized = False
        self._build_chrome()
        self.show_step(0)
        self._poll_queues()

    # ---------- shell ----------

    def _build_chrome(self) -> None:
        header = ctk.CTkFrame(self, fg_color=self.colors["surface"], corner_radius=0, height=84)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(header, text="K", font=font(28, "bold"), text_color="#FFFFFF",
                     fg_color=self.colors["accent"], corner_radius=12, width=48, height=48).grid(row=0, column=0, padx=22, pady=16)
        titles = ctk.CTkFrame(header, fg_color="transparent")
        titles.grid(row=0, column=1, sticky="w", pady=12)
        ctk.CTkLabel(titles, text="Kokoro Audiobook Studio", font=font(19, "bold"), text_color=self.colors["text"]).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(titles, text="One-time local resource setup", font=font(11), text_color=self.colors["muted"]).grid(row=1, column=0, sticky="w")
        self.step_label = ctk.CTkLabel(header, text="", font=font(11, "bold"), text_color=self.colors["muted"])
        self.step_label.grid(row=0, column=2, padx=22)
        self.content = ctk.CTkScrollableFrame(self, fg_color="transparent",
                                               scrollbar_button_color=self.colors["border"])
        self.content.grid(row=1, column=0, sticky="nsew", padx=24, pady=16)
        self.content.grid_columnconfigure(0, weight=1)
        footer = ctk.CTkFrame(self, fg_color=self.colors["surface"], corner_radius=0, height=68)
        footer.grid(row=2, column=0, sticky="ew")
        footer.grid_columnconfigure(0, weight=1)
        self.footer_status = ctk.CTkLabel(footer, text="", font=font(11), text_color=self.colors["muted"], anchor="w")
        self.footer_status.grid(row=0, column=0, sticky="ew", padx=22, pady=12)
        self.back_button = ctk.CTkButton(footer, text="Back", width=90, command=self.back,
                                          fg_color=self.colors["surface_alt"], text_color=self.colors["text"])
        self.back_button.grid(row=0, column=1, padx=6, pady=12)
        self.next_button = ctk.CTkButton(footer, text="Next", width=120, command=self.next, font=font(12, "bold"))
        self.next_button.grid(row=0, column=2, padx=(6, 22), pady=12)

    def _clear_content(self) -> None:
        for child in self.content.winfo_children():
            child.destroy()

    def _set_footer(self, text: str, next_text: str = "Next", next_enabled: bool = True,
                    back_enabled: bool = True) -> None:
        self.footer_status.configure(text=text)
        self.next_button.configure(text=next_text, state="normal" if next_enabled else "disabled")
        self.back_button.configure(state="normal" if back_enabled else "disabled")

    def show_step(self, index: int) -> None:
        self.current = max(0, min(index, len(self.STEPS) - 1))
        self.step_label.configure(text=f"Step {self.current+1} of {len(self.STEPS)} · {self.STEPS[self.current]}")
        self._clear_content()
        self.next_button.configure(command=self.next, state="normal", text="Next")
        self.back_button.configure(state="normal")
        steps = [self.step_welcome, self.step_storage, self.step_voices,
                 self.step_download, self.step_verify, self.step_complete]
        steps[self.current]()

    # ---------- step 1 ----------

    def step_welcome(self) -> None:
        system = self.ctx.resources.system_info()
        card = Card(self.content, title="Welcome to local audiobook production",
                    subtitle="This wizard installs the selected Kokoro model, voice styles and verification files into stable app data.")
        card.grid(row=0, column=0, sticky="ew", pady=(4, 10))
        details = (f"Operating system: {system.os}\nArchitecture: {system.architecture}\n"
                   f"Logical CPUs: {system.cpu_count}\nInstalled RAM: {system.total_memory_mb:.0f} MB "
                   f"({'4 GB target: low-memory mode will be enabled' if system.total_memory_mb < 5200 else 'sufficient for standard mode'})\n"
                   f"Free disk: {system.free_disk_mb/1024:.1f} GB\nRuntime providers: {', '.join(system.providers[:3])}\n"
                   f"Optional DirectML: {'detected' if system.directml_available else 'not installed (CPU is fully supported)'}")
        ctk.CTkLabel(card, text=details, font=font(12), text_color=self.colors["text"],
                     justify="left", anchor="nw", wraplength=760).grid(row=card.row, column=0, sticky="ew", padx=18, pady=(0, 10))
        privacy = Card(self.content, title="Privacy and network use",
                       subtitle="No account, telemetry, ads or hidden cloud services.")
        privacy.grid(row=1, column=0, sticky="ew", pady=8)
        ctk.CTkLabel(privacy, text=("This setup contacts only huggingface.co over HTTPS to download files from the pinned Kokoro ONNX commit. "
                                    "Every model and voice file is checked against an exact SHA-256 digest. After setup, ordinary generation, "
                                    "import, playback and export work with no internet. There is no online TTS fallback."),
                     font=font(11), text_color=self.colors["muted"], wraplength=760, justify="left", anchor="nw").grid(row=privacy.row, column=0, sticky="ew", padx=18, pady=(0, 14))
        self._set_footer("Downloads are explicit, resumable and checksum-verified.", "Get started", True, False)

    # ---------- step 2 ----------

    def step_storage(self) -> None:
        card = Card(self.content, title="Choose the speech model",
                    subtitle="The recommended q8 model was measured on a 2-core, RAM-constrained Linux worker.")
        card.grid(row=0, column=0, sticky="ew", pady=(4, 10))
        options = [
            ("q8", "Balanced Q8 — recommended", "92.4 MB · lowest practical peak RSS (~567–611 MB worker in benchmark) · verified voice quality close to fp32."),
            ("fp32", "Full precision reference", "325.5 MB · higher RAM (~1.0 GB peak worker in benchmark) · only for machines comfortably above 4 GB RAM."),
        ]
        for i, (value, title, note) in enumerate(options):
            frame = ctk.CTkFrame(card, fg_color=self.colors["surface_alt"], corner_radius=10)
            frame.grid(row=card.row + i, column=0, sticky="ew", padx=16, pady=6)
            ctk.CTkRadioButton(frame, text=title, variable=self.model_var, value=value,
                               font=font(13, "bold"), text_color=self.colors["text"],
                               command=self.update_storage_estimate).grid(row=0, column=0, sticky="w", padx=14, pady=(12, 2))
            ctk.CTkLabel(frame, text=note, font=font(11), text_color=self.colors["muted"],
                         wraplength=720, justify="left", anchor="w").grid(row=1, column=0, sticky="ew", padx=34, pady=(0, 12))
        estimate_card = Card(self.content, title="Storage requirements",
                             subtitle="Displayed before any download begins.")
        estimate_card.grid(row=1, column=0, sticky="ew", pady=8)
        self.storage_label = ctk.CTkLabel(estimate_card, text="", font=font(12), text_color=self.colors["text"],
                                           justify="left", anchor="nw", wraplength=760)
        self.storage_label.grid(row=estimate_card.row, column=0, sticky="ew", padx=18, pady=(0, 14))
        self.update_storage_estimate()
        self._set_footer("The model and selected voices are stored separately from the executable, so upgrades do not remove them.", "Choose voices", True, True)

    def update_storage_estimate(self) -> None:
        if not hasattr(self, "storage_label"):
            return
        estimate = self.ctx.resources.estimate_download(self.model_var.get(), sorted(self.selected_voices))
        system = self.ctx.resources.system_info()
        status = "OK" if system.free_disk_mb * 1048576 >= estimate["recommended_free"] else "LOW DISK SPACE"
        self.storage_label.configure(text=(
            f"Selected model: {format_bytes(estimate['model'])}\n"
            f"Selected voices ({len(self.selected_voices)}): {format_bytes(estimate['voices'])}\n"
            f"Download total: {format_bytes(estimate['download'])}\n"
            f"Recommended free space (including WAV chunks and a safety margin): {format_bytes(estimate['recommended_free'])}\n"
            f"Free space available: {format_bytes(system.free_disk_mb * 1048576)} — {status}\n"
            f"Destination: {data_root() / 'Resources'}"))

    # ---------- step 3 ----------

    def step_voices(self) -> None:
        card = Card(self.content, title="Select initial voices",
                    subtitle="A small English set is preselected. You can add any of the 54 upstream voices later.")
        card.grid(row=0, column=0, sticky="ew", pady=(4, 10))
        catalog = self.ctx.resources.voice_catalog()
        self.voice_vars = {}
        for i, voice in enumerate(catalog):
            var = StringVar(value="on" if voice.id in self.selected_voices else "off")
            self.voice_vars[voice.id] = var
            row = ctk.CTkFrame(card, fg_color=self.colors["surface_alt"], corner_radius=8)
            row.grid(row=card.row + i, column=0, sticky="ew", padx=14, pady=3)
            row.grid_columnconfigure(0, weight=1)
            checkbox = ctk.CTkCheckBox(row, text=f"{voice.id}  ·  {voice.name}  ·  {voice.gender}, {voice.language} ({voice.accent})  ·  grade {voice.quality}",
                                       variable=var, onvalue="on", offvalue="off", font=font(11),
                                       text_color=self.colors["text"], command=lambda vid=voice.id, v=var: self.toggle_voice(vid, v.get()))
            checkbox.grid(row=0, column=0, sticky="w", padx=10, pady=6)
            ctk.CTkLabel(row, text=format_bytes(voice.size), font=font(10), text_color=self.colors["muted"]).grid(row=0, column=1, padx=10)
        size_card = Card(self.content, title="Current selection")
        size_card.grid(row=1, column=0, sticky="ew", pady=8)
        self.voice_size_label = ctk.CTkLabel(size_card, text="", font=font(12), text_color=self.colors["text"], anchor="w")
        self.voice_size_label.grid(row=size_card.row, column=0, sticky="ew", padx=18, pady=(0, 12))
        self.update_voice_estimate()
        self._set_footer("Only checked voice files will be downloaded. First-time setup can be repeated to add voices.", "Download", True, True)

    def toggle_voice(self, voice_id: str, value: str) -> None:
        if value == "on":
            self.selected_voices.add(voice_id)
        else:
            self.selected_voices.discard(voice_id)
        self.update_voice_estimate()

    def update_voice_estimate(self) -> None:
        if not hasattr(self, "voice_size_label"):
            return
        estimate = self.ctx.resources.estimate_download(self.model_var.get(), sorted(self.selected_voices))
        self.voice_size_label.configure(text=f"{len(self.selected_voices)} voice(s) selected · {format_bytes(estimate['voices'])} · Total download {format_bytes(estimate['download'])}")

    # ---------- step 4 ----------

    def step_download(self) -> None:
        card = Card(self.content, title="Download local resources",
                    subtitle="Pinned HTTPS sources · SHA-256 verification · pause/resume · automatic retries")
        card.grid(row=0, column=0, sticky="ew", pady=(4, 10))
        self.download_status_label = StatusPill(card, "Starting…", "warn")
        self.download_status_label.grid(row=card.row, column=0, sticky="w", padx=18, pady=(2, 8))
        card.row += 1
        self.download_progress = ctk.CTkProgressBar(card, height=14)
        self.download_progress.grid(row=card.row, column=0, sticky="ew", padx=18, pady=(2, 6))
        self.download_progress.set(0)
        card.row += 1
        self.download_progress_label = ctk.CTkLabel(card, text="0 B / 0 B", font=font(12), text_color=self.colors["muted"], anchor="w")
        self.download_progress_label.grid(row=card.row, column=0, sticky="ew", padx=18, pady=(0, 8))
        card.row += 1
        self.file_label = ctk.CTkLabel(card, text="Preparing download…", font=font(12), text_color=self.colors["text"], anchor="w")
        self.file_label.grid(row=card.row, column=0, sticky="ew", padx=18, pady=(0, 8))
        card.row += 1
        controls = ctk.CTkFrame(card, fg_color="transparent")
        controls.grid(row=card.row, column=0, sticky="w", padx=14, pady=(0, 12))
        self.pause_button = ctk.CTkButton(controls, text="Pause", width=100, command=self.toggle_pause,
                                           fg_color=self.colors["surface_alt"], text_color=self.colors["text"])
        self.pause_button.grid(row=0, column=0, padx=4)
        ctk.CTkButton(controls, text="Retry", width=100, command=self.retry_download,
                      fg_color=self.colors["surface_alt"], text_color=self.colors["text"]).grid(row=0, column=1, padx=4)
        ctk.CTkButton(controls, text="Cancel", width=100, command=self.cancel_download,
                      fg_color=self.colors["red_bg"], text_color=self.colors["red"]).grid(row=0, column=2, padx=4)
        log_card = Card(self.content, title="Download log", subtitle="Partial files are kept for resume; corrupt files are quarantined.")
        log_card.grid(row=1, column=0, sticky="ew", pady=8)
        self.download_log = ctk.CTkTextbox(log_card, height=150, font=font(11),
                                            fg_color=self.colors["surface_alt"], text_color=self.colors["text"], border_width=0)
        self.download_log.grid(row=log_card.row, column=0, sticky="ew", padx=14, pady=(0, 12))
        self.download_log.configure(state="disabled")
        self._set_footer("Offline mode is temporarily disabled only for these explicit downloads.", "Verify", False, False)
        self.start_download()

    def log_line(self, text: str) -> None:
        self.download_log.configure(state="normal")
        self.download_log.insert("end", text.rstrip() + "\n")
        self.download_log.see("end")
        self.download_log.configure(state="disabled")

    def start_download(self) -> None:
        if self.download_thread and self.download_thread.is_alive():
            return
        if not self.selected_voices:
            InfoDialog(self, "Select a voice", "Choose at least one voice before downloading.")
            return
        self.download_attempt += 1
        self.download_status = "running"
        self.cancel_event.clear()
        self.pause_event.set()
        self.ctx.set_offline(False)
        self.was_offline = True
        self.download_status_label.set_state("warn", f"Downloading (attempt {self.download_attempt})")
        self.pause_button.configure(text="Pause")
        self.log_line(f"Starting download attempt {self.download_attempt} for model {self.model_var.get()} and {len(self.selected_voices)} voices.")

        def progress(info: dict[str, Any]) -> None:
            self.download_queue.put({"kind": "progress", "data": info})

        def task() -> Any:
            return self.ctx.resources.download_selected(
                self.model_var.get(), sorted(self.selected_voices), progress=progress,
                pause_event=self.pause_event, cancel_event=self.cancel_event)

        def worker() -> None:
            try:
                self.download_result_queue.put((task(), None))
            except Exception as exc:
                self.download_result_queue.put((None, exc))

        self.download_thread = threading.Thread(target=worker, daemon=True, name="kas-setup-download")
        self.download_thread.start()

    def toggle_pause(self) -> None:
        if self.pause_event.is_set():
            self.pause_event.clear()
            self.download_status_label.set_state("warn", "Paused")
            self.pause_button.configure(text="Resume")
            self.log_line("Paused by user. Partial file is retained for resume.")
        else:
            self.pause_event.set()
            self.download_status_label.set_state("warn", "Resuming…")
            self.pause_button.configure(text="Pause")
            self.log_line("Resuming download.")
            if not (self.download_thread and self.download_thread.is_alive()):
                self.start_download()

    def retry_download(self) -> None:
        self.cancel_event.set()
        if self.download_thread and self.download_thread.is_alive():
            self.download_thread.join(timeout=2)
        self.pause_event.set()
        self.start_download()

    def cancel_download(self) -> None:
        self.cancel_event.set()
        self.pause_event.set()
        self.download_status_label.set_state("error", "Cancelled")
        self.log_line("Cancelled by user. Re-run setup to resume from partial files.")
        self._set_footer("Download cancelled. Offline mode will be re-enabled when you leave setup.", "Retry", False, True)
        self.next_button.configure(command=self.retry_download, state="normal", text="Retry")

    # ---------- step 5 ----------

    def step_verify(self) -> None:
        self.ctx.set_offline(True)
        card = Card(self.content, title="Verify resources and initialize speech engine",
                    subtitle="This step loads the real ONNX model in an isolated worker and generates a local speech sample.")
        card.grid(row=0, column=0, sticky="ew", pady=(4, 10))
        self.verify_status = StatusPill(card, "Working…", "warn")
        self.verify_status.grid(row=card.row, column=0, sticky="w", padx=18, pady=(2, 8))
        card.row += 1
        self.verify_label = ctk.CTkLabel(card, text="Verifying checksums and generating sample…", font=font(12),
                                          text_color=self.colors["text"], anchor="nw", justify="left", wraplength=760)
        self.verify_label.grid(row=card.row, column=0, sticky="ew", padx=18, pady=(0, 10))
        card.row += 1
        self.verify_log = ctk.CTkTextbox(card, height=200, font=font(11), fg_color=self.colors["surface_alt"],
                                          text_color=self.colors["text"], border_width=0)
        self.verify_log.grid(row=card.row, column=0, sticky="ew", padx=14, pady=(0, 12))
        self.verify_log.configure(state="disabled")
        playback = Card(self.content, title="Playback confirmation",
                        subtitle="The app reports Offline Ready only after a real sample is generated and you confirm playback.")
        playback.grid(row=1, column=0, sticky="ew", pady=8)
        controls = ctk.CTkFrame(playback, fg_color="transparent")
        controls.grid(row=playback.row, column=0, sticky="w", padx=14, pady=(0, 12))
        self.play_button = ctk.CTkButton(controls, text="Play sample", width=120, command=self.play_sample, state="disabled")
        self.play_button.grid(row=0, column=0, padx=4)
        ctk.CTkButton(controls, text="Open sample file", width=130, command=self.open_sample,
                      fg_color=self.colors["surface_alt"], text_color=self.colors["text"]).grid(row=0, column=1, padx=4)
        self.confirm_button = ctk.CTkButton(controls, text="I heard the sample", width=150, command=self.confirm_playback, state="disabled")
        self.confirm_button.grid(row=0, column=2, padx=4)
        self._set_footer("Outbound network connections are blocked during this test.", "Finish", False, False)
        self.start_verification()

    def start_verification(self) -> None:
        def task() -> dict[str, Any]:
            verification = self.ctx.resources.verify_resources(self.model_var.get())
            report = self.ctx.resources.offline_readiness_test(
                model_id=self.model_var.get(), voice=sorted(self.selected_voices)[0],
                play=False, mark_ready=False)
            return {"verification": verification, "report": report}

        def done(result: Any, error: Exception | None) -> None:
            if error:
                self.verify_status.set_state("error", "Verification failed")
                self.verify_label.configure(text=str(error))
                self._append_verify(f"ERROR: {error}")
                self._set_footer("Setup cannot continue until resources verify. Retry or go back.", "Retry", True, True)
                self.next_button.configure(command=self.start_verification, text="Retry")
                return
            self.verification_result = result["verification"]
            self.sample_report = result["report"]
            lines = []
            for check in self.verification_result.checks:
                lines.append(f"{'PASS' if check.ok else 'FAIL'}  {check.name}: {check.detail}")
            lines.append("")
            for check in self.sample_report.get("checks", []):
                lines.append(f"{'PASS' if check.get('ok') else 'FAIL'}  {check.get('name')}: {check.get('detail','')}")
            self._append_verify("\n".join(lines))
            if self.verification_result.ok and self.sample_report.get("ok"):
                self.verify_status.set_state("good", "Sample generated & verified")
                sample = self.sample_report.get("sample", "")
                self.verify_label.configure(text=f"Real speech sample generated locally: {sample}\n\n"
                                                 "Click Play sample (or open it in another local player), then confirm that you heard it.")
                self.play_button.configure(state="normal")
                self.confirm_button.configure(state="normal")
                self._set_footer("Playback confirmation is required before Offline Ready is reported.", "Finish", False, False)
            else:
                self.verify_status.set_state("error", "Verification failed")
                self.verify_label.configure(text="The resources or sample did not pass verification. Review the log and retry.")
                self._set_footer("Setup cannot continue until the local sample passes.", "Retry", True, True)
                self.next_button.configure(command=self.start_verification, text="Retry", state="normal")
        run_async(self, "Verifying local resources…", task, done)

    def _append_verify(self, text: str) -> None:
        self.verify_log.configure(state="normal")
        self.verify_log.delete("1.0", "end")
        self.verify_log.insert("1.0", text)
        self.verify_log.configure(state="disabled")

    def play_sample(self) -> None:
        path = self.sample_report.get("sample")
        if not path:
            return
        if not self.ctx.player:
            InfoDialog(self, "Playback unavailable", self.ctx.player_error or "No local audio output device was detected. You can open the WAV in another player.")
            return
        try:
            self.ctx.player.play(path)
            self.play_attempted = True
            self.sample_report["played"] = True
            InfoDialog(self, "Playing sample", "The locally generated WAV sample is playing. If you can hear it, click 'I heard the sample'.")
        except Exception as exc:
            InfoDialog(self, "Playback failed", str(exc))

    def open_sample(self) -> None:
        path = self.sample_report.get("sample")
        if path:
            reveal_path(self, path)
            self.play_attempted = True

    def confirm_playback(self) -> None:
        if not self.play_attempted:
            InfoDialog(self, "Play the sample first", "Click Play sample or Open sample file, then confirm that you heard it.")
            return
        self.sample_report.setdefault("checks", []).append(
            {"name": "user playback confirmation", "ok": True, "detail": "User confirmed the locally generated sample was audible."})
        self.sample_report["playback_confirmed_by_user"] = True
        self.playback_confirmed = True
        self.show_step(5)

    # ---------- step 6 ----------

    def step_complete(self) -> None:
        if not self.finalized:
            self.ctx.resources.mark_offline_ready(self.sample_report, self.model_var.get(), sorted(self.selected_voices)[0])
            self.ctx.settings = load_settings(force=True)
            self.ctx.set_offline(True)
            self.finalized = True
            self.ctx.notify("setup_complete", {"model": self.model_var.get()})
            if self.on_complete:
                self.on_complete()
        card = Card(self.content, title="Offline Ready", subtitle="A real local speech sample passed checksum, generation, decode and playback confirmation.")
        card.grid(row=0, column=0, sticky="ew", pady=(4, 10))
        StatusPill(card, "OFFLINE READY", "good").grid(row=card.row, column=0, sticky="w", padx=18, pady=(2, 8))
        model = self.ctx.resources.model(self.model_var.get())
        report_path = setup_report_path()
        summary = (f"Model: {model['label']} · {format_bytes(model['size'])}\n"
                   f"Model SHA-256: {model['sha256']}\n"
                   f"Pinned revision: {self.ctx.resources.revision}\n"
                   f"Installed voices: {', '.join(sorted(self.selected_voices))}\n"
                   f"Sample: {self.sample_report.get('sample','')}\n"
                   f"Setup report: {report_path}\n"
                   f"Stable data root: {data_root()}\n\n"
                   f"Network activity: explicit setup downloads only. Offline mode is now enforced; no cloud TTS, telemetry or hidden update calls.")
        ctk.CTkLabel(card, text=summary, font=font(12), text_color=self.colors["text"],
                     justify="left", anchor="nw", wraplength=760).grid(row=card.row + 1, column=0, sticky="ew", padx=18, pady=(0, 14))
        license_card = Card(self.content, title="Licenses preserved", subtitle="Apache-2.0 model/voices; dependency notices are included with the installation.")
        license_card.grid(row=1, column=0, sticky="ew", pady=8)
        ctk.CTkLabel(license_card, text=("Kokoro v1.0 model and voice styles: Apache-2.0. kokoro-onnx: MIT. phonemizer/eSpeak NG: GPL-3.0-or-later. "
                                          "lameenc/LAME: LGPL-3.0-or-later. The complete inventory is in NOTICE.md and third_party_licenses/."),
                     font=font(11), text_color=self.colors["muted"], wraplength=760, justify="left", anchor="nw").grid(row=license_card.row, column=0, sticky="ew", padx=18, pady=(0, 14))
        self._set_footer("Projects and audio live outside the install folder and are preserved across upgrades/uninstall.", "Open Studio", True, False)
        self.next_button.configure(command=self.close_wizard)

    # ---------- navigation / events ----------

    def next(self) -> None:
        if self.current == 1:
            estimate = self.ctx.resources.estimate_download(self.model_var.get(), sorted(self.selected_voices))
            free = self.ctx.resources.system_info().free_disk_mb * 1048576
            if free < estimate["recommended_free"]:
                InfoDialog(self, "Low disk space", "Free more disk space or choose fewer voices before continuing.")
                return
        if self.current == 2 and not self.selected_voices:
            InfoDialog(self, "Select a voice", "Choose at least one voice.")
            return
        if self.current < 3:
            self.show_step(self.current + 1)
        elif self.current == 3 and self.download_status == "complete":
            self.show_step(4)
        elif self.current == 4 and self.playback_confirmed:
            self.show_step(5)
        else:
            InfoDialog(self, "Step incomplete", "Finish the current step before continuing.")

    def back(self) -> None:
        if self.current > 0:
            self.next_button.configure(command=self.next)
            self.show_step(self.current - 1)

    def _poll_queues(self) -> None:
        try:
            if not self.winfo_exists():
                return
            while True:
                message = self.download_queue.get_nowait()
                if message.get("kind") == "progress":
                    self._update_download_progress(message["data"])
        except queue.Empty:
            pass
        except Exception:
            return
        try:
            while True:
                result, error = self.download_result_queue.get_nowait()
                self._download_finished(result, error)
        except queue.Empty:
            pass
        try:
            self.after(120, self._poll_queues)
        except Exception:
            pass

    def _update_download_progress(self, info: dict[str, Any]) -> None:
        done = int(info.get("overall_done", info.get("bytes_done", 0)))
        total = int(info.get("overall_total", info.get("bytes_total", 1)))
        self.download_progress.set(min(1.0, done / total) if total else 0)
        self.download_progress_label.configure(text=f"{format_bytes(done)} / {format_bytes(total)}")
        self.file_label.configure(text=f"{info.get('name','')}: {info.get('status','')}")

    def _download_finished(self, result: Any, error: Exception | None) -> None:
        if error:
            self.download_status = "error"
            self.download_status_label.set_state("error", "Download failed")
            self.log_line(f"ERROR: {error}")
            self._set_footer("Check the network connection and click Retry. Partial files will resume.", "Retry", False, True)
            self.next_button.configure(command=self.retry_download, text="Retry", state="normal")
            return
        status = result.get("status") if isinstance(result, dict) else "unknown"
        self.download_status = status
        for item in result.get("files", []):
            self.log_line(f"{item.get('result','')}: {item.get('name','')}")
        if status == "downloaded":
            self.ctx.set_offline(True)
            self.download_status_label.set_state("good", "Downloaded & checksum-verified")
            self.log_line(f"Voice pack built: {result.get('voice_pack','')}")
            self._set_footer("All selected files passed SHA-256 verification. Voice pack is ready.", "Verify", True, True)
            self.next_button.configure(command=self.next, state="normal")
        elif status == "paused":
            self.download_status_label.set_state("warn", "Paused")
            self.log_line("Paused. Click Resume to continue from the .part file.")
            self._set_footer("Paused. Partial download is retained.", "Resume", False, True)
            self.next_button.configure(command=self.toggle_pause, text="Resume", state="normal")
        elif status == "cancelled":
            self.download_status_label.set_state("error", "Cancelled")
            self._set_footer("Cancelled. Re-run setup to resume.", "Retry", False, True)
            self.next_button.configure(command=self.retry_download, text="Retry", state="normal")
        else:
            self.download_status_label.set_state("error", f"Status: {status}")
            self._set_footer("Setup cannot continue. Review the log and retry.", "Retry", False, True)
            self.next_button.configure(command=self.retry_download, text="Retry", state="normal")

    def close_wizard(self) -> None:
        self.cancel_event.set()
        self.pause_event.set()
        if self.was_offline:
            self.ctx.set_offline(True)
        self.ctx.refresh()
        self.destroy()
