"""Reusable, dependency-light CustomTkinter components."""
from __future__ import annotations

import math
from typing import Callable

import customtkinter as ctk

LIGHT = {
    "bg": "#F4F7FB", "surface": "#FFFFFF", "surface_alt": "#F8FAFC",
    "border": "#DCE4EE", "text": "#0F172A", "muted": "#64748B",
    "accent": "#2563EB", "accent_hover": "#1D4ED8", "teal": "#0D9488",
    "green": "#15803D", "green_bg": "#DCFCE7", "amber": "#B45309",
    "amber_bg": "#FEF3C7", "red": "#B91C1C", "red_bg": "#FEE2E2",
    "sidebar": "#FFFFFF", "shadow": "#E8EEF6",
}
DARK = {
    "bg": "#0B1220", "surface": "#111827", "surface_alt": "#1F2937",
    "border": "#334155", "text": "#F8FAFC", "muted": "#94A3B8",
    "accent": "#3B82F6", "accent_hover": "#2563EB", "teal": "#2DD4BF",
    "green": "#4ADE80", "green_bg": "#14532D", "amber": "#FBBF24",
    "amber_bg": "#78350F", "red": "#F87171", "red_bg": "#7F1D1D",
    "sidebar": "#0F172A", "shadow": "#111827",
}


def palette(theme: str = "light") -> dict[str, str]:
    return LIGHT if theme != "dark" else DARK


def font(size: int = 14, weight: str = "normal", family: str = "Segoe UI") -> ctk.CTkFont:
    return ctk.CTkFont(family=family, size=size, weight=weight)


def format_bytes(value: float) -> str:
    if value < 1024:
        return f"{int(value)} B"
    units = ["KB", "MB", "GB", "TB"]
    size = float(value)
    for unit in units:
        size /= 1024
        if size < 1024:
            return f"{size:.1f} {unit}"
    return f"{size:.1f} PB"


def format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds or 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:d}:{m:02d}:{s:02d}" if h else f"{m:d}:{s:02d}"


def format_clock(seconds: float) -> str:
    seconds = max(0, int(seconds or 0))
    return f"{seconds//60:d}:{seconds%60:02d}"


class Card(ctk.CTkFrame):
    def __init__(self, master, *, title: str = "", subtitle: str = "", **kwargs):
        colors = palette(ctk.get_appearance_mode().lower())
        super().__init__(master, corner_radius=14, fg_color=colors["surface"],
                         border_width=1, border_color=colors["border"], **kwargs)
        self.colors = colors
        self.grid_columnconfigure(0, weight=1)
        self.row = 0
        if title:
            label = ctk.CTkLabel(self, text=title, font=font(16, "bold"),
                                 text_color=colors["text"], anchor="w")
            label.grid(row=self.row, column=0, sticky="ew", padx=18, pady=(16, 2))
            self.row += 1
        if subtitle:
            label = ctk.CTkLabel(self, text=subtitle, font=font(12),
                                 text_color=colors["muted"], anchor="w", wraplength=620)
            label.grid(row=self.row, column=0, sticky="ew", padx=18, pady=(0, 10))
            self.row += 1

    def body(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.grid(row=self.row, column=0, sticky="nsew", padx=18, pady=(4, 16))
        frame.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(self.row, weight=1)
        self.row += 1
        return frame


class StatCard(Card):
    def __init__(self, master, label: str, value: str, caption: str = "", icon: str = "◆"):
        super().__init__(master)
        self.grid_columnconfigure(1, weight=1)
        colors = self.colors
        icon_label = ctk.CTkLabel(self, text=icon, font=font(22), text_color=colors["accent"])
        icon_label.grid(row=0, column=0, rowspan=2, padx=(18, 12), pady=16, sticky="n")
        title = ctk.CTkLabel(self, text=label.upper(), font=font(10, "bold"), text_color=colors["muted"], anchor="w")
        title.grid(row=0, column=1, sticky="ew", padx=(0, 18), pady=(16, 2))
        self.value_label = ctk.CTkLabel(self, text=value, font=font(25, "bold"), text_color=colors["text"], anchor="w")
        self.value_label.grid(row=1, column=1, sticky="ew", padx=(0, 18), pady=(0, 2))
        self.caption_label = ctk.CTkLabel(self, text=caption, font=font(11), text_color=colors["muted"], anchor="w")
        self.caption_label.grid(row=2, column=1, sticky="ew", padx=(0, 18), pady=(0, 14))

    def set_value(self, value: str, caption: str = "") -> None:
        self.value_label.configure(text=value)
        if caption:
            self.caption_label.configure(text=caption)


class StatusPill(ctk.CTkLabel):
    def __init__(self, master, text: str = "Ready", state: str = "neutral"):
        super().__init__(master, text=f"  ●  {text}  ", font=font(11, "bold"), corner_radius=999)
        self.set_state(state, text)

    def set_state(self, state: str, text: str | None = None) -> None:
        colors = palette(ctk.get_appearance_mode().lower())
        mapping = {
            "good": (colors["green_bg"], colors["green"]),
            "warn": (colors["amber_bg"], colors["amber"]),
            "error": (colors["red_bg"], colors["red"]),
            "accent": (colors["accent"], "#FFFFFF"),
            "neutral": (colors["surface_alt"], colors["muted"]),
        }
        bg, fg = mapping.get(state, mapping["neutral"])
        self.configure(fg_color=bg, text_color=fg, text=f"  ●  {text or self.cget('text').strip(' ●')}  ")


class EmptyState(ctk.CTkFrame):
    def __init__(self, master, icon: str, title: str, message: str,
                 action_text: str = "", action: Callable[[], None] | None = None):
        colors = palette(ctk.get_appearance_mode().lower())
        super().__init__(master, fg_color=colors["surface"], corner_radius=14,
                         border_width=1, border_color=colors["border"])
        self.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(self, text=icon, font=font(34), text_color=colors["accent"]).grid(row=0, column=0, pady=(28, 8))
        ctk.CTkLabel(self, text=title, font=font(17, "bold"), text_color=colors["text"]).grid(row=1, column=0, pady=(0, 6))
        ctk.CTkLabel(self, text=message, font=font(12), text_color=colors["muted"],
                     wraplength=500, justify="center").grid(row=2, column=0, padx=30, pady=(0, 14))
        if action_text and action:
            ctk.CTkButton(self, text=action_text, command=action, corner_radius=9,
                          font=font(12, "bold")).grid(row=3, column=0, pady=(0, 28))


class SectionHeader(ctk.CTkFrame):
    def __init__(self, master, title: str, subtitle: str = "", action_text: str = "",
                 action: Callable[[], None] | None = None):
        colors = palette(ctk.get_appearance_mode().lower())
        super().__init__(master, fg_color="transparent")
        self.grid_columnconfigure(0, weight=1)
        left = ctk.CTkFrame(self, fg_color="transparent")
        left.grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(left, text=title, font=font(25, "bold"), text_color=colors["text"]).grid(row=0, column=0, sticky="w")
        if subtitle:
            ctk.CTkLabel(left, text=subtitle, font=font(12), text_color=colors["muted"], anchor="w").grid(row=1, column=0, sticky="w", pady=(2, 0))
        if action_text and action:
            ctk.CTkButton(self, text=action_text, command=action, corner_radius=9,
                          font=font(12, "bold")).grid(row=0, column=1, rowspan=2, sticky="e", padx=(12, 0))


class Toolbar(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        colors = palette(ctk.get_appearance_mode().lower())
        super().__init__(master, fg_color=colors["surface"], corner_radius=10,
                         border_width=1, border_color=colors["border"], **kwargs)
        self.grid_columnconfigure(99, weight=1)

    def add(self, text: str, command: Callable[[], None], *, primary: bool = False, width: int = 110):
        colors = self.master.palette if hasattr(self.master, "palette") else palette(ctk.get_appearance_mode().lower())
        button = ctk.CTkButton(self, text=text, command=command, width=width, corner_radius=8,
                               font=font(12, "bold"),
                               fg_color=colors["accent"] if primary else colors["surface_alt"],
                               hover_color=colors["accent_hover"] if primary else colors["border"],
                               text_color="#FFFFFF" if primary else colors["text"])
        column = len([w for w in self.winfo_children() if isinstance(w, ctk.CTkButton)])
        button.grid(row=0, column=column, padx=(8 if column else 10, 6), pady=8)
        return button


class InfoDialog(ctk.CTkToplevel):
    def __init__(self, master, title: str, message: str, *, kind: str = "info"):
        super().__init__(master)
        self.title(title)
        self.geometry("480x260")
        self.resizable(False, False)
        self.transient(master)
        self.grab_set()
        colors = palette(ctk.get_appearance_mode().lower())
        self.configure(fg_color=colors["bg"])
        frame = Card(self, title=title)
        frame.pack(fill="both", expand=True, padx=18, pady=18)
        label = ctk.CTkLabel(frame, text=message, font=font(13), text_color=colors["text"],
                             wraplength=400, justify="left", anchor="nw")
        label.grid(row=frame.row, column=0, sticky="nsew", padx=18, pady=(6, 12))
        ctk.CTkButton(frame, text="Close", command=self.destroy, corner_radius=9,
                      font=font(12, "bold")).grid(row=frame.row + 1, column=0, sticky="e", padx=18, pady=(0, 16))


class ConfirmDialog(ctk.CTkToplevel):
    def __init__(self, master, title: str, message: str, on_confirm: Callable[[], None]):
        super().__init__(master)
        self.title(title)
        self.geometry("470x230")
        self.resizable(False, False)
        self.transient(master)
        self.grab_set()
        colors = palette(ctk.get_appearance_mode().lower())
        self.configure(fg_color=colors["bg"])
        frame = Card(self, title=title)
        frame.pack(fill="both", expand=True, padx=18, pady=18)
        ctk.CTkLabel(frame, text=message, font=font(13), text_color=colors["text"],
                     wraplength=400, justify="left", anchor="nw").grid(row=frame.row, column=0, sticky="nsew", padx=18, pady=(4, 12))
        buttons = ctk.CTkFrame(frame, fg_color="transparent")
        buttons.grid(row=frame.row + 1, column=0, sticky="e", padx=18, pady=(0, 16))
        ctk.CTkButton(buttons, text="Cancel", command=self.destroy, width=90, corner_radius=9,
                      fg_color=colors["surface_alt"], text_color=colors["text"]).grid(row=0, column=0, padx=6)
        ctk.CTkButton(buttons, text="Confirm", width=90, corner_radius=9, font=font(12, "bold"),
                      command=lambda: (on_confirm(), self.destroy())).grid(row=0, column=1, padx=6)
