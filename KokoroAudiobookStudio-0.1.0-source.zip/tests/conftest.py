from __future__ import annotations

import http.server
import os
import sys
import threading
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


@pytest.fixture(autouse=True)
def isolated_data(tmp_path, monkeypatch):
    """Every ordinary test gets its own stable app-data root.

    Real-resource tests can opt into a pre-populated root by setting both
    KAS_E2E=1 and KAS_DATA_DIR in the environment.
    """
    if os.environ.get("KAS_E2E") == "1" and os.environ.get("KAS_DATA_DIR"):
        data = Path(os.environ["KAS_DATA_DIR"])
        data.mkdir(parents=True, exist_ok=True)
    else:
        data = tmp_path / "appdata"
        data.mkdir()
        monkeypatch.setenv("KAS_DATA_DIR", str(data))
    monkeypatch.setenv("KAS_SKIP_SETUP", "1")
    import kokoro_studio.config as config
    import kokoro_studio.network_guard as network_guard
    config._settings = None
    network_guard.set_offline(False)
    yield data
    network_guard.set_offline(False)
    config._settings = None


class RangeHandler(http.server.BaseHTTPRequestHandler):
    data = b""

    def log_message(self, *args):
        pass

    def do_GET(self):
        total = len(self.data)
        header = self.headers.get("Range")
        start = 0
        if header and header.startswith("bytes="):
            try:
                start = int(header.split("=", 1)[1].split("-", 1)[0])
            except ValueError:
                start = 0
        body = self.data[start:]
        self.send_response(206 if header else 200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(len(body)))
        if header:
            self.send_header("Content-Range", f"bytes {start}-{total-1}/{total}")
        self.end_headers()
        self.wfile.write(body)


@pytest.fixture
def range_server():
    data = os.urandom(3 * 1024 * 1024)
    RangeHandler.data = data
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), RangeHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_port}/file.bin", data
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)


@pytest.fixture
def sample_text() -> str:
    return """Chapter 1: The Lantern

On 12 February 2026, Maya found a small brass key beneath the old station clock. “Do you hear that?” she whispered. The train arrived at 7:45 p.m., twelve minutes late.

Dr. Okafor paid $12.50 for a 2 kg parcel. It travelled 5 km through the rain.

CHAPTER 2: THE PLATFORM

The notice said 10% of Platform 3 was closed. Mr. Adeyemi waited for 3 minutes.

The lantern flickered once, then went out.
"""
