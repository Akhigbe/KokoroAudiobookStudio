from __future__ import annotations

import threading

import numpy as np
import pytest

from kokoro_studio.audio import (
    ChunkSpec, WavChunkWriter, assemble_mp3, assemble_wav, probe_audio, read_wav, validate_chunk_specs,
)


def write_chunk(path, value: float, frames: int = 12000):
    with WavChunkWriter(path) as writer:
        writer.write(np.full(frames, value, dtype=np.float32))
    return path


def non_silent_segments(samples: np.ndarray, threshold: float = 0.03):
    loud = np.abs(samples) > threshold
    padded = np.concatenate(([False], loud, [False]))
    edges = np.flatnonzero(padded[1:] != padded[:-1])
    return [(int(edges[i]), int(edges[i + 1])) for i in range(0, len(edges), 2)]


def test_wav_assembly_preserves_chunk_order_and_no_missing_audio(tmp_path):
    values = [0.25, -0.35, 0.45]
    paths = [write_chunk(tmp_path / f"chunk{i}.wav", value) for i, value in enumerate(values)]
    specs = [ChunkSpec(path=str(p), chapter_id="c1", chapter_idx=0, chunk_idx=i,
                       pause_before_ms=100, chapter_transition_ms=800) for i, p in enumerate(paths)]
    assert validate_chunk_specs(specs) == []
    output = tmp_path / "book.wav"
    result = assemble_wav(specs, output)
    assert result["chunks"] == 3 and output.is_file()
    samples = read_wav(output)
    segments = non_silent_segments(samples)
    assert len(segments) == 3
    means = [float(np.mean(samples[a:b])) for a, b in segments]
    assert means[0] > 0.15 and means[1] < -0.2 and means[2] > 0.3
    assert abs(result["duration"] - len(samples) / 24000) < 0.001
    assert not list(tmp_path.glob("*.tmp.wav"))


def test_chapter_transition_is_longer_than_ordinary_pause(tmp_path):
    paths = [write_chunk(tmp_path / "a.wav", 0.3), write_chunk(tmp_path / "b.wav", 0.3)]
    specs = [ChunkSpec(path=str(paths[0]), chapter_id="c1", chapter_idx=0, chunk_idx=0, pause_before_ms=0),
             ChunkSpec(path=str(paths[1]), chapter_id="c2", chapter_idx=1, chunk_idx=0,
                       pause_before_ms=100, chapter_transition_ms=1200)]
    result = assemble_wav(specs, tmp_path / "two.wav")
    # 2 x 0.5 s speech + 1.2 s chapter transition = 2.2 s
    assert 2.1 < result["duration"] < 2.3


def test_mp3_streaming_export_is_decodable(tmp_path):
    pytest.importorskip("lameenc")
    paths = [write_chunk(tmp_path / f"m{i}.wav", 0.2 + 0.1 * i) for i in range(3)]
    specs = [ChunkSpec(path=str(p), chapter_id="c1", chapter_idx=0, chunk_idx=i,
                       pause_before_ms=80) for i, p in enumerate(paths)]
    output = tmp_path / "book.mp3"
    result = assemble_mp3(specs, output, bitrate=96)
    assert output.is_file() and output.stat().st_size > 1000
    info = probe_audio(output)
    assert info["duration"] >= 1.2
    assert result["chunks"] == 3


def test_assembly_validates_missing_files_and_cancellation(tmp_path):
    missing = tmp_path / "missing.wav"
    specs = [ChunkSpec(path=str(missing), chapter_id="c1", chapter_idx=0, chunk_idx=0)]
    problems = validate_chunk_specs(specs)
    assert problems and "missing" in problems[0]
    good = write_chunk(tmp_path / "good.wav", 0.2)
    cancel = threading.Event()
    cancel.set()
    with pytest.raises(Exception):
        assemble_wav([ChunkSpec(path=str(good), chapter_id="c1", chapter_idx=0, chunk_idx=0)],
                     tmp_path / "cancelled.wav", cancel_event=cancel)
