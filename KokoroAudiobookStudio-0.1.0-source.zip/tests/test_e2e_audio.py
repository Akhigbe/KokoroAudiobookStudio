from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import pytest

from kokoro_studio.audio import read_wav
from kokoro_studio.network_guard import is_offline, set_offline
from kokoro_studio.resources import ResourceManager


@pytest.mark.e2e
def test_real_offline_kokoro_sample_is_audible(tmp_path):
    if os.environ.get("KAS_E2E") != "1":
        pytest.skip("Set KAS_E2E=1 with downloaded resources to run the real inference test.")
    resources = ResourceManager()
    verification = resources.verify_resources("q8")
    if not verification.ok:
        pytest.skip("Pinned q8 resources are not installed in this test data root.")
    set_offline(True)
    output = tmp_path / "real_sample.wav"
    report = resources.offline_readiness_test(model_id="q8", voice=verification.installed_voices[0],
                                               output_path=output, play=False, mark_ready=True)
    assert report.get("ok"), report
    assert is_offline()
    assert output.is_file() and output.stat().st_size > 10_000
    samples = read_wav(output)
    duration = len(samples) / 24000
    rms = float(np.sqrt(np.mean(samples ** 2)))
    peak = float(np.max(np.abs(samples)))
    assert duration > 2.0
    assert rms > 0.005 and peak > 0.02 and peak < 1.0
    assert not np.isnan(samples).any()
