from __future__ import annotations

import threading
import time

import numpy as np

from kokoro_studio.audio import WavChunkWriter
from kokoro_studio.config import load_settings, save_settings
from kokoro_studio.generation import GenerationController
from kokoro_studio.models import NarrationSettings
from kokoro_studio.resources import ResourceManager
from kokoro_studio.storage import Storage


class FakeEngine:
    count = 0

    def __init__(self, delay: float = 0.0):
        self.delay = delay
        self.cancelled = False
        self.started = False

    def start(self):
        self.started = True
        return {"ok": True}

    def synthesize_chunk(self, text, output_path, **kwargs):
        if self.delay:
            time.sleep(self.delay)
        if self.cancelled:
            raise RuntimeError("cancelled by test")
        FakeEngine.count += 1
        with WavChunkWriter(output_path) as writer:
            writer.write(np.full(2400, 0.1, dtype=np.float32))
        return {"ok": True, "duration": 0.1, "size": 4800, "rtf": 0.01}

    def process_tree_rss_mb(self):
        return 42.0

    def cancel_current(self):
        self.cancelled = True

    def stop(self):
        return None


def make_project(storage: Storage) -> str:
    settings = NarrationSettings(chunk_target_chars=1000, chunk_max_chars=1200,
                                 expand_numbers=False, expand_dates=False,
                                 expand_abbreviations=False, normalize_text=False)
    project = storage.create_project(
        "Queue book",
        chapters=[{"title": "Chapter 1", "text": "First paragraph is here.\n\nSecond paragraph is here.\n\nThird paragraph is here."}],
        settings=settings,
    )
    return project.id


def wait_for(controller: GenerationController, timeout: float = 15.0):
    thread = controller._thread
    if not thread:
        return
    deadline = time.monotonic() + timeout
    while thread.is_alive() and time.monotonic() < deadline:
        time.sleep(0.05)


def test_generation_reuses_completed_chunks_after_selective_edit(tmp_path):
    FakeEngine.count = 0
    storage = Storage(tmp_path / "studio.sqlite3")
    project_id = make_project(storage)
    controller = GenerationController(storage, ResourceManager(), engine_factory=lambda: FakeEngine())
    controller.start(project_id, auto_export=True)
    wait_for(controller)
    status = controller.snapshot()
    assert status.state == "completed", status.message
    assert FakeEngine.count == 3
    assert storage.project_stats(project_id)["done"] == 3
    assert controller.status.exports and __import__("pathlib").Path(controller.status.exports[0]).is_file()

    # Change only the second paragraph; the first and third WAVs must be reused.
    chapter = storage.list_chapters(project_id)[0]
    paragraphs = chapter.narration_text.split("\n\n")
    paragraphs[1] = "Second paragraph was corrected."
    storage.update_chapter(chapter.id, narration_text="\n\n".join(paragraphs))
    assert storage.project_stats(project_id)["stale"] == 1
    controller.start(project_id, auto_export=False)
    wait_for(controller)
    assert controller.snapshot().state == "completed"
    assert FakeEngine.count == 4


def test_cancel_preserves_completed_chunks_and_resume_finishes(tmp_path):
    FakeEngine.count = 0
    storage = Storage(tmp_path / "studio.sqlite3")
    project_id = make_project(storage)
    engines = []

    def factory():
        engine = FakeEngine(delay=0.18)
        engines.append(engine)
        return engine

    controller = GenerationController(storage, ResourceManager(), engine_factory=factory)
    controller.start(project_id, auto_export=False)
    deadline = time.monotonic() + 5
    while controller.snapshot().completed < 1 and time.monotonic() < deadline:
        time.sleep(0.02)
    controller.cancel()
    wait_for(controller, timeout=5)
    status = controller.snapshot()
    assert status.state == "cancelled", status.message
    assert controller.snapshot().completed >= 1
    assert storage.project_stats(project_id)["done"] >= 1

    # A new job resumes only the remaining chunks.
    controller.start(project_id, auto_export=False)
    wait_for(controller)
    assert controller.snapshot().state == "completed"
    assert storage.project_stats(project_id)["done"] == 3
    assert FakeEngine.count == 3
