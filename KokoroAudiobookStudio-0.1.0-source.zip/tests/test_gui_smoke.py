from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


@pytest.mark.gui
def test_all_pages_instantiate_under_xvfb(tmp_path):
    if os.environ.get("KAS_GUI_SMOKE") != "1":
        pytest.skip("Set KAS_GUI_SMOKE=1 and run pytest under xvfb-run.")
    if os.name != "nt" and not os.environ.get("DISPLAY"):
        pytest.skip("No DISPLAY; run with xvfb-run -a pytest ...")
    root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(root / "src") + os.pathsep + env.get("PYTHONPATH", "")
    env["KAS_DATA_DIR"] = str(tmp_path / "appdata")
    env["KAS_SKIP_SETUP"] = "1"
    report = tmp_path / "ui_smoke.json"
    result = subprocess.run(
        [sys.executable, "-m", "kokoro_studio.app", "--self-test", "--headless", "--skip-setup",
         "--self-test-report", str(report)],
        cwd=root, env=env, capture_output=True, text=True, timeout=90,
    )
    assert result.returncode == 0, result.stdout + "\n" + result.stderr
    data = json.loads(report.read_text(encoding="utf-8"))
    assert data["ok"]
    assert len(data["pages"]) == 9
    assert max(data["timer_callback_delays_ms"]) < 250
