from __future__ import annotations

from pathlib import Path

import pytest

from kokoro_studio.importers import (
    ImportFailure, import_file, import_pasted_text, markdown_to_plain, read_txt, validate_file,
)


def write_docx(path: Path) -> None:
    from docx import Document
    document = Document()
    document.add_heading("Chapter 1: The Signal", level=1)
    document.add_paragraph("Maya heard the bell at dawn.")
    document.add_paragraph("Dr. Okafor arrived on 2026-02-12.")
    document.add_heading("Chapter 2: The Tunnel", level=1)
    document.add_paragraph("The train waited under the hill.")
    document.save(path)


def write_pdf(path: Path, *, empty_text: bool = False) -> None:
    from fpdf import FPDF
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    for page in range(3):
        pdf.add_page()
        if empty_text:
            continue  # No text objects: simulates an image-only/scanned PDF.
        pdf.set_font("Helvetica", size=11)
        pdf.cell(0, 8, "Wintergate Memoirs", ln=True)
        pdf.set_font("Helvetica", size=16)
        if page == 0:
            pdf.cell(0, 12, "Chapter 1: The Signal", ln=True)
        elif page == 1:
            pdf.cell(0, 12, "Chapter 2: The Tunnel", ln=True)
        pdf.set_font("Helvetica", size=11)
        pdf.cell(0, 8, f"On page {page+1}, Maya heard the bell and walked toward the platform.", ln=True)
        pdf.cell(0, 8, "The lantern made a soft sound in the rain.", ln=True)
        pdf.cell(0, 8, f"Page {page+1}", ln=True)
        pdf.cell(0, 8, "Confidential manuscript", ln=True)
    pdf.output(path)


def test_txt_import_and_chapter_order(tmp_path, sample_text):
    path = tmp_path / "book.txt"
    path.write_text(sample_text, encoding="utf-8")
    result = import_file(path)
    assert result.source_type == "txt"
    assert len(result.chapters) == 2
    assert "Lantern" in result.chapters[0].title
    assert "Platform" in result.chapters[1].title
    assert result.source_hash
    assert result.preview


def test_markdown_import_preserves_headings(tmp_path):
    path = tmp_path / "book.md"
    path.write_text("# Chapter One\n\n**Maya** waited.\n\n## Chapter Two\n\nThe [train](https://example.invalid) left.\n", encoding="utf-8")
    text = markdown_to_plain(path.read_text(encoding="utf-8"))
    assert "**" not in text and "[train]" not in text
    assert "Chapter One" in text and "The train left" in text
    result = import_file(path)
    assert len(result.chapters) == 2
    assert "Maya waited" in result.chapters[0].text


def test_docx_import_reads_headings_and_paragraphs(tmp_path):
    path = tmp_path / "book.docx"
    write_docx(path)
    assert validate_file(path) == path
    result = import_file(path)
    assert result.source_type == "docx"
    assert len(result.chapters) == 2
    assert "Maya heard" in result.chapters[0].text
    assert "train waited" in result.chapters[1].text


def test_pdf_import_removes_repeated_headers_and_footers(tmp_path):
    pytest.importorskip("fpdf")
    path = tmp_path / "book.pdf"
    write_pdf(path)
    result = import_file(path)
    assert result.source_type == "pdf"
    assert result.pages == 3
    assert result.removed_lines
    joined = "\n".join(c.text for c in result.chapters)
    assert "Wintergate Memoirs" not in joined
    assert "Confidential manuscript" not in joined
    assert "Page 1" not in joined
    assert "Maya heard" in joined


def test_image_only_pdf_reports_ocr_need(tmp_path):
    pytest.importorskip("fpdf")
    path = tmp_path / "scan.pdf"
    write_pdf(path, empty_text=True)
    result = import_file(path)
    assert result.needs_ocr
    assert any("OCR" in warning for warning in result.warnings)


def test_paste_import_and_invalid_file(tmp_path):
    result = import_pasted_text("Chapter 1\n\nHello from a pasted manuscript.")
    assert len(result.chapters) == 1
    bad = tmp_path / "bad.docx"
    bad.write_bytes(b"not a docx")
    with pytest.raises(ImportFailure):
        validate_file(bad)
    with pytest.raises(ImportFailure):
        import_file(bad)
