from __future__ import annotations

import socket
import urllib.request

import pytest

from kokoro_studio.network_guard import OfflineNetworkError, is_offline, set_offline


def test_offline_guard_blocks_remote_socket_and_urlopen():
    set_offline(True)
    try:
        assert is_offline()
        with pytest.raises(OfflineNetworkError):
            socket.create_connection(("example.com", 80), timeout=1)
        with pytest.raises(OfflineNetworkError):
            urllib.request.urlopen("https://example.com", timeout=1)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            with pytest.raises(OfflineNetworkError):
                sock.connect(("8.8.8.8", 53))
        finally:
            sock.close()
    finally:
        set_offline(False)
    assert not is_offline()


def test_offline_guard_allows_loopback(range_server):
    url, _ = range_server
    set_offline(True)
    try:
        # Loopback is local and is intentionally allowed for local test servers.
        with urllib.request.urlopen(url, timeout=3) as response:
            assert response.status == 200
    finally:
        set_offline(False)
