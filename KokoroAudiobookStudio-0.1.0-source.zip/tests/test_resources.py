from __future__ import annotations

import hashlib
import threading

import pytest

from kokoro_studio.network_guard import is_offline, set_offline
from kokoro_studio.resources import OfflineViolation, ResourceManager


def make_asset(url: str, data: bytes) -> dict:
    return {
        "name": "test.bin", "url": url, "size": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "relative_path": "models/test.bin",
    }


def test_download_pause_resume_checksum_and_corrupt_quarantine(tmp_path, range_server):
    url, data = range_server
    resources = ResourceManager()
    asset = make_asset(url, data)
    target = resources.local_path(asset)
    set_offline(False)
    pause = threading.Event()
    pause.set()
    progress_seen = []
    paused_once = {"done": False}

    def progress(info):
        progress_seen.append(info)
        if not paused_once["done"] and info.get("bytes_done", 0) > 1024 * 1024:
            pause.clear()
            paused_once["done"] = True

    result = resources.download_asset(asset, progress=progress, pause_event=pause)
    assert result == "paused"
    part = target.with_name(target.name + ".part")
    assert part.exists() and 0 < part.stat().st_size < len(data)
    assert progress_seen
    pause.set()
    result = resources.download_asset(asset, progress=progress, pause_event=pause)
    assert result == "complete"
    assert target.read_bytes() == data
    check = resources.verify_asset(asset)
    assert check.ok
    # A re-download should skip the verified file.
    assert resources.download_asset(asset) == "skipped"

    # Corruption is detected by checksum and quarantined rather than trusted.
    with target.open("r+b") as f:
        f.seek(100)
        f.write(b"\xff")
    check = resources.verify_asset(asset, quarantine=True)
    assert not check.ok and "SHA-256" in check.detail
    assert not target.exists()
    assert target.with_name(target.name + ".corrupt").exists()


def test_offline_mode_blocks_download_explicitly(range_server):
    url, data = range_server
    resources = ResourceManager()
    asset = make_asset(url, data)
    set_offline(True)
    try:
        assert is_offline()
        with pytest.raises(OfflineViolation):
            resources.download_asset(asset)
    finally:
        set_offline(False)


def test_manifest_pins_revision_and_checksums():
    resources = ResourceManager()
    assert resources.revision == "1939ad2a8e416c0acfeecc08a694d14ef25f2231"
    q8 = resources.model("q8")
    assert q8["size"] == 92_361_116
    assert len(q8["sha256"]) == 64
    assert all(len(v["sha256"]) == 64 for v in resources.manifest["voices"])
    assert len(resources.manifest["voices"]) == 54
    assert resources.bundled_config_files()
    for asset in resources.bundled_config_files():
        assert (resources.manifest_path.parent / "runtime_config" / asset["name"]).is_file()


def test_voice_pack_builds_only_verified_voices(tmp_path):
    resources = ResourceManager()
    voice_dir = resources.local_path({"relative_path": "voices/af_heart.bin"}).parent
    voice_dir.mkdir(parents=True, exist_ok=True)
    # A valid pinned voice file plus an invalid file of the same size.
    valid = voice_dir / "af_heart.bin"
    valid.write_bytes((b"\x00" * 522240))
    # This is not the real checksum, so it must be skipped.
    (voice_dir / "fake_voice.bin").write_bytes(b"\x00" * 522240)
    with pytest.raises(Exception):
        resources.build_voice_pack(["af_heart", "fake_voice"])
