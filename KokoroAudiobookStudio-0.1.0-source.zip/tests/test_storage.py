from __future__ import annotations

import numpy as np
import soundfile as sf

from kokoro_studio.audio import SAMPLE_RATE
from kokoro_studio.models import NarrationSettings
from kokoro_studio.storage import Storage
from kokoro_studio.text_processing import sha256_text


def make_wav(path, value: float = 0.1, frames: int = 2400):
    data = np.full(frames, value, dtype=np.float32)
    sf.write(str(path), data, SAMPLE_RATE, subtype="PCM_16")
    return path


def make_project(storage: Storage, name: str = "Test book") -> tuple[str, list[str]]:
    settings = NarrationSettings(chunk_target_chars=1000, chunk_max_chars=1200,
                                 expand_numbers=False, expand_dates=False,
                                 expand_currencies=False, expand_measurements=False,
                                 expand_abbreviations=False, normalize_text=False)
    text = "First paragraph is spoken here.\n\nSecond paragraph has the old sentence.\n\nThird paragraph closes the chapter."
    project = storage.create_project(name, chapters=[{"title": "Chapter 1", "text": text}], settings=settings)
    chunks = storage.list_chunks(project.id)
    assert len(chunks) == 3
    for i, chunk in enumerate(chunks):
        path = storage.chunk_audio_path(chunk)
        make_wav(path, value=0.1 + 0.05 * i)
        storage.mark_chunk_done(chunk.id, str(path), 0.1, path.stat().st_size)
    return project.id, [c.id for c in chunks]


def test_project_crud_duplicate_backup_restore(tmp_path):
    storage = Storage(tmp_path / "studio.sqlite3")
    project_id, chunk_ids = make_project(storage)
    project = storage.get_project(project_id)
    assert project and project.name == "Test book"
    assert storage.project_stats(project_id)["done"] == 3

    copy = storage.duplicate_project(project_id, "Copy")
    assert copy and copy.id != project_id
    assert storage.project_stats(copy.id)["done"] == 3
    for chunk in storage.list_chunks(copy.id):
        assert chunk.audio_path and __import__("pathlib").Path(chunk.audio_path).exists()

    backup = tmp_path / "backup.kasbackup"
    storage.backup_project(project_id, backup)
    assert backup.is_file() and backup.stat().st_size > 1000
    restored = storage.restore_project(backup)
    assert restored.id not in {project_id, copy.id}
    assert storage.project_stats(restored.id)["done"] == 3

    storage.rename_project(project_id, "Renamed")
    assert storage.get_project(project_id).name == "Renamed"
    storage.delete_project(copy.id)
    assert storage.get_project(copy.id) is None


def test_editing_one_paragraph_only_invalidates_affected_chunk(tmp_path):
    storage = Storage(tmp_path / "studio.sqlite3")
    project_id, chunk_ids = make_project(storage)
    before = {c.id: c for c in storage.list_chunks(project_id)}
    chapter = storage.list_chapters(project_id)[0]
    paragraphs = chapter.narration_text.split("\n\n")
    paragraphs[1] = "Second paragraph has a corrected sentence."
    storage.update_chapter(chapter.id, narration_text="\n\n".join(paragraphs))
    after = {c.id: c for c in storage.list_chunks(project_id)}
    assert after[chunk_ids[0]].status == "done"
    assert after[chunk_ids[1]].status == "stale"
    assert after[chunk_ids[2]].status == "done"
    assert after[chunk_ids[0]].text_hash == before[chunk_ids[0]].text_hash
    assert after[chunk_ids[1]].text_hash != before[chunk_ids[1]].text_hash


def test_chapter_reorder_split_merge_and_regeneration(tmp_path):
    storage = Storage(tmp_path / "studio.sqlite3")
    project_id, _ = make_project(storage)
    first = storage.list_chapters(project_id)[0]
    second = storage.create_chapter(project_id, "Chapter 2", "A second short paragraph.\n\nAnother short paragraph.")
    assert [c.title for c in storage.list_chapters(project_id)] == ["Chapter 1", "Chapter 2"]
    storage.move_chapter(second.id, -1)
    assert [c.title for c in storage.list_chapters(project_id)] == ["Chapter 2", "Chapter 1"]
    storage.move_chapter(second.id, 1)
    assert [c.title for c in storage.list_chapters(project_id)] == ["Chapter 1", "Chapter 2"]
    new_id = storage.split_chapter(second.id, 2)
    assert new_id
    titles = [c.title for c in storage.list_chapters(project_id)]
    assert len(titles) == 3 and any("continued" in t for t in titles)
    storage.merge_chapters(second.id, new_id)
    assert len(storage.list_chapters(project_id)) == 2
    storage.regenerate_chapter(first.id)
    statuses = [c.status for c in storage.list_chunks(project_id, first.id)]
    assert statuses and all(status == "stale" for status in statuses)


def test_chunk_provenance_hashes(tmp_path):
    storage = Storage(tmp_path / "studio.sqlite3")
    project_id, chunk_ids = make_project(storage)
    chunk = storage.get_chunk(chunk_ids[0])
    assert chunk.text_hash == sha256_text(chunk.narration_text)
    assert chunk.settings_hash
    assert chunk.audio_path.endswith(".wav")
