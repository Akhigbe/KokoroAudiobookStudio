from __future__ import annotations

from kokoro_studio.models import NarrationSettings
from kokoro_studio.text_processing import (
    NarrationPreprocessor, chapter_heading, clean_extracted_text, detect_chapters,
    number_to_words, repeated_page_lines, split_narration_chunks, year_to_words,
)


def test_chapter_detection_preserves_order_and_titles(sample_text):
    chapters = detect_chapters(sample_text)
    assert len(chapters) == 2
    assert "Lantern" in chapters[0].title
    assert "Platform" in chapters[1].title
    assert chapters[0].source_order == 0 and chapters[1].source_order == 1
    assert chapters[0].text.startswith("On 12 February 2026")
    assert "lantern flickered" in chapters[1].text


def test_heading_detection_rejects_prose():
    assert chapter_heading("CHAPTER 3: THE RETURN")
    assert chapter_heading("## Part Two")
    assert chapter_heading("23. The Long Road")
    assert not chapter_heading("Maya opened the door and looked outside.")
    assert not chapter_heading("Chapter one was a very long sentence that continues well beyond a heading.")


def test_chunking_respects_hard_limit_and_sentence_boundaries():
    settings = NarrationSettings(chunk_target_chars=90, chunk_max_chars=120)
    text = ("Maya waited on the cold platform. " * 20) + "\n\n" + ("The lantern flickered softly. " * 20)
    chunks = split_narration_chunks(text, settings)
    assert len(chunks) > 4
    assert all(len(c.text) <= settings.chunk_max_chars for c in chunks)
    assert all(c.text.strip() for c in chunks)
    assert any("Maya" in c.text for c in chunks) and any("lantern" in c.text for c in chunks)
    assert all(c.source_start >= 0 and c.source_end >= c.source_start for c in chunks)


def test_preprocessor_is_auditable_and_does_not_mutate_source(sample_text):
    original = sample_text
    settings = NarrationSettings(pronunciation={"Kokoro": "Koh koh roh"})
    result, transformations = NarrationPreprocessor(settings).transform(sample_text + " Kokoro says hello.")
    assert sample_text == original
    assert result != sample_text
    assert "Doctor Okafor" in result
    assert "Mister Adeyemi" in result
    assert "dollars" in result
    assert "kilograms" in result
    assert "kilometers" in result
    assert "percent" in result
    assert "February" in result and "twenty twenty-six" in result
    assert "Koh koh roh" in result
    kinds = {t.kind for t in transformations}
    assert {"abbreviation", "number", "currency", "measurement", "date", "pronunciation"} <= kinds


def test_expansion_toggles_disable_all_automatic_rewrites():
    settings = NarrationSettings(
        normalize_text=False, expand_abbreviations=False, expand_numbers=False,
        expand_dates=False, expand_currencies=False, expand_measurements=False,
        pronunciation={"Maya": "My ah"},
    )
    text = "Dr. Maya paid $12.50 on 2026-02-12 for 2 kg."
    result, transformations = NarrationPreprocessor(settings).transform(text)
    assert "Dr." in result and "$12.50" in result and "2026-02-12" in result and "2 kg" in result
    assert "My ah" in result
    assert all(t.kind == "pronunciation" for t in transformations)


def test_number_and_year_words():
    assert number_to_words(0) == "zero"
    assert number_to_words(42) == "forty-two"
    assert number_to_words(105) == "one hundred and five"
    assert number_to_words(2026) == "two thousand twenty-six"
    assert year_to_words(2026) == "twenty twenty-six"
    assert year_to_words(1999) == "nineteen ninety-nine"


def test_pdf_repeated_line_detection_and_cleanup():
    pages = [
        "Wintergate Memoirs\nPage 1\nMaya arrived at dawn.\nConfidential",
        "Wintergate Memoirs\nPage 2\nThe lantern was warm.\nConfidential",
        "Wintergate Memoirs\nPage 3\nThey departed at noon.\nConfidential",
    ]
    repeated = repeated_page_lines(pages)
    assert "Wintergate Memoirs" in repeated and "Confidential" in repeated
    assert all(f"Page {n}" in repeated for n in (1, 2, 3))
    cleaned = clean_extracted_text("\n".join(pages), repeated)
    assert "Wintergate Memoirs" not in cleaned
    assert "Confidential" not in cleaned
    assert "Maya arrived at dawn" in cleaned
    assert "Page 1" not in cleaned
